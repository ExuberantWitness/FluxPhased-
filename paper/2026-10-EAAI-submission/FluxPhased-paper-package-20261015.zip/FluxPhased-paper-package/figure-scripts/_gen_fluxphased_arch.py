"""FluxPhased architecture figure: three-tier stack (signal physics -> task-level
multi-agent environment -> GPU-parallel training backend). v2: roomier gaps,
no annotation/border collisions."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

FIGS = Path(r'E:\DATA\vscode\RADAR_AGENT_EXECUTION_PACKAGE_2\paper_eaai\figures')

fig, ax = plt.subplots(figsize=(7.6, 5.4))
ax.set_xlim(0, 10); ax.set_ylim(0, 7.6); ax.axis('off')

TIER_STYLE = dict(linewidth=1.1, edgecolor='#37474F', boxstyle='round,pad=0.04,rounding_size=0.10')
BOX_STYLE = dict(linewidth=0.8, boxstyle='round,pad=0.02,rounding_size=0.05')

def tier(x, y, w, h, face, title, note=None):
    ax.add_patch(FancyBboxPatch((x, y), w, h, facecolor=face, **TIER_STYLE))
    ax.text(x + 0.18, y + h - 0.26, title, fontsize=9.5, fontweight='bold',
            color='#263238', va='center')
    if note:
        ax.text(x + w - 0.18, y + h - 0.26, note, fontsize=7.5, color='#546E7A',
                ha='right', va='center', style='italic')

def box(x, y, w, h, label, face, ec='#455A64'):
    ax.add_patch(FancyBboxPatch((x, y), w, h, facecolor=face, edgecolor=ec, **BOX_STYLE))
    ax.text(x + w / 2, y + h / 2, label, ha='center', va='center', fontsize=7.6, color='#212121')

# ── Top tier: GPU-parallel training backend (5.55 – 7.15) ───────────
tier(0.3, 5.55, 9.4, 1.60, '#FDECEA', 'GPU-Parallel Training Backend',
     '16 parallel rollouts · 7.72 s/iter')
box(0.62, 5.80, 2.55, 0.72, 'MAPPO\ntrainer', 'white')
box(3.42, 5.80, 2.55, 0.72, 'Frozen jammer\npool (3 ckpts)', 'white')
box(6.22, 5.80, 3.15, 0.72, 'Canonical evaluator\n(protected manifests)', 'white')

# ── Middle tier: task-level multi-agent environment (3.05 – 5.10) ───
tier(0.3, 3.05, 9.4, 2.05, '#E8F0FB', 'Task-Level Multi-Agent Environment (S7)',
     '64-step horizon · PettingZoo API')
box(0.62, 3.80, 2.75, 0.85, '2× radar stations\n25 beams × 2 services', 'white')
box(3.62, 3.80, 2.75, 0.85, '2× jammer stations\n63-cell power budget', 'white')
box(6.62, 3.80, 2.75, 0.85, 'Missions\n5 sectors · deadlines', 'white')
box(0.62, 3.22, 8.75, 0.40, 'detection sigmoid · bearing-dependent array gain · finite energy · action validation',
    '#F6FAFF', ec='#90A4AE')

# ── Bottom tier: signal-level validated physics (0.50 – 2.60) ───────
tier(0.3, 0.50, 9.4, 2.10, '#E9F5EE', 'Signal-Level Validated Physics (inherited)',
     'IQ-level, three-layer cross-validated')
box(0.62, 1.30, 2.10, 0.85, 'array factor\n(1.4e-4 dB)', 'white')
box(2.92, 1.30, 2.10, 0.85, 'radar equation\n(0.000 dB)', 'white')
box(5.22, 1.30, 2.10, 0.85, 'Friis link budget\n(3.1e-15)', 'white')
box(7.52, 1.30, 1.85, 0.85, 'matched filter\n(0.21 m)', 'white')
box(0.62, 0.72, 4.20, 0.42, 'MATLAB Phased Array Toolbox: 83/83 tests · 985 sweeps',
    '#F4FAF7', ec='#90A4AE')
box(5.07, 0.72, 4.30, 0.42, 'RadarSimPy v15.2.0: 12 jamming links · 0 dB error',
    '#F4FAF7', ec='#90A4AE')

# ── Inter-tier arrows and labels (gaps 2.60–3.05 and 5.10–5.55) ─────
for (ylo, yhi) in [(2.60, 3.05), (5.10, 5.55)]:
    ax.add_patch(FancyArrowPatch((3.1, ylo), (3.1, yhi), arrowstyle='-|>',
                                 mutation_scale=11, linewidth=1.0, color='#455A64'))
    ax.add_patch(FancyArrowPatch((6.9, yhi), (6.9, ylo), arrowstyle='-|>',
                                 mutation_scale=11, linewidth=1.0, color='#78909C'))
    ymid = (ylo + yhi) / 2
    ax.text(2.93, ymid, 'obs / env steps' if yhi > 4 else 'abstracted physics',
            fontsize=7, ha='right', va='center', color='#37474F')
    ax.text(7.07, ymid, 'actions' if yhi > 4 else 'geometric / RF parameters',
            fontsize=7, ha='left', va='center', color='#607D8B')

fig.tight_layout(pad=0.3)
fig.savefig(str(FIGS / 'fig_fluxphased_arch.pdf'), bbox_inches='tight')
print('fig_fluxphased_arch.pdf written (v2)')
