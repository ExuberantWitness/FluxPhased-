"""Generate TD-MPC Figure 3 style learning curves (4x4 grid + summary), NPG palette."""
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
from scipy.ndimage import uniform_filter1d

CURVES = Path(r'E:\DATA\vscode\RADAR_AGENT_EXECUTION_PACKAGE_2\campaigns\cap_curves')
FIGS = Path(r'E:\DATA\vscode\RADAR_AGENT_EXECUTION_PACKAGE_2\paper_eaai\figures')

data = {}
for f in sorted(CURVES.glob('*_curves.json')):
    d = json.loads(f.read_text())
    key = f"{d['domain']}:{d['task']}"
    data[key] = d['curves']

domains = sorted(data.keys())
if not domains:
    print('No curve data found!')
    exit(1)

ARMS = ['default', 'agent', 'llm_nodiag']
# ggsci NPG (Nature Publishing Group) palette
COLORS = {'default': '#8491B4', 'agent': '#E64B35', 'llm_nodiag': '#3C5488'}
LABELS = {'default': 'Default CEM', 'agent': 'Agent (diagnosis)',
          'llm_nodiag': 'LLM (no diagnosis)'}

short_names = {
    'cartpole:balance': 'cartpole\nbalance', 'cartpole:swingup': 'cartpole\nswingup',
    'cheetah:run': 'cheetah\nrun', 'finger:spin': 'finger\nspin',
    'finger:turn_easy': 'finger\nturn_easy', 'fish:swim': 'fish\nswim',
    'fish:upright': 'fish\nupright', 'hopper:hop': 'hopper\nhop',
    'humanoid:run': 'humanoid\nrun', 'humanoid:stand': 'humanoid\nstand',
    'manipulator:bring_ball': 'manipulator\nbring', 'pendulum:swingup': 'pendulum\nswing',
    'quadruped:run': 'quadruped\nrun', 'quadruped:walk': 'quadruped\nwalk',
    'reacher:hard': 'reacher\nhard', 'walker:run': 'walker\nrun',
}

def smooth_and_interp(curves, n_points=100, smooth_window=5):
    if not curves:
        return None, None, None
    parsed = []
    for c in curves:
        if not c:
            continue
        pts = []
        for p in c:
            if isinstance(p, (list, tuple)) and len(p) >= 2:
                pts.append((float(p[0]), float(p[1])))
        if pts:
            parsed.append(pts)
    if not parsed:
        return None, None, None
    max_x = min(p[-1][0] for p in parsed)
    if max_x <= 0:
        return None, None, None
    x_common = np.linspace(0, max_x, n_points)
    interpolated = []
    for pts in parsed:
        xs = np.array([p[0] for p in pts])
        ys = np.array([p[1] for p in pts])
        ys_interp = np.interp(x_common, xs, ys)
        ys_smooth = uniform_filter1d(ys_interp, size=smooth_window, mode='nearest')
        interpolated.append(ys_smooth)
    arr = np.array(interpolated)
    mean = arr.mean(axis=0)
    std = arr.std(axis=0) if len(arr) > 1 else np.zeros_like(mean)
    ci = 1.96 * std / max(np.sqrt(len(arr)), 1)
    return x_common, mean, ci

n_domains = len(domains)
n_cols = 4
n_rows = (n_domains + n_cols - 1) // n_cols + 1

fig, axes = plt.subplots(n_rows, n_cols, figsize=(16, 4 * n_rows * 0.7))
fig.suptitle('Code-as-Policy TD-MPC: Learning Curves on 16 dm_control Domains\n'
             '(Mean of 3 seeds; shaded areas are 95% confidence intervals)',
             fontsize=12, fontweight='bold', y=0.98)

all_norm_curves = {arm: [] for arm in ARMS}

for idx, dm in enumerate(domains):
    row, col = idx // n_cols, idx % n_cols
    ax = axes[row, col]
    curves_by_arm = data[dm]
    for arm in ARMS:
        if arm not in curves_by_arm:
            continue
        seed_curves = curves_by_arm[arm]
        curve_lists = []
        for sc in seed_curves:
            if isinstance(sc, list) and sc and isinstance(sc[0], (list, tuple)):
                curve_lists.append([(p[0], p[1]) for p in sc])
        x, mean, ci = smooth_and_interp(curve_lists)
        if x is None:
            continue
        ax.plot(x, mean, color=COLORS[arm], linewidth=1.5, label=LABELS[arm])
        ax.fill_between(x, mean - ci, mean + ci, color=COLORS[arm], alpha=0.15)
        if mean.max() > 0:
            all_norm_curves[arm].append(mean / mean.max())
    ax.set_title(short_names.get(dm, dm), fontsize=7, fontweight='bold')
    ax.set_xlabel('Steps', fontsize=6)
    ax.set_ylabel('Reward', fontsize=6)
    ax.tick_params(labelsize=5)
    ax.grid(alpha=0.2)

summary_ax = axes[n_rows - 1, 0] if n_domains < n_rows * n_cols else axes[-1, 0]
for arm in ARMS:
    curves = all_norm_curves[arm]
    if curves:
        arr = np.array(curves)
        mean = arr.mean(axis=0)
        std = arr.std(axis=0)
        ci = 1.96 * std / np.sqrt(len(arr))
        x = np.linspace(0, 5000, len(mean))
        summary_ax.plot(x, mean, color=COLORS[arm], linewidth=2, label=LABELS[arm])
        summary_ax.fill_between(x, mean - ci, mean + ci, color=COLORS[arm], alpha=0.15)
summary_ax.set_title('Average (normalized)\nacross all domains', fontsize=8, fontweight='bold')
summary_ax.set_xlabel('Steps', fontsize=7)
summary_ax.set_ylabel('Normalized reward', fontsize=7)
summary_ax.legend(fontsize=6, loc='lower right')
summary_ax.grid(alpha=0.2)

for idx in range(n_domains, n_rows * n_cols):
    row, col = idx // n_cols, idx % n_cols
    if idx != n_domains:
        axes[row, col].set_visible(False)

from matplotlib.lines import Line2D
legend_elems = [Line2D([0], [0], color=COLORS[a], linewidth=2, label=LABELS[a]) for a in ARMS]
fig.legend(handles=legend_elems, loc='upper right', fontsize=8, bbox_to_anchor=(0.98, 0.96))

fig.tight_layout(rect=[0, 0, 1, 0.94])
fig.savefig(str(FIGS / 'fig17_cap_curves.pdf'), dpi=150, bbox_inches='tight')
print(f'fig17_cap_curves.pdf saved ({n_domains} domains, NPG palette)')
