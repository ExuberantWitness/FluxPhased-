"""Generate the EAAI workflow figure as a simple vector PDF."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

out = Path(__file__).resolve().parent
fig, ax = plt.subplots(figsize=(7.0, 2.8))
ax.set_xlim(0, 10); ax.set_ylim(0, 4); ax.axis('off')
boxes = [
    (0.3, 1.45, 1.45, 1.0, 'Observe\nlearning curve'),
    (2.0, 1.45, 1.45, 1.0, 'Retrieve\narXiv papers'),
    (3.7, 1.45, 1.45, 1.0, 'Read +\nsynthesize'),
    (5.4, 1.45, 1.45, 1.0, 'Hypothesize\none change'),
    (7.1, 1.45, 1.45, 1.0, 'Train with\nfrozen jammer'),
    (8.8, 1.45, 0.9, 1.0, 'Keep /\nstop'),
]
colors = ['#DCEAF7', '#E8F3E8', '#F8EACB', '#F6D9D5', '#E6DDF4', '#DCEAF7']
for (x,y,w,h,label), color in zip(boxes, colors):
    patch = FancyBboxPatch((x,y), w,h, boxstyle='round,pad=0.03,rounding_size=0.05',
                           linewidth=1.0, edgecolor='#2F3B45', facecolor=color)
    ax.add_patch(patch)
    ax.text(x+w/2, y+h/2, label, ha='center', va='center', fontsize=8)
for i in range(len(boxes)-1):
    x1 = boxes[i][0] + boxes[i][2]
    x2 = boxes[i+1][0]
    ax.add_patch(FancyArrowPatch((x1+0.04,2.0),(x2-0.04,2.0), arrowstyle='-|>',
                                 mutation_scale=10, linewidth=0.9, color='#455A64'))
# Feedback path as an explicit routed polyline: down from the last box,
# across below everything, then up into the first box (no arc ambiguity).
ax.plot([9.55, 9.55], [1.40, 0.75], linestyle='--', color='#607D8B', linewidth=0.8)
ax.plot([9.55, 0.65], [0.75, 0.75], linestyle='--', color='#607D8B', linewidth=0.8)
ax.plot([0.65, 0.65], [0.75, 1.32], linestyle='--', color='#607D8B', linewidth=0.8)
ax.add_patch(FancyArrowPatch((0.65,1.30),(0.65,1.43), arrowstyle='-|>',
                             mutation_scale=10, linewidth=0.8, color='#607D8B'))
ax.text(5.1, 0.42, 'Feedback loop repeats until convergence or patience limit',
        ha='center', va='center', fontsize=8, color='#455A64')
ax.text(5.1, 3.45, 'Trusted parent: manifests, task ledger, checkpoints, and protected test boundary',
        ha='center', va='center', fontsize=8.5, fontweight='bold', color='#263238')
fig.tight_layout(pad=0.2)
fig.savefig(out/'fig1_workflow.pdf', bbox_inches='tight')
fig.savefig(out/'fig1_workflow.png', dpi=180, bbox_inches='tight')
print('wrote', out/'fig1_workflow.pdf')
