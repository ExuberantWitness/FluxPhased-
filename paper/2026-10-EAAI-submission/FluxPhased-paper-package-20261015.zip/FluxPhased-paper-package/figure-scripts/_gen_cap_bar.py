"""Regenerate fig17_cap_tdmpc.pdf with the Nature (ggsci npg) palette."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(r'E:\DATA\vscode\RADAR_AGENT_EXECUTION_PACKAGE_2')
BASE = ROOT / 'campaigns' / 'cap_tdmpc'
FIGS = ROOT / 'paper_eaai' / 'figures'

ARMS = ['default', 'agent', 'random', 'llm_nodiag']
# ggsci NPG (Nature Publishing Group) palette
COLORS = {'default': '#8491B4', 'agent': '#E64B35', 'random': '#00A087',
          'llm_nodiag': '#3C5488'}
LABELS = {'default': 'Default CEM', 'agent': 'Agent (diagnosis)',
          'random': 'Random mutation', 'llm_nodiag': 'LLM (no diagnosis)'}

data = {}
for arm in ARMS:
    for f in sorted((BASE / arm).glob('*/results_*.json')):
        d = json.loads(f.read_text())
        data.setdefault(f"{d['domain']}:{d['task']}", {})[arm] = d['best_reward']

domains = sorted(data.keys())
short = {
    'cartpole:balance': 'cartpole\nbal.', 'cartpole:swingup': 'cartpole\nsw.-up',
    'cheetah:run': 'cheetah\nrun', 'finger:spin': 'finger\nspin',
    'finger:turn_easy': 'finger\nturn-ez', 'fish:swim': 'fish\nswim',
    'fish:upright': 'fish\nupright', 'hopper:hop': 'hopper\nhop',
    'humanoid:run': 'humanoid\nrun', 'humanoid:stand': 'humanoid\nstand',
    'manipulator:bring_ball': 'manip.\nbring', 'pendulum:swingup': 'pendulum\nsw.-up',
    'quadruped:run': 'quadruped\nrun', 'quadruped:walk': 'quadruped\nwalk',
    'reacher:hard': 'reacher\nhard', 'walker:run': 'walker\nrun',
}

fig, (ax, axm) = plt.subplots(1, 2, figsize=(13.5, 3.6),
                              gridspec_kw={'width_ratios': [4.6, 1.0]})

x = np.arange(len(domains))
w = 0.2
for i, arm in enumerate(ARMS):
    vals = [data[dm][arm] for dm in domains]
    ax.bar(x + (i - 1.5) * w, vals, width=w * 0.92, color=COLORS[arm],
           edgecolor='white', linewidth=0.4, label=LABELS[arm])
ax.set_xticks(x)
ax.set_xticklabels([short.get(dm, dm) for dm in domains], fontsize=6.5)
ax.set_ylabel('Best reward (3 candidates)', fontsize=9)
ax.grid(axis='y', alpha=0.2)
ax.set_axisbelow(True)
ax.legend(fontsize=8, ncol=4, loc='lower left', bbox_to_anchor=(0.0, 1.01),
          frameon=False, borderaxespad=0.0)

# Summary panel: mean over 16 domains
means = [np.mean([data[dm][arm] for dm in domains]) for arm in ARMS]
bars = axm.bar(np.arange(4), means, width=0.62,
               color=[COLORS[a] for a in ARMS], edgecolor='white', linewidth=0.4)
axm.set_xticks(np.arange(4))
axm.set_xticklabels(['def.', 'agent', 'rand.', 'nodiag'], fontsize=8)
axm.set_title('Mean over\n16 domains', fontsize=9, fontweight='bold')
axm.set_ylim(95, 118)
axm.grid(axis='y', alpha=0.2)
axm.set_axisbelow(True)
for b, m in zip(bars, means):
    axm.text(b.get_x() + b.get_width() / 2, m + 0.4, f'{m:.1f}',
             ha='center', fontsize=8, fontweight='bold')

fig.tight_layout()
fig.savefig(str(FIGS / 'fig17_cap_tdmpc.pdf'), dpi=150, bbox_inches='tight')
print('fig17_cap_tdmpc.pdf regenerated; means:',
      {a: round(m, 1) for a, m in zip(ARMS, means)})
