"""Generate additional figures for the EAAI paper Chinese version."""
import json, math, statistics as st
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

CAMPAIGN = Path(r'E:\DATA\vscode\RADAR_AGENT_EXECUTION_PACKAGE_2\campaigns\eaai_recipe_v1')
FIGS = Path(r'E:\DATA\vscode\RADAR_AGENT_EXECUTION_PACKAGE_2\paper_eaai\figures')
FIGS.mkdir(exist_ok=True)
plt.rcParams.update({'font.size': 9, 'axes.grid': True, 'grid.alpha': 0.3})


def fig8_environment():
    """Task-level radar-jammer environment schematic."""
    fig, ax = plt.subplots(figsize=(6, 4))
    # Radar positions
    for az, label in [(20, '$R_1$'), (-20, '$R_2$')]:
        x, y = 0.8*math.cos(math.radians(az)), 0.8*math.sin(math.radians(az))
        ax.scatter(x, y, c='blue', s=200, marker='^', zorder=5)
        ax.annotate(label, (x, y), textcoords="offset points", xytext=(8, 8), fontsize=11)
    # Jammer positions
    for az, label in [(60, '$J_1$'), (-60, '$J_2$')]:
        x, y = 0.8*math.cos(math.radians(az)), 0.8*math.sin(math.radians(az))
        ax.scatter(x, y, c='red', s=200, marker='s', zorder=5)
        ax.annotate(label, (x, y), textcoords="offset points", xytext=(8, -12), fontsize=11)
    # Beam grid (5x5) from R1
    for az_i in range(5):
        for el_i in range(5):
            az = -60 + az_i * 30
            el = -30 + el_i * 15
            r = 0.45
            bx = r * math.cos(math.radians(az)) * math.cos(math.radians(el)) + 0.8*math.cos(math.radians(20))
            by = r * math.sin(math.radians(az)) * math.cos(math.radians(el)) + 0.8*math.sin(math.radians(20))
            ax.plot([0.8*math.cos(math.radians(20)), bx], [0.8*math.sin(math.radians(20)), by],
                    'b-', alpha=0.15, linewidth=0.5)
    # Link lines
    for raz in [20, -20]:
        for jaz in [60, -60]:
            x1, y1 = 0.8*math.cos(math.radians(raz)), 0.8*math.sin(math.radians(raz))
            x2, y2 = 0.8*math.cos(math.radians(jaz)), 0.8*math.sin(math.radians(jaz))
            ax.plot([x1, x2], [y1, y2], 'k--', alpha=0.3, linewidth=0.8)
    ax.set_xlim(-1.1, 1.1); ax.set_ylim(-1.1, 1.1)
    ax.set_aspect('equal')
    ax.set_xlabel('East (km)'); ax.set_ylabel('North (km)')
    ax.set_title('Task-Level Radar–Jammer Environment Geometry')
    blue_patch = mpatches.Patch(color='blue', label='Radar sites (±20°)')
    red_patch = mpatches.Patch(color='red', label='Jammer sites (±60°)')
    ax.legend(handles=[blue_patch, red_patch], loc='lower left')
    fig.tight_layout(); fig.savefig(str(FIGS / 'fig8_environment.pdf'), dpi=150); plt.close()


def fig9_recipe_space():
    """Recipe-A bounded parameter space visualization."""
    fields = ['actor_lr', 'critic_lr', 'clip', 'gae_lambda', 'entropy_init',
              'entropy_min', 'anneal_frac', 'value_coef', 'grad_clip', 'target_kl']
    lo = [1e-5, 3e-4, 0.1, 0.90, 0.0, 0.0, 0.1, 0.1, 0.1, 0.005]
    hi = [1e-4, 3e-3, 0.3, 0.99, 0.02, 0.02, 0.99, 1.0, 2.0, 0.1]
    # Wide-box winner values
    winner = [3e-4, 1e-3, 0.2, 0.95, 0.01, 0.001, 0.3, 0.5, 0.5, 0.02]
    # Original box winner
    orig = [1e-4, 1e-3, 0.15, 0.95, 0.01, 0.0, 0.8, 0.3, 1.0, 0.04]

    fig, ax = plt.subplots(figsize=(7, 4))
    x = np.arange(len(fields))
    width = 0.35
    ax.barh(x - width/2, [np.log10(h+1e-10)-np.log10(l+1e-10) for l, h in zip(lo, hi)], width,
            left=[np.log10(l+1e-10) for l, h in zip(lo, hi)], alpha=0.3, color='gray',
            label='Search box (log scale)')
    ax.scatter([np.log10(w+1e-10) for w in winner], x, c='red', s=80, marker='D',
               zorder=5, label='Wide-box winner')
    ax.scatter([np.log10(o+1e-10) for o in orig], x, c='blue', s=80, marker='o',
               zorder=5, label='Original-box winner')
    ax.set_yticks(x, [f.replace('_', '\n') for f in fields], fontsize=7)
    ax.set_xlabel('log$_{10}$(value)')
    ax.set_title('Recipe-A Bounded Parameter Space and Winner Positions')
    ax.legend(loc='lower right')
    ax.axvline(np.log10(3e-4), color='red', linestyle='--', alpha=0.5, label='Wide-box cap')
    fig.tight_layout(); fig.savefig(str(FIGS / 'fig9_recipe_space.pdf'), dpi=150); plt.close()


def fig10_crossval():
    """Cross-domain validation comparison bar chart."""
    arms = ['Random', 'Static-prompt', 'Dynamic-retrieval']
    data = [[0.8, 1.0, 0.5], [2.0, 1.0, 2.3], [1.8, 0.9, 2.3]]
    colors = ['gray', 'steelblue', 'coral']

    fig, ax = plt.subplots(figsize=(6, 3.5))
    x = np.arange(3)
    for i, (arm, vals, color) in enumerate(zip(arms, data, colors)):
        bars = ax.bar(x + i*0.25, vals, 0.25, label=arm, color=color, alpha=0.8)
        ax.errorbar(x + i*0.25, [np.mean(vals)]*3, yerr=[np.std(vals)]*3,
                    fmt='none', capsize=3, color='black')
    ax.set_xticks(x + 0.25, arms)
    ax.set_ylabel('Best terminal reward (↑)')
    ax.set_title('Cross-Domain Validation: HalfCheetah-v4 Robotics')
    ax.legend()
    fig.tight_layout(); fig.savefig(str(FIGS / 'fig10_crossval.pdf'), dpi=150); plt.close()


def fig11_box_saturation():
    """Field-level boundary saturation audit."""
    fields = ['actor_lr', 'critic_lr', 'entropy_min', 'clip', 'gae_lambda',
              'entropy_init', 'anneal_frac', 'value_coef', 'grad_clip',
              'target_kl', 'epochs', 'minibatch']
    at_bound = [10, 2, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    n = [10] * 12

    fig, ax = plt.subplots(figsize=(7, 3.5))
    colors = ['red' if a == n_ else ('orange' if a > 0 else 'lightgreen')
              for a, n_ in zip(at_bound, n)]
    ax.barh(range(len(fields)), at_bound, color=colors, edgecolor='black', linewidth=0.5)
    ax.set_yticks(range(len(fields)), [f.replace('_', '\n') for f in fields], fontsize=7)
    ax.set_xlabel('Times at declared boundary (out of 10)')
    ax.set_title('Field-Level Boundary Saturation Audit')
    ax.axvline(10, color='red', linestyle='--', alpha=0.5)
    ax.text(10.2, 0, 'CEILING', fontsize=7, color='red', va='center')
    fig.tight_layout(); fig.savefig(str(FIGS / 'fig11_box_saturation.pdf'), dpi=150); plt.close()


def fig12_scripted():
    """Scripted baseline comparison."""
    winners = ['Wide-box', 'Boundary', 'Literature\nmedian', 'Random', 'BOHB']
    vs_random = [0.0824, 0.0931, 0.0832, 0.1064, 0.0942]
    vs_stare = [0.2289, 0.2160, 0.2462, 0.2352, 0.3477]

    fig, ax = plt.subplots(figsize=(6, 3.5))
    x = np.arange(len(winners))
    ax.bar(x - 0.15, vs_random, 0.3, label='vs Random jammer', color='steelblue', alpha=0.8)
    ax.bar(x + 0.15, vs_stare, 0.3, label='vs Stare jammer', color='coral', alpha=0.8)
    ax.set_xticks(x, winners, fontsize=8)
    ax.set_ylabel('Terminal drop (↓)')
    ax.set_title('Trained Winners vs Scripted Heuristics')
    ax.legend()
    ax.axhline(0.2958, color='red', linestyle='--', alpha=0.5)
    ax.text(4.2, 0.30, 'vs trained pool', fontsize=7, color='red')
    fig.tight_layout(); fig.savefig(str(FIGS / 'fig12_scripted.pdf'), dpi=150); plt.close()


def fig13_gepa_evolution():
    """GEPA prompt evolution diagram (clean routing, no arrow/box overlap)."""
    fig, ax = plt.subplots(figsize=(7, 3))
    ax.axis('off')
    # Two rows of three boxes with wide horizontal gaps; box edges are exact
    # (no padding), and every arrow endpoint sits strictly outside the boxes.
    top_y, bot_y, w, h = 0.66, 0.16, 0.22, 0.24
    xs = [0.03, 0.335, 0.64]
    boxes = [
        (xs[0], top_y, 'Audit Trail\n(12 trajectories)'),
        (xs[1], top_y, 'GEPA Reflection\n(3 variants)'),
        (xs[2], top_y, 'Probe Selection\n(2 cand × 3 var)'),
        (xs[0], bot_y, 'Winner Prompt\n(median 0.3647)'),
        (xs[1], bot_y, 'Full Search\n(3 seeds × 4 cand)'),
        (xs[2], bot_y, 'Improvement\n(mean −2.7%)'),
    ]
    pad = 0.012  # visual padding handled by FancyBboxPatch; endpoints use pad + gap
    for x, y, label in boxes:
        color = 'lightyellow' if y == top_y else 'lightcyan'
        ax.add_patch(mpatches.FancyBboxPatch((x + pad, y + pad), w - 2 * pad, h - 2 * pad,
                     boxstyle="round,pad=0.008", facecolor=color, edgecolor='black'))
        ax.text(x + w / 2, y + h / 2, label, ha='center', va='center', fontsize=8)

    def harrow(i, j):  # horizontal arrow between boxes i -> j on the same row
        y = boxes[i][1] + h / 2
        x0 = boxes[i][0] + w + 1.5 * pad
        x1 = boxes[j][0] - 1.5 * pad
        ax.annotate('', xy=(x1, y), xytext=(x0, y),
                    arrowprops=dict(arrowstyle='->', color='black',
                                    shrinkA=0, shrinkB=0))

    for i in (0, 1):
        harrow(i, i + 1)
    for i in (3, 4):
        harrow(i, i + 1)

    # Elbow connector: down from box2 (top middle), across, up-into box4 (bottom left)
    x_start = boxes[1][0] + w / 2          # below GEPA Reflection
    y_mid = 0.545                            # gap between rows
    x_end = boxes[3][0] + w / 2            # above Winner Prompt
    ax.plot([x_start, x_start], [boxes[1][1] - 1.5 * pad, y_mid], color='black', lw=0.9)
    ax.plot([x_start, x_end], [y_mid, y_mid], color='black', lw=0.9)
    ax.annotate('', xy=(x_end, boxes[3][1] + h + 1.5 * pad), xytext=(x_end, y_mid),
                arrowprops=dict(arrowstyle='->', color='black', shrinkA=0, shrinkB=0))

    ax.set_xlim(0, 0.9); ax.set_ylim(0, 1)
    ax.set_title('GEPA Reflective Prompt Evolution Pipeline')
    fig.tight_layout(); fig.savefig(str(FIGS / 'fig13_gepa.pdf'), dpi=150); plt.close()


def fig14_cost_efficiency():
    """Cost-efficiency comparison across arms."""
    arms = ['Random\n(12 cand)', 'BOHB\n(12 equiv)', 'Dynamic\n(4-6 cand)',
            'Wide-box\n(4-6 cand)', 'GEPA\n(4-6 cand)']
    budget = [12, 12, 5, 5, 5]
    best = [0.3808, 0.3983, 0.3791, 0.3606, 0.3647]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7, 3))
    colors = ['gray', 'gray', 'steelblue', 'coral', 'gold']
    ax1.bar(range(5), best, color=colors, edgecolor='black', linewidth=0.5)
    ax1.set_xticks(range(5), arms, fontsize=6.5)
    ax1.set_ylabel('Median best drop (↓)')
    ax1.set_title('Search Quality')

    ax2.bar(range(5), budget, color=colors, edgecolor='black', linewidth=0.5)
    ax2.set_xticks(range(5), arms, fontsize=6.5)
    ax2.set_ylabel('Candidate budget')
    ax2.set_title('Budget Usage')
    fig.tight_layout(); fig.savefig(str(FIGS / 'fig14_cost_efficiency.pdf'), dpi=150); plt.close()


def fig15_audit_trail():
    """Audit trail architecture (information flow)."""
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.axis('off')
    # Trusted boundary
    ax.add_patch(mpatches.FancyBboxPatch((0.05, 0.1), 0.45, 0.8,
                 boxstyle="round,pad=0.03", facecolor='lightyellow',
                 edgecolor='black', linestyle='--', linewidth=2))
    ax.text(0.27, 0.93, 'Trusted Boundary', ha='center', fontsize=9,
            fontweight='bold', style='italic')
    # Components inside
    for y, label in [(0.75, 'Environment\n(S7 / HalfCheetah)'), (0.5, 'Evaluator\n(canonical)'),
                     (0.25, 'Evidence Ledger\n(immutable)')]:
        ax.add_patch(mpatches.FancyBboxPatch((0.10, y-0.08), 0.35, 0.16,
                     boxstyle="round,pad=0.01", facecolor='white', edgecolor='black'))
        ax.text(0.27, y, label, ha='center', va='center', fontsize=7)
    # Components outside
    for y, label in [(0.75, 'Retriever\n(arXiv API)'), (0.5, 'Local LLM\n(Qwen 4B)')]:
        ax.add_patch(mpatches.FancyBboxPatch((0.60, y-0.08), 0.30, 0.16,
                     boxstyle="round,pad=0.01", facecolor='lightcyan', edgecolor='black'))
        ax.text(0.75, y, label, ha='center', va='center', fontsize=7)
    # Arrows
    ax.annotate('', xy=(0.60, 0.75), xytext=(0.45, 0.75),
                arrowprops=dict(arrowstyle='->', color='blue'))
    ax.annotate('', xy=(0.60, 0.50), xytext=(0.45, 0.50),
                arrowprops=dict(arrowstyle='->', color='blue'))
    ax.annotate('', xy=(0.45, 0.25), xytext=(0.60, 0.42),
                arrowprops=dict(arrowstyle='->', color='red', linestyle='--'))
    ax.text(0.53, 0.35, 'proposals\n(as data only)', fontsize=6, color='red',
            ha='center', style='italic')
    ax.text(0.53, 0.68, 'diagnosis\nquery', fontsize=6, color='blue',
            ha='center', style='italic')
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.set_title('Information Flow Architecture')
    fig.tight_layout(); fig.savefig(str(FIGS / 'fig15_audit_trail.pdf'), dpi=150); plt.close()


if __name__ == '__main__':
    fig8_environment()
    fig9_recipe_space()
    fig10_crossval()
    fig11_box_saturation()
    fig12_scripted()
    fig13_gepa_evolution()
    fig14_cost_efficiency()
    fig15_audit_trail()
    print('8 additional figures generated')
