"""Neutral target pool for the MFR-IQ env (M1).

N_max slotted targets with Poisson spawn, CV motion + heading jitter, despawn
on region exit or age. Per-target RCS (log-normal) and emitter flag. All draws
use a per-call torch.Generator so reset(seed) is bit-reproducible.

Shapes (E = n_envs, N = N_max):
    pos[E,N,2], vel[E,N,2], alive[E,N], emitter[E,N], rcs[E,N], age[E,N]
"""

from __future__ import annotations

import math
import torch


class TargetPool:
    def __init__(
        self,
        E: int,
        N_max: int = 12,
        lam_spawn: float = 0.02,       # Poisson rate per step per env (calibrate)
        region_half_m: float = 15000.0,
        dt: float = 0.1,
        v_min_mps: float = 50.0,
        v_max_mps: float = 300.0,
        heading_jitter_rad: float = 0.05,   # per-step heading Wiener std
        max_age_steps: int = 450,           # 45 s at dt=0.1
        emitter_frac: float = 0.30,
        rcs_median_m2: float = 1.0,
        rcs_lognormal_sigma: float = 0.5,
        device: str = "cuda",
        gen: torch.Generator = None,
        jammer_frac_of_emitters: float = 0.0,
    ):
        self.E = int(E)
        self.N = int(N_max)
        self.lam_spawn = float(lam_spawn)
        self.region_half = float(region_half_m)
        self.dt = float(dt)
        self.v_min = float(v_min_mps)
        self.v_max = float(v_max_mps)
        self.heading_jitter = float(heading_jitter_rad)
        self.max_age = int(max_age_steps)
        self.emitter_frac = float(emitter_frac)
        self.rcs_median = float(rcs_median_m2)
        self.rcs_sigma = float(rcs_lognormal_sigma)
        self.jammer_frac_of_emitters = float(jammer_frac_of_emitters)
        self.device = torch.device(device)
        self.gen = gen if gen is not None else torch.Generator(device=self.device)
        self.reset()

    def reset(self):
        E, N, dev = self.E, self.N, self.device
        self.pos = torch.zeros(E, N, 2, device=dev)
        self.vel = torch.zeros(E, N, 2, device=dev)
        self.alive = torch.zeros(E, N, dtype=torch.bool, device=dev)
        self.emitter = torch.zeros(E, N, dtype=torch.bool, device=dev)
        self.jammer = torch.zeros(E, N, dtype=torch.bool, device=dev)
        self.rcs = torch.full((E, N), self.rcs_median, device=dev)
        self.age = torch.zeros(E, N, device=dev)

    def _spawn(self, mask: torch.Tensor):
        """Spawn targets at slots where mask is True. mask: [E, N]."""
        E, N, dev = self.E, self.N, self.device
        n = int(mask.sum().item())
        if n == 0:
            return
        # Spawn on region boundary ring, heading inward-ish
        ang = torch.rand(E, N, device=dev, generator=self.gen) * 2 * math.pi
        r = torch.full((E, N), self.region_half * 0.95, device=dev)
        pos_new = torch.stack([r * torch.cos(ang), r * torch.sin(ang)], dim=-1)
        # Heading: toward region center + uniform jitter ±90°
        inward = ang + math.pi
        heading = inward + (torch.rand(E, N, device=dev, generator=self.gen) - 0.5) * math.pi
        speed = self.v_min + torch.rand(E, N, device=dev, generator=self.gen) * (self.v_max - self.v_min)
        vel_new = torch.stack([speed * torch.cos(heading), speed * torch.sin(heading)], dim=-1)
        rcs_new = self.rcs_median * torch.exp(
            self.rcs_sigma * torch.randn(E, N, device=dev, generator=self.gen)
        )
        emitter_new = torch.rand(E, N, device=dev, generator=self.gen) < self.emitter_frac
        jammer_new = emitter_new & (
            torch.rand(E, N, device=dev, generator=self.gen) < self.jammer_frac_of_emitters
        )

        self.pos = torch.where(mask.unsqueeze(-1), pos_new, self.pos)
        self.vel = torch.where(mask.unsqueeze(-1), vel_new, self.vel)
        self.rcs = torch.where(mask, rcs_new, self.rcs)
        self.emitter = torch.where(mask, emitter_new, self.emitter)
        self.jammer = torch.where(mask, jammer_new, self.jammer)
        self.age = torch.where(mask, torch.zeros_like(self.age), self.age)
        self.alive = self.alive | mask

    def step(self):
        """Advance one dt: spawn (Poisson), move (CV + heading jitter), despawn."""
        E, N, dev = self.E, self.N, self.device

        # Age + despawn (region exit or max age)
        self.age = self.age + torch.where(self.alive, torch.ones_like(self.age), torch.zeros_like(self.age))
        in_region = (self.pos.abs() <= self.region_half).all(dim=-1)
        too_old = self.age > self.max_age
        self.alive = self.alive & in_region & (~too_old)

        # Motion: heading Wiener jitter + CV advance
        jitter = torch.randn(E, N, device=dev, generator=self.gen) * self.heading_jitter
        speed = self.vel.norm(dim=-1).clamp(min=1e-6)
        heading = torch.atan2(self.vel[..., 1], self.vel[..., 0]) + jitter
        vel_new = torch.stack([speed * torch.cos(heading), speed * torch.sin(heading)], dim=-1)
        self.vel = torch.where(self.alive.unsqueeze(-1), vel_new, self.vel)
        self.pos = self.pos + self.vel * self.dt

        # Spawn: Poisson per step per env into free slots
        n_spawn = torch.poisson(
            torch.full((E,), self.lam_spawn, device=dev), generator=self.gen
        ).long()  # [E]
        free = ~self.alive
        # Rank free slots per env; spawn into the first n_spawn[e] free slots
        free_rank = free.long().cumsum(dim=1)  # [E, N]
        spawn_mask = free & (free_rank <= n_spawn.unsqueeze(1))
        self._spawn(spawn_mask)

    # Convenience views ---------------------------------------------------
    def n_alive(self) -> torch.Tensor:
        return self.alive.sum(dim=1)  # [E]

    def emitter_pos(self) -> tuple:
        """(pos[E,N,2], mask[E,N]) of alive emitters."""
        return self.pos, (self.alive & self.emitter)
