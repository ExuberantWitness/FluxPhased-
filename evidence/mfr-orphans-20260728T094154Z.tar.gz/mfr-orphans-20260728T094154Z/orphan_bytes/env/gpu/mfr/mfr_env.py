"""MFR-IQ env: single-team multifunction radar with K digital subarrays.

One fully-digital MFR (K=4 co-located subarrays, each an independent agent with
its own beam/freq/emission) schedules Wang-2025 task types over a neutral target
pool. Task success is decided by IQ physics (SNR → detect → IMM-PDAF →
trace_P / JNR), not abstract rectangles.

Physics scalars are copied verbatim from twoteam_env.py ctor defaults
(twoteam_env.py:62-144) per approved plan §2.1. mfr-specific values:
  region ±15 km, range_max 25 km (region diagonal ≈ 21.2 km), 72 search cells
  (5°/cell), k_max=24 (K·N real-candidate headroom).

M1 scope: target pool + physics chain + obs skeleton (task blocks zeroed).
M2 attaches TaskLayer and the task_select action interface.
"""

from __future__ import annotations

import math
import sys

import torch

sys.path.insert(0, "/home/ubuntu/CODE/FluxPhased-")

from env.gpu.twoteam.iq_interference import IqInterference
from env.gpu.twoteam.detection import detect
from env.gpu.twoteam.tracker import BatchedIMMPDAF
from env.gpu.mfr.target_pool import TargetPool
from env.gpu.mfr.task_layer import (
    TaskLayer, N_TYPES,
    TYPE_TRACK_PRECISE, TYPE_IFF, TYPE_TRACK_NORMAL,
    TYPE_SEARCH_HI, TYPE_JAM, TYPE_COMM, TYPE_SEARCH_LO,
    F_TYPE, F_P, F_TAUD, F_TAUW, F_ETA, F_PROG, F_TGT, F_SECTOR, F_R,
)
from env.gpu.mfr.jammer import (
    JammerField, JAM_POLICY_NONE, JAM_POLICIES,
)


# Physics defaults verbatim from twoteam_env.py:62-144 (approved plan §2.1).
PHYS_DEFAULTS = dict(
    dt=0.1,
    episode_steps=600,
    sigma_q=2.0,
    range_sigma_m=0.05,
    n_subarrays=25,
    comm_threshold=0.10,
    fc_hz=10e9,
    channel_bw_hz=10e6,
    noise_figure_db=5.0,
    P_per_subarray_W=5.0,
    aperture_D_m=0.4,
    aperture_eta=0.6,
    tau_track=4.0,
    freq_hop_max=8.0,
    detect_threshold_db=15.0,
    detect_width_db=3.0,
    p_fa=1e-6,
    beam_width_rad=0.075,
    sigma_rcs_m2=1.0,
    coherent_processing_gain_db=20.0,
)

# mfr-specific (approved plan §2.1, deviations from twoteam documented)
MFR_DEFAULTS = dict(
    region_half_m=15000.0,
    range_max_m=25000.0,       # deviation: twoteam 8000 (8 km map); mfr region diag ≈ 21.2 km
    n_search_cells=72,         # deviation: twoteam 84 (4.3°); mfr 72 (5°/cell) per plan §2.1
    k_max=24,                  # deviation: twoteam 8; mfr K·N real-candidate headroom
)

OBS_DIM = 4 + 8 + 8 * 9 + 12 * 6 + 3  # = 159 per agent (Phase A)
OBS_DIM_JAMMER = OBS_DIM + 4 * 3 + 2 * 3  # = 177 (Phase B: 4 pool-jammer×3 + 2 off-board×3)


class MfrVecEnv:
    """Vectorized MFR-IQ scheduling env.

    Agent interface (M2): step(actions[E,K] int64) — discrete task_select,
    0 = idle, 1..8 = exposed queue slot. Env auto-servos beam/emission/alloc
    from the bound task (plan §4.4).

    M1 exposes physics_step(beam_az, alloc, emission_on, hop_rate) for direct
    physics testing (T2/T3).
    """

    n_teams = 1  # tracker shim contract

    def __init__(
        self,
        n_envs: int = 32,
        K: int = 4,
        N_max: int = 12,
        device: str = "cuda",
        seed: int = 0,
        task_cfg=None,
        load_factor: float = 1.5,
        lam_spawn: float = 0.017,  # calibrated: 256-env × 600-step steady-state mean alive = 7.1 ∈ [6,8]
        drop_penalty_scale: float = 1.0,  # RL shaping: ≥1 amplifies Wang's -(2+P/7)
        # Phase B (adversarial jammers); defaults preserve Phase A bit-identical.
        jammer_policy: str = JAM_POLICY_NONE,
        n_offboard_jammers: int = 0,
        pool_jammer_frac_of_emitters: float = 0.0,
        jammer_pow_W: float = 50.0,
        ew_detect_db: float = 20.0,
        ew_cooldown_steps: int = 60,
        enable_antijam_action: bool = False,
        **physics_overrides,
    ):
        self.E = int(n_envs)
        self.K = int(K)
        self.N_max = int(N_max)
        self.device = torch.device(device)
        self.seed = int(seed)
        self.load_factor = float(load_factor)
        self.drop_penalty_scale = float(drop_penalty_scale)

        # Phase B config
        self.jammer_policy = str(jammer_policy)
        self.has_jammers = self.jammer_policy != JAM_POLICY_NONE and (
            pool_jammer_frac_of_emitters > 0.0 or n_offboard_jammers > 0
        )
        self.n_offboard_jammers = int(n_offboard_jammers) if self.has_jammers else 0
        self.pool_jammer_frac_of_emitters = (
            float(pool_jammer_frac_of_emitters) if self.has_jammers else 0.0
        )
        self.jammer_pow_W = float(jammer_pow_W)
        self.ew_detect_db = float(ew_detect_db)
        self.ew_cooldown_steps = int(ew_cooldown_steps)
        self.enable_antijam_action = bool(enable_antijam_action) and self.has_jammers
        self.hop_rate_max = 8.0  # antijam subarray spread-spectrum processing gain
        # action space: 9 (Phase A) or 10 (Phase B with antijam)
        self.n_act = 10 if self.enable_antijam_action else 9
        self.obs_dim = OBS_DIM_JAMMER if self.has_jammers else OBS_DIM

        p = dict(PHYS_DEFAULTS)
        p.update(MFR_DEFAULTS)
        p.update(physics_overrides)
        for k, v in p.items():
            setattr(self, k, v)

        # Tracker-shim attributes (BatchedIMMPDAF duck-type contract)
        self.n_radars_per_team = self.N_max  # track slots = target slots

        self.gen = torch.Generator(device=self.device)
        self.gen.manual_seed(self.seed)

        self.pool = TargetPool(
            E=self.E, N_max=self.N_max, lam_spawn=lam_spawn,
            region_half_m=self.region_half_m, dt=self.dt,
            rcs_median_m2=self.sigma_rcs_m2, device=str(self.device),
            gen=self.gen,
            jammer_frac_of_emitters=self.pool_jammer_frac_of_emitters,
        )

        self.iq = IqInterference(
            fc_hz=self.fc_hz, channel_bw_hz=self.channel_bw_hz,
            noise_figure_db=self.noise_figure_db,
            P_per_subarray_W=self.P_per_subarray_W,
            aperture_D_m=self.aperture_D_m, aperture_eta=self.aperture_eta,
            n_subarrays=self.n_subarrays,
        )

        self.task_layer = TaskLayer(
            E=self.E, K=self.K, load_factor=self.load_factor,
            device=str(self.device), gen=self.gen,
        )

        if self.has_jammers:
            self.jammer = JammerField(
                E=self.E, N_pool=self.N_max, n_offboard=self.n_offboard_jammers,
                policy=self.jammer_policy, jammer_pow_W=self.jammer_pow_W,
                region_half_m=self.region_half_m, fc_hz=self.fc_hz,
                channel_bw_hz=self.channel_bw_hz,
                ew_detect_db=self.ew_detect_db,
                ew_cooldown_steps=self.ew_cooldown_steps,
                device=str(self.device), gen=self.gen,
            )
        else:
            self.jammer = None

        # State allocated in reset()
        self.reset()

    # ------------------------------------------------------------------
    def reset(self) -> torch.Tensor:
        E, K, N, dev = self.E, self.K, self.N_max, self.device
        self.gen.manual_seed(self.seed)
        self.pool.reset()
        self.step_idx = torch.zeros(E, dtype=torch.long, device=dev)

        # Subarrays co-located at origin
        self.radar_pos = torch.zeros(E, 1, K, 2, device=dev)
        self.beam_az = torch.zeros(E, 1, K, device=dev)
        self.emission_on = torch.zeros(E, 1, K, dtype=torch.bool, device=dev)
        self.alloc = torch.zeros(E, 1, K, 4, device=dev)
        self.hop_rate = torch.ones(E, 1, K, device=dev)

        # Tracker state (shim contract with BatchedIMMPDAF)
        self.tracker_x = torch.zeros(E, 1, N, 4, device=dev)
        self.tracker_P = (
            torch.eye(4, device=dev).expand(E, 1, N, 4, 4).clone()
        )
        self.tracker_initialized = torch.zeros(E, 1, N, dtype=torch.bool, device=dev)
        # init_P=400 (σ_pos=20 m): fast pool targets (≤300 m/s, 10 m–30 m/step)
        # must pass the 5σ PDAF gate on the first post-init update; twoteam's
        # default 1.0 is calibrated for slow radar platforms.
        self.tracker = BatchedIMMPDAF(self, init_P=400.0)

        self._searched_cells = torch.zeros(E, K, self.n_search_cells, dtype=torch.bool, device=dev)
        self.bound_task = torch.full((E, K), -1, dtype=torch.long, device=dev)
        self.last_jnr_at_sub = torch.zeros(E, K, device=dev)

        self.task_layer.reset()
        return self._build_obs()

    # ------------------------------------------------------------------
    def physics_step(self, beam_az, alloc, emission_on, hop_rate=None, antijam_mask=None):
        """Run one physics step with explicit controls (M1 test interface).

        beam_az[E,1,K] rad, alloc[E,1,K,4] (softmax'd inside), emission_on[E,1,K] bool.
        antijam_mask[E,K] bool (Phase B): subarray selects action 9 → frequency-hop
            suppresses incoming jammer JNR by 1/hop_rate_max (= 1/8) this step.

        Returns dict with detections, jnr_at_sub[E,K], jnr_at_emitters[E,N],
        sigma_meas[E,1,N], jnr_from_pool_db[E,N_pool], jnr_from_off_db[E,J].
        """
        E, K, N, dev = self.E, self.K, self.N_max, self.device
        if hop_rate is None:
            hop_rate = torch.ones(E, 1, K, device=dev)
        alloc = torch.softmax(alloc, dim=-1)
        self.beam_az = beam_az
        self.alloc = alloc
        self.emission_on = emission_on
        if antijam_mask is None:
            antijam_mask = torch.zeros(E, K, dtype=torch.bool, device=dev)

        # JNR nodes (Phase B order): [K subarrays | J off-board | N pool emitters]
        # Off-board and pool-jammer nodes are transmitters only; they do not
        # receive (their victim columns are zeroed in the cross-block mask below).
        emit_mask = self.pool.alive & self.pool.emitter  # [E,N]
        J = self.n_offboard_jammers if self.has_jammers else 0
        n_nodes = K + J + N

        # ---- Build per-node tensors ----
        sub_pos = self.radar_pos.squeeze(1)                    # [E,K,2]
        sub_baz = beam_az.squeeze(1)                            # [E,K]
        sub_alloc = alloc.squeeze(1)                            # [E,K,4]
        sub_em = emission_on.squeeze(1)                         # [E,K]
        sub_hop = hop_rate.squeeze(1)                           # [E,K]
        # Phase B: antijam subarrays hop at max rate (suppresses incoming JNR)
        if antijam_mask.any():
            sub_hop = torch.where(antijam_mask, torch.full_like(sub_hop, 8.0), sub_hop)

        emit_pos = self.pool.pos                                # [E,N,2]
        emit_baz = torch.atan2(-emit_pos[..., 1], -emit_pos[..., 0])

        if J > 0:
            off_pos = self.jammer.off_pos                       # [E,J,2]
            off_baz = torch.atan2(-off_pos[..., 1], -off_pos[..., 0])
            pos_nodes = torch.cat([sub_pos, off_pos, emit_pos], dim=1)
            baz_nodes = torch.cat([sub_baz, off_baz, emit_baz], dim=1)
            alloc_off = torch.zeros(E, J, 4, device=dev)
            # Off-board jammer "alloc" — set its detect/jam flag so f_emit ≠ 0
            # in iq.compute_jnr_matrix (drives D_eff → beamwidth). Use the
            # jammer's own pow/freq via separate node fields below; here alloc
            # only needs to gate emission on.
            alloc_off[..., 2] = 1.0  # mark as jam-mode emitter
            alloc_nodes = torch.cat([sub_alloc, alloc_off, torch.zeros(E, N, 4, device=dev)], dim=1)
            em_off = self.jammer.active_off if self.has_jammers else torch.zeros(E, 0, dtype=torch.bool, device=dev)
            em_nodes = torch.cat([sub_em, em_off, torch.zeros(E, N, dtype=torch.bool, device=dev)], dim=1)
            hop_nodes = torch.cat([sub_hop, torch.ones(E, J, device=dev), torch.ones(E, N, device=dev)], dim=1)
            alive_off = self.jammer.off_alive
            alive_nodes = torch.cat(
                [torch.ones(E, K, dtype=torch.bool, device=dev), alive_off, emit_mask], dim=1
            )
        else:
            pos_nodes = torch.cat([sub_pos, emit_pos], dim=1)
            baz_nodes = torch.cat([sub_baz, emit_baz], dim=1)
            alloc_nodes = torch.cat([sub_alloc, torch.zeros(E, N, 4, device=dev)], dim=1)
            em_nodes = torch.cat([sub_em, torch.zeros(E, N, dtype=torch.bool, device=dev)], dim=1)
            hop_nodes = torch.cat([sub_hop, torch.ones(E, N, device=dev)], dim=1)
            alive_nodes = torch.cat(
                [torch.ones(E, K, dtype=torch.bool, device=dev), emit_mask], dim=1
            )

        # Per-node frequency: subarrays at fc; off-board jammers at policy freq;
        # pool emitters (passive) at fc; pool-upgraded jammers at policy freq.
        freq_nodes = torch.full((E, n_nodes), self.fc_hz, device=dev)
        if J > 0 and self.has_jammers:
            freq_nodes[:, K:K + J] = self.jammer.freq_off
        # Pool-jammer freq (only nonzero when Phase B policy in effect)
        if self.has_jammers and self.pool.jammer.any():
            jam_pool_idx = self.pool.jammer & self.pool.alive
            freq_nodes[:, K + J:].masked_scatter_(
                jam_pool_idx, self.jammer.freq_pool.masked_select(jam_pool_idx)
            )

        # Per-node tx power override for jammers. Subarrays: keep internal
        # (P_per_subarray·n_subarrays·f_emit). Off-board/pool jammers: override
        # with jammer active-power (already scaled by activation mask in
        # JammerField.pow_*) so JNR scales with jammer_pow_W ctor parameter.
        P_tx_override = torch.zeros(E, n_nodes, device=dev)
        if J > 0 and self.has_jammers:
            P_tx_override[:, K:K + J] = self.jammer.pow_off
        if self.has_jammers and self.pool.jammer.any():
            jam_pool_idx = self.pool.jammer & self.pool.alive
            P_tx_override[:, K + J:].masked_scatter_(
                jam_pool_idx, self.jammer.pow_pool.masked_select(jam_pool_idx)
            )

        jnr_full = self.iq.compute_jnr_matrix(
            pos_nodes.unsqueeze(1), baz_nodes.unsqueeze(1), alloc_nodes.unsqueeze(1),
            freq_nodes.unsqueeze(1), em_nodes.unsqueeze(1), hop_nodes.unsqueeze(1),
            alive_nodes.unsqueeze(1),
            P_tx_override_W=P_tx_override.unsqueeze(1),
        ).squeeze(1)  # [E,n_nodes,n_nodes]
        # Node layout: rows/cols indexed as [K subarrays | J off-board | N pool]
        # KEEP:
        #   rows [:K] × cols [K:]       ← subarray → off-board & pool (jam task)
        #   rows [K:K+J] × cols [:K]    ← off-board jammer → subarray (the threat)
        #   rows [K+J: jammer-only] × cols [:K]  ← pool jammer → subarray
        # ZERO: sub SIC, off↔off, off↔pool cross, pool↔pool, non-jammer pool rows.
        jnr_full[:, :K, :K] = 0.0                      # subarray SIC
        if J > 0:
            jnr_full[:, K:K + J, K:K + J] = 0.0        # off↔off
            jnr_full[:, K:K + J, K + J:] = 0.0         # off → pool
            jnr_full[:, K + J:, K:K + J] = 0.0         # pool → off
        jnr_full[:, K + J:, K + J:] = 0.0              # pool → pool (incl. jammers)
        # Non-jammer pool slots are passive victims — zero their rows so they
        # don't appear as interferers. Pool-jammer rows keep their [.., :K] block.
        if self.has_jammers:
            pool_nonjam = ~(self.pool.jammer & self.pool.alive)        # [E,N]
            blk = jnr_full[:, K + J:, :K]                                # [E,N,K]
            jnr_full[:, K + J:, :K] = torch.where(
                pool_nonjam.unsqueeze(-1).expand_as(blk),
                torch.zeros_like(blk), blk,
            )
        else:
            jnr_full[:, K + J:, :K] = 0.0              # Phase A: emitters passive

        # JNR at subarray victims (sum over interferer rows i = rows of col s)
        # Phase B antijam: victim subarray frequency-hops → spread-spectrum
        # processing gain attenuates incoming narrowband jammer by hop_rate_max.
        jnr_at_sub = jnr_full[:, :, :K].sum(dim=1)  # [E,K]
        if antijam_mask.any():
            jnr_at_sub = torch.where(
                antijam_mask, jnr_at_sub / self.hop_rate_max, jnr_at_sub
            )

        # Per-jammer → max-subarray JNR (for EW cue).
        if J > 0:
            jnr_off_to_sub = jnr_full[:, K:K + J, :K]              # [E,J,K]
            jnr_from_off = jnr_off_to_sub.max(dim=2).values       # [E,J]
        else:
            jnr_from_off = torch.zeros(E, 0, device=dev)
        jnr_pool_to_sub = jnr_full[:, K + J:, :K]                 # [E,N,K]
        jnr_from_pool_all = jnr_pool_to_sub.max(dim=2).values     # [E,N]
        if self.has_jammers:
            jnr_from_pool = torch.where(
                self.pool.jammer & self.pool.alive,
                jnr_from_pool_all, torch.zeros_like(jnr_from_pool_all),
            )
        else:
            jnr_from_pool = torch.zeros_like(jnr_from_pool_all)

        # JNR at emitter victims (cols K+J..K+J+N-1) — for jam-task criterion.
        jnr_at_emitters = jnr_full[:, :, K + J:].sum(dim=1) * emit_mask.float()  # [E,N]

        # Measurement σ: per-subarray from f_track; tracker slots use worst-case
        f_track_eff = alloc[..., 1].squeeze(1)  # [E,K]
        # Build fte_nodes: [K+J+N], zeros for non-subarray nodes (their σ unused)
        fte_sub = f_track_eff
        fte_nodes = torch.cat([
            fte_sub,
            torch.zeros(E, J, device=dev),
            torch.full((E, N), 1e-3, device=dev),
        ], dim=1) if J > 0 else torch.cat([fte_sub, torch.full((E, N), 1e-3, device=dev)], dim=1)
        fusion = torch.ones(E, 1, n_nodes, device=dev)
        sigma_nodes = self.iq.compute_meas_sigma(
            jnr_full, fte_nodes.unsqueeze(1), self.range_sigma_m, fusion
        ).squeeze(1)  # [E,K+J+N]
        sigma_sub = sigma_nodes[:, :K]  # [E,K]
        sigma_worst = sigma_sub.max(dim=1, keepdim=True).values  # [E,1]
        sigma_meas = sigma_worst.view(E, 1, 1).expand(E, 1, N).contiguous()  # [E,1,N]

        # Detection against target pool (RCS path, no emitter gate)
        radar_alive = torch.ones(E, 1, K, dtype=torch.bool, device=dev)
        dets = detect(
            self.radar_pos, beam_az, alloc, emission_on,
            torch.ones(E, 1, K, dtype=torch.bool, device=dev),  # enemy_emitting (unused)
            radar_alive, jnr_full,
            range_max_m=self.range_max_m, fc_hz=self.fc_hz,
            channel_bw_hz=self.channel_bw_hz, noise_figure_db=self.noise_figure_db,
            P_per_subarray_W=self.P_per_subarray_W, n_subarrays=self.n_subarrays,
            aperture_D_m=self.aperture_D_m, aperture_eta=self.aperture_eta,
            sigma_rcs_m2=self.sigma_rcs_m2,
            detect_threshold_db=self.detect_threshold_db,
            detect_width_db=self.detect_width_db, p_fa=self.p_fa,
            k_max=self.k_max, n_search_cells=self.n_search_cells,
            beam_width_rad=self.beam_width_rad,
            coherent_processing_gain_db=self.coherent_processing_gain_db,
            device=self.device,
            target_pos=self.pool.pos, target_emitting=self.pool.emitter,
            target_rcs_m2=self.pool.rcs, target_alive=self.pool.alive,
        )

        # Tracker update
        self.tracker.update(dets, sigma_meas)

        # Env-side track management: de-duplicate slots latched onto the same
        # target (all slots init independently and would otherwise saturate on
        # the first-detected targets, starving later spawns). Tracker math
        # untouched; duplicates simply lose their initialized flag and are
        # re-seeded as fresh slots by the tracker's _sync_from_env.
        init = self.tracker_initialized[:, 0]              # [E,N_trk]
        if init.any():
            tx = self.tracker_x[:, 0, :, [0, 2]]           # [E,N_trk,2]
            d2 = (tx.unsqueeze(2) - tx.unsqueeze(1)).norm(dim=-1)  # [E,Ti,Tj]
            dup_pair = (d2 < 100.0) & init.unsqueeze(1) & init.unsqueeze(2)
            upper = torch.triu(
                torch.ones_like(dup_pair, dtype=torch.bool), diagonal=1
            )
            dup = (dup_pair & upper).any(dim=1)
            self.tracker_initialized[:, 0] = init & ~dup

        # Search-cell bitmap: mark cell containing each active subarray's beam
        cell_width = 2.0 * math.pi / self.n_search_cells
        cell_idx = ((beam_az.squeeze(1) + math.pi) / cell_width).long().clamp(
            0, self.n_search_cells - 1
        )  # [E,K]
        active = (alloc[..., 0].squeeze(1) > 0.01) & emission_on.squeeze(1)  # [E,K]
        self._searched_cells.scatter_(
            2, cell_idx.unsqueeze(-1), active.unsqueeze(-1)
        )

        jnr_from_pool_db = 10.0 * torch.log10(jnr_from_pool.clamp(min=1e-12))
        jnr_from_off_db = 10.0 * torch.log10(jnr_from_off.clamp(min=1e-12))
        # JNR at off-board jammers from our subarrays (jam-task criterion).
        # Source = sum over subarray rows i of jnr_full[i, K+j]; computed before
        # the off-board-victim masking was applied... but we DID mask cols K..K+J
        # to zero. Recompute from the raw matrix by re-extracting pre-mask.
        # Easier: rebuild a small submatrix sub→off using the masked matrix
        # (which kept [:K, K:K+J] block) and sum rows.
        if J > 0:
            jnr_at_off_board = jnr_full[:, :K, K:K + J].sum(dim=1)   # [E,J]
        else:
            jnr_at_off_board = torch.zeros(E, 0, device=dev)
        return dict(
            detections=dets, jnr_at_sub=jnr_at_sub,
            jnr_at_emitters=jnr_at_emitters, sigma_meas=sigma_meas,
            jnr_from_pool_db=jnr_from_pool_db, jnr_from_off_db=jnr_from_off_db,
            jnr_at_off_board=jnr_at_off_board,
        )

    # ------------------------------------------------------------------
    def _matched_track(self):
        """Map each pool target slot to its best tracker slot.

        Returns (matched[E,N], slot[E,N], dist[E,N]): matched = nearest
        initialized track within 200 m of the true position. Env-internal
        (privileged) — used only for task success criteria, never in obs.
        """
        init = self.tracker_initialized[:, 0]              # [E,N_trk]
        tx = self.tracker_x[:, 0, :, [0, 2]]               # [E,N_trk,2]
        tp = self.pool.pos                                 # [E,N,2]
        d = (tx.unsqueeze(2) - tp.unsqueeze(1)).norm(dim=-1)  # [E,N_trk,N]
        d = d.masked_fill(~init.unsqueeze(2), 1e9)
        dmin, slot = d.min(dim=1)                          # [E,N]
        return (dmin < 200.0), slot, dmin

    # ------------------------------------------------------------------
    def step(self, actions: torch.Tensor, jammer_actions: torch.Tensor = None):
        """M2 interface: actions[E,K] int64, 0=idle, 1..8 = exposed queue slot.

        Phase B learning-jammer path: pass jammer_actions[E,J] bool/0-1 to
        override the off-board active mask for THIS step (env.policy must be
        JAM_POLICY_LEARNING). None = scripted policy drives activation.

        Pipeline (order fixed, plan §4.1): pool advance → arrivals/drops →
        action parse → servo → physics → progress/criteria → reward → obs.
        Returns (obs[E,K,OBS_DIM], reward[E,K], done[E], info).
        """
        E, K, N, dev = self.E, self.K, self.N_max, self.device
        tl = self.task_layer
        # Pre-step jammer override (LEARNING policy reads it inside update_activation)
        if jammer_actions is not None and self.has_jammers:
            self.jammer.set_active_override_off(jammer_actions)

        # 1-2. Target pool + task arrivals/drops
        self.pool.step()
        tl.arrive(self.pool)
        dropped = tl.tick_windows()  # [E,Q]

        # 3. Exposed queue + action parse (Phase B: action 9 = antijam)
        bmask = tl.bindable(self.pool, n_pool=self.N_max) if self.has_jammers \
            else tl.bindable(self.pool)                              # [E,Q]
        exposed = tl.exposed(bmask)                                  # [E,8]
        act = actions.long().view(E, K)
        sel = (act >= 1) & (act <= 8)
        antijam = torch.zeros(E, K, dtype=torch.bool, device=dev)
        if self.enable_antijam_action:
            antijam = act == 9
        exp_idx = (act - 1).clamp(min=0, max=7)
        gathered = torch.gather(exposed, 1, exp_idx)                 # [E,K]
        g_ok = gathered >= 0
        g_bindable = torch.where(
            g_ok, torch.gather(bmask, 1, gathered.clamp(min=0)),
            torch.zeros_like(g_ok),
        )
        ok = sel & g_ok & g_bindable
        infeasible = sel & ~ok                                       # penalized idle
        # antijam subarrays are not "infeasible"; they're a deliberate idle
        infeasible = infeasible & ~antijam
        self.bound_task = torch.where(ok, gathered, torch.full_like(gathered, -1))

        # 4. Servo beam/alloc/emission from bound task type
        beam_az = torch.zeros(E, 1, K, device=dev)
        alloc_raw = torch.zeros(E, 1, K, 4, device=dev)
        emission_on = torch.zeros(E, 1, K, dtype=torch.bool, device=dev)
        bound = self.bound_task >= 0
        if bound.any():
            q = self.bound_task.clamp(min=0)
            t_type = torch.gather(tl.fields[:, :, F_TYPE], 1, q).long()   # [E,K]
            t_tgt = torch.gather(tl.fields[:, :, F_TGT], 1, q).long()     # [E,K]
            t_sec = torch.gather(tl.fields[:, :, F_SECTOR], 1, q).long()  # [E,K]

            is_track = bound & (t_type <= TYPE_TRACK_NORMAL)
            is_jam = bound & (t_type == TYPE_JAM)
            is_search = bound & ((t_type == TYPE_SEARCH_HI) | (t_type == TYPE_SEARCH_LO))
            is_comm = bound & (t_type == TYPE_COMM)

            # beam → target az (track/jam). Phase B: off-board jammer target
            # (t_tgt ≥ N_max) → beam toward off-board jammer pos.
            in_pool = t_tgt < self.N_max
            tgt_pos_pool = torch.gather(
                self.pool.pos, 1,
                t_tgt.clamp(min=0, max=self.N_max - 1).unsqueeze(-1).expand(E, K, 2),
            )
            if self.has_jammers and self.n_offboard_jammers > 0:
                off_idx = (t_tgt - self.N_max).clamp(min=0, max=self.n_offboard_jammers - 1)
                tgt_pos_off = torch.gather(
                    self.jammer.off_pos, 1, off_idx.unsqueeze(-1).expand(E, K, 2)
                )
                tgt_pos = torch.where(in_pool.unsqueeze(-1), tgt_pos_pool, tgt_pos_off)
            else:
                tgt_pos = tgt_pos_pool
            az_t = torch.atan2(tgt_pos[..., 1], tgt_pos[..., 0])
            beam_az[:, 0, :] = torch.where(is_track | is_jam, az_t, beam_az[:, 0, :])

            # beam → first uncovered cell in sector (search)
            covered_any = self._searched_cells.any(dim=1)  # [E,72]
            cell_w = 2.0 * math.pi / self.n_search_cells
            offs = torch.arange(8, device=dev)
            sec_cells = (t_sec.unsqueeze(-1) + offs) % self.n_search_cells  # [E,K,8]
            cov = torch.gather(
                covered_any.unsqueeze(1).expand(E, K, self.n_search_cells), 2, sec_cells
            )  # [E,K,8]
            first_unc = (~cov).float().argmax(dim=-1)  # 0 if all covered
            k_off = torch.arange(K, device=dev).unsqueeze(0)  # [1,K]
            pick = (first_unc + k_off) % 8
            cell_id = torch.gather(sec_cells, 2, pick.unsqueeze(-1)).squeeze(-1)
            az_s = -math.pi + (cell_id.float() + 0.5) * cell_w
            beam_az[:, 0, :] = torch.where(is_search, az_s, beam_az[:, 0, :])

            # alloc one-hot: track→1, search→0, jam→2, comm→3
            alloc_idx = torch.where(
                is_track, torch.ones_like(t_type),
                torch.where(is_search, torch.zeros_like(t_type),
                            torch.where(is_jam, torch.full_like(t_type, 2),
                                        torch.full_like(t_type, 3))))
            alloc_raw[:, 0, :].scatter_(1, alloc_idx.unsqueeze(-1), 10.0)
            emission_on[:, 0, :] = bound & ~is_comm

        # 4.5 Phase B: advance jammer activation (illum/policy state) so the
        # JNR matrix built inside physics_step reflects this step's jammer state.
        if self.has_jammers:
            self.jammer.update_activation(
                self.pool.jammer, self.pool.alive, self.pool.pos,
                beam_az.squeeze(1), self.radar_pos.squeeze(1),
                self.beam_width_rad,
            )

        # 5. Physics (Phase B: pass antijam mask so jammer→sub σ is suppressed)
        matched_pre, m_slot_pre, _ = self._matched_track()
        out = self.physics_step(
            beam_az, alloc_raw, emission_on,
            antijam_mask=antijam if self.enable_antijam_action else None,
        )
        # Cache last-step JNR for downstream consumers (rule scheduler reads
        # this for its antijam trigger, since actions are chosen BEFORE physics).
        self.last_jnr_at_sub = out["jnr_at_sub"].detach()

        # 5.5 Phase B: EW auto-cue type-4 tasks against active jammers
        if self.has_jammers:
            cue_pool, cue_off = self.jammer.ew_detect(
                out["jnr_from_pool_db"], out["jnr_from_off_db"]
            )
            if cue_pool.any() or cue_off.any():
                tl.cue_jammers(cue_pool, cue_off, n_pool=self.N_max)
                # Re-bind exposed queue (cue admission may have changed it)
                bmask = tl.bindable(self.pool, n_pool=self.N_max)

        # 6. Per-task progress + criteria
        # Phase B σ-coupling: progress rate is scaled by 1/sqrt(1+JNR_at_target)
        # — physically, low SNR lengthens dwell (integration time grows to
        # hold detection quality fixed). Without this coupling the jammer
        # can only damage radar via EW-cue admission inflation, capping its
        # lever at the (saturated) scripted baseline.
        Q = tl.Q
        f_type = tl.fields[:, :, F_TYPE].long()
        f_tgt = tl.fields[:, :, F_TGT].long().clamp(min=0)
        # Phase B: off-board cue tasks target slot ≥ N_max. Clamp for tracker
        # gathers (no track exists for off-board); compute JNR-at-target per
        # carrier type (pool emitter vs off-board jammer) separately below.
        tgt_in_pool = f_tgt < self.N_max                       # [E,Q]
        f_tgt_pool = f_tgt.clamp(max=self.N_max - 1)           # safe for [E,N] gather
        f_tgt_off = (f_tgt - self.N_max).clamp(min=0, max=max(self.n_offboard_jammers - 1, 0))
        progress_add = torch.zeros(E, Q, device=dev)
        if bound.any():
            onehot = torch.nn.functional.one_hot(
                self.bound_task.clamp(min=0), Q
            ).float()  # [E,K,Q]
            onehot = onehot * bound.unsqueeze(-1).float()
            n_exec = onehot.sum(dim=1)                     # [E,Q]
            progress_add = 0.25 * n_exec
            if self.has_jammers:
                # Per-task JNR at target (pool emitter JNR or off-board victim)
                jnr_em = out["jnr_at_emitters"]              # [E,N]
                jnr_off = out.get(
                    "jnr_at_off_board",
                    torch.zeros(E, max(self.n_offboard_jammers, 0), device=dev),
                )
                tgt_jnr_pool = torch.gather(jnr_em, 1, f_tgt_pool)
                tgt_jnr_off = torch.zeros(E, Q, device=dev)
                if self.n_offboard_jammers > 0:
                    tgt_jnr_off = torch.gather(jnr_off, 1, f_tgt_off)
                tgt_jnr = torch.where(tgt_in_pool, tgt_jnr_pool, tgt_jnr_off)
                # Dwell-time scaling: σ_eff/σ_base = sqrt(1+JNR_lin). Scale
                # progress by inverse. Clamp to keep min rate 0.1 (avoids
                # full stalls that freeze the queue indefinitely).
                sigma_scale = torch.sqrt(1.0 + tgt_jnr.clamp(min=0.0, max=1e4))
                prog_factor = (1.0 / sigma_scale).clamp(min=0.1, max=1.0)
                progress_add = progress_add * prog_factor

        matched, m_slot, _ = self._matched_track()             # [E,N]
        m_gather = torch.where(
            tgt_in_pool, torch.gather(matched, 1, f_tgt_pool),
            torch.zeros_like(tgt_in_pool),
        )
        slot_gather = torch.gather(m_slot, 1, f_tgt_pool)
        trk_init = self.tracker_initialized[:, 0]              # [E,N_trk]
        init_now = torch.where(
            m_gather, torch.gather(trk_init, 1, slot_gather),
            torch.zeros_like(m_gather),
        )  # [E,Q]
        real_assoc = torch.where(
            m_gather, torch.gather(self.tracker.last_real_assoc[:, 0], 1, slot_gather),
            torch.zeros_like(m_gather),
        )
        init_pre = torch.where(
            tgt_in_pool, torch.gather(matched_pre, 1, f_tgt_pool),
            torch.zeros_like(tgt_in_pool),
        )
        # JNR-at-target: pool emitter uses jnr_at_emitters[E,N]; off-board uses
        # JNR at off-board victim columns (subarray contributions).
        jnr_emit_db = 10.0 * torch.log10(out["jnr_at_emitters"].clamp(min=1e-12))
        jnr_at_tgt_pool = torch.gather(jnr_emit_db, 1, f_tgt_pool)
        if self.has_jammers and self.n_offboard_jammers > 0:
            # Recompute JNR at off-board victim cols (physics_step zeroed them
            # for victim-protection; we want the subarray→off-board sum here).
            # Use the total off-board JNR breakdown we already extracted.
            jnr_at_off_db = 10.0 * torch.log10(
                out.get("jnr_at_off_board", torch.zeros(E, self.n_offboard_jammers, device=dev))
                .clamp(min=1e-12)
            )
            jnr_at_tgt_off = torch.gather(jnr_at_off_db, 1, f_tgt_off)
            jnr_at_tgt = torch.where(tgt_in_pool, jnr_at_tgt_pool, jnr_at_tgt_off)
        else:
            jnr_at_tgt = jnr_at_tgt_pool
        n_exec_per_task = progress_add / 0.25              # [E,Q]

        crit_ok = torch.ones(E, Q, dtype=torch.bool, device=dev)
        crit_ok = torch.where(f_type == TYPE_TRACK_NORMAL, real_assoc, crit_ok)
        crit_ok = torch.where(f_type == TYPE_JAM, jnr_at_tgt > 10.0, crit_ok)
        crit_ok = torch.where(f_type == TYPE_COMM, n_exec_per_task >= 2, crit_ok)

        tl.accumulate(progress_add, crit_ok, init_now, init_pre)

        # 7. Finalize completions
        trace_p = (
            self.tracker_P[:, 0, :, 0, 0] + self.tracker_P[:, 0, :, 2, 2]
        )  # [E,N_trk]
        trace_gather = torch.where(
            m_gather, torch.gather(trace_p, 1, slot_gather),
            torch.full_like(jnr_at_tgt, 1e9),
        )
        covered_any = self._searched_cells.any(dim=1)      # [E,72]
        f_sec = tl.fields[:, :, F_SECTOR].long()
        offs = torch.arange(8, device=dev)
        sec_cells = (f_sec.unsqueeze(-1) + offs) % self.n_search_cells  # [E,Q,8]
        sec_cov = torch.gather(
            covered_any.unsqueeze(1).expand(E, Q, self.n_search_cells), 2, sec_cells
        ).all(dim=-1)  # [E,Q]

        final_ok = torch.ones(E, Q, dtype=torch.bool, device=dev)
        final_ok = torch.where(f_type == TYPE_TRACK_PRECISE, trace_gather < self.tau_track, final_ok)
        final_ok = torch.where(f_type == TYPE_IFF, tl.seen_uninit & init_now, final_ok)
        final_ok = torch.where(f_type == TYPE_TRACK_NORMAL, tl.crit_all & init_now, final_ok)
        final_ok = torch.where(
            (f_type == TYPE_SEARCH_HI) | (f_type == TYPE_SEARCH_LO), sec_cov, final_ok
        )
        final_ok = torch.where(f_type == TYPE_JAM, tl.crit_all, final_ok)
        final_ok = torch.where(f_type == TYPE_COMM, tl.crit_all, final_ok)

        completed, success = tl.finalize(final_ok)

        # 8. Reward (team-shared, plan §2.5 + drop-shaping)
        reward_team = torch.zeros(E, device=dev)
        n_unbound = K - bound.sum(dim=1).float()           # [E]
        if success.any():
            reward_team += 10.0 * (1.0 - 0.25 * n_unbound) * success.float().sum(dim=1)
        if dropped.any():
            # fields persist after tick_windows clears active → P still readable
            P_drop = tl.fields[:, :, F_P] * dropped.float()
            reward_team -= self.drop_penalty_scale * (
                2.0 * dropped.float() + P_drop / 7.0
            ).sum(dim=1)
        reward_team -= 10.0 * infeasible.float().sum(dim=1)
        idle = ~bound
        reward_team -= 1.0 * idle.float().sum(dim=1)
        reward = reward_team.unsqueeze(1).expand(E, K).contiguous()

        # 9. Bookkeeping + obs
        self.step_idx += 1
        done = self.step_idx >= self.episode_steps
        obs = self._build_obs()
        info = dict(
            completed=int(completed.sum().item()),
            succeeded=int(success.sum().item()),
            dropped=int(dropped.sum().item()),
        )
        return obs, reward, done, info

    # ------------------------------------------------------------------
    def _build_obs(self) -> torch.Tensor:
        """Per-agent obs [E, K, obs_dim] (Phase A 159; Phase B 175)."""
        E, K, N, dev = self.E, self.K, self.N_max, self.device
        obs = torch.zeros(E, K, self.obs_dim, device=dev)

        # [0:4] subarray one-hot
        obs[:, :, :K] = torch.eye(K, device=dev).unsqueeze(0).expand(E, K, K)

        tl = self.task_layer
        Q = tl.Q
        f = tl.fields
        prog_ratio = f[:, :, F_PROG] / f[:, :, F_R].clamp(min=1e-9)

        # [4:12] bound-task features per subarray (zeros when idle)
        bound = self.bound_task >= 0
        q = self.bound_task.clamp(min=0)
        g = lambda col: torch.gather(f[:, :, col], 1, q)  # [E,K]
        bf = torch.stack([
            g(F_TYPE) / N_TYPES, g(F_P) / 7.0, g(F_TAUW) / 100.0,
            g(F_ETA), torch.gather(prog_ratio, 1, q),
            g(F_TGT) / (self.N_max + self.n_offboard_jammers + 1),
            g(F_SECTOR) / 72.0,
        ], dim=-1)  # [E,K,7]
        bf = torch.cat([bound.float().unsqueeze(-1), bf], dim=-1)  # [E,K,8]
        obs[:, :, 4:12] = bf * bound.unsqueeze(-1).float()

        # [12:84] exposed queue 8×9
        bmask = tl.bindable(self.pool, n_pool=self.N_max) if self.has_jammers \
            else tl.bindable(self.pool)
        exposed = tl.exposed(bmask)  # [E,8]
        exp_ok = exposed >= 0
        eq = exposed.clamp(min=0)
        ge = lambda col: torch.gather(f[:, :, col], 1, eq)  # [E,8]
        feasible = torch.where(
            exp_ok, torch.gather(bmask, 1, eq), torch.zeros_like(exp_ok)
        )
        qf = torch.stack([
            ge(F_TYPE) / N_TYPES, ge(F_P) / 7.0, ge(F_TAUD) / 20.0,
            ge(F_TAUW) / 100.0, ge(F_ETA), torch.gather(prog_ratio, 1, eq),
            ge(F_TGT) / (self.N_max + self.n_offboard_jammers + 1),
            ge(F_SECTOR) / 72.0, feasible.float(),
        ], dim=-1)  # [E,8,9]
        qf = qf * exp_ok.unsqueeze(-1).float()
        obs[:, :, 12:84] = qf.reshape(E, 1, 72).expand(E, K, 72)

        # [84:156] target beliefs: 12 × 6 = [x,vx,y,vy normalized, trace_P_n, init]
        base = 12 + 8 * 9
        tx = self.tracker_x.squeeze(1) / self.region_half_m  # [E,N,4] pos+vel norm
        trace_p = (
            self.tracker_P.squeeze(1)[..., 0, 0] + self.tracker_P.squeeze(1)[..., 2, 2]
        )  # [E,N]
        trace_n = (trace_p / 100.0).clamp(0.0, 1.0)
        init = self.tracker_initialized.squeeze(1).float()  # [E,N]
        beliefs = torch.cat([tx, trace_n.unsqueeze(-1), init.unsqueeze(-1)], dim=-1)  # [E,N,6]
        beliefs = beliefs * init.unsqueeze(-1)
        obs[:, :, base:base + N * 6] = (
            beliefs.reshape(E, 1, N * 6).expand(E, K, N * 6)
        )

        # [156:159] global
        obs[:, :, base + N * 6] = (self.step_idx.float() / self.episode_steps).unsqueeze(-1)
        obs[:, :, base + N * 6 + 1] = (
            tl.active.sum(dim=1).float() / Q
        ).unsqueeze(-1).expand(E, K)
        obs[:, :, base + N * 6 + 2] = (
            tl.n_completed.sum().float() / 100.0
        ).expand(E, K)

        # Phase B extension [159:177]: jammer beliefs
        if self.has_jammers:
            jb = self._build_jammer_beliefs()                   # [E,18]
            obs[:, :, OBS_DIM:OBS_DIM + 18] = (
                jb.unsqueeze(1).expand(E, K, 18)
            )

        return obs

    # ------------------------------------------------------------------
    def _build_jammer_beliefs(self) -> torch.Tensor:
        """[E, 18]: 4 pool-jammer × 3 (x_norm, y_norm, init_flag) +
        2 off-board × 3 (bearing_sin, bearing_cos, active_flag).
        Beliefs tracker-derived (no-godview); uninitialized → zeros."""
        E, N, dev = self.E, self.N_max, self.device
        jam_mask = self.pool.jammer & self.pool.alive             # [E,N]
        tx = self.tracker_x.squeeze(1) / self.region_half_m       # [E,N,4]
        init = self.tracker_initialized.squeeze(1)                # [E,N]
        pb_x = tx[..., 0] * jam_mask.float()                      # [E,N]
        pb_y = tx[..., 2] * jam_mask.float()
        pb_i = init.float() * jam_mask.float()
        pb = torch.stack([pb_x, pb_y, pb_i], dim=-1)              # [E,N,3]
        pb = pb[:, :4]                                            # truncate to 4
        if pb.shape[1] < 4:
            pad = torch.zeros(E, 4 - pb.shape[1], 3, device=dev)
            pb = torch.cat([pb, pad], dim=1)
        pb = pb.reshape(E, 12)

        if self.n_offboard_jammers > 0:
            off_pos = self.jammer.off_pos                         # [E,J,2]
            off_active = self.jammer.active_off.float() \
                if hasattr(self.jammer, "active_off") \
                else torch.zeros(E, self.n_offboard_jammers, device=dev)
            bearing = torch.atan2(off_pos[..., 1], off_pos[..., 0])
            ob = torch.stack([
                torch.sin(bearing), torch.cos(bearing), off_active,
            ], dim=-1)                                            # [E,J,3]
            ob = ob[:, :2]
            if ob.shape[1] < 2:
                pad = torch.zeros(E, 2 - ob.shape[1], 3, device=dev)
                ob = torch.cat([ob, pad], dim=1)
            ob = ob.reshape(E, 6)
        else:
            ob = torch.zeros(E, 6, device=dev)

        return torch.cat([pb, ob], dim=-1)                        # [E, 18]

    # ------------------------------------------------------------------
    def action_mask(self) -> torch.Tensor:
        """mask[E,K,n_act] bool: idle (and antijam, if enabled) always allowed;
        slot i+1 allowed iff the i-th exposed task exists (bindable)."""
        E, K = self.E, self.K
        bmask = self.task_layer.bindable(self.pool, n_pool=self.N_max) \
            if self.has_jammers else self.task_layer.bindable(self.pool)
        exposed = self.task_layer.exposed(bmask)                  # [E,8]
        valid = exposed >= 0                                      # [E,8]
        n_act = self.n_act
        mask = torch.zeros(E, K, n_act, dtype=torch.bool, device=self.device)
        mask[..., 0] = True                                       # idle
        if self.enable_antijam_action:
            mask[..., 9] = True                                   # antijam always allowed
        mask[..., 1:9] = valid.unsqueeze(1)
        return mask

    # ------------------------------------------------------------------
    def privileged(self) -> torch.Tensor:
        """Critic-only privileged state: true target pos/vel + jammer state."""
        E, N = self.E, self.N_max
        alive = self.pool.alive.float().unsqueeze(-1)
        pos_n = self.pool.pos / self.region_half_m
        vel_n = self.pool.vel / 300.0
        out = [pos_n * alive, vel_n * alive, alive]
        if self.has_jammers:
            # Pool jammer true state
            jam_alive = (self.pool.jammer & self.pool.alive).float().unsqueeze(-1)
            out.append(pos_n * jam_alive)                          # jammer pos
            out.append(jam_alive)
            # Off-board true state
            if self.n_offboard_jammers > 0:
                off_pos = self.jammer.off_pos / self.region_half_m
                off_active = self.jammer.active_off.float().unsqueeze(-1) \
                    if hasattr(self.jammer, "active_off") else \
                    torch.zeros(E, self.n_offboard_jammers, 1, device=self.device)
                out.append(off_pos)
                out.append(off_active)
        return torch.cat([t.reshape(E, -1) for t in out], dim=-1)

    # ------------------------------------------------------------------
    def jammer_obs(self) -> torch.Tensor:
        """Phase B: per-env observation for the learning jammer agent.
        Layout (~17 + 7·K + 5·J features):
          - step_idx/episode_steps (1)
          - radar_pos / region_half (2) — constant but useful for generalisation
          - per-subarray [beam_az sin/cos, alloc[detect/track/jam/comm] sum
            normalised, emission_on, last_jnr_lin] (K × 6 = 24 for K=4)
          - per off-board jammer [illum_count, dwell_remaining, base_ang sin/cos,
            last-cue steps ago] (J × 5 = 10 for J=2)
          - pool aggregates [n_alive, n_emitter_alive, n_jammer_alive,
            queue_depth, mean_track_progress] (5)
        Returns [E, jammer_obs_dim] float32.
        """
        if not self.has_jammers:
            raise RuntimeError("jammer_obs() requires has_jammers=True env")
        E, K, dev = self.E, self.K, self.device
        jf = self.jammer
        J = jf.J

        step_norm = (jf.step_idx.float() / max(self.episode_steps, 1)).unsqueeze(-1)
        # Radar is co-located at origin → normalised pos ~0; include for
        # generalisation across non-origin configs. Shape [E, 2].
        radar_pos_n = (self.radar_pos.squeeze(1).mean(dim=1) /
                       self.region_half_m)

        # Per-subarray features
        baz = self.beam_az.squeeze(1)                              # [E,K]
        baz_sin = torch.sin(baz)
        baz_cos = torch.cos(baz)
        alloc = self.alloc.squeeze(1)                             # [E,K,4]
        alloc_emit = alloc[..., :3].sum(dim=-1).clamp(0.0, 1.0)  # detect+track+jam
        em = self.emission_on.squeeze(1).float()                 # [E,K]
        jnr_lin = getattr(self, "last_jnr_at_sub",
                          torch.zeros(E, K, device=dev)).clamp(0.0, 1e6)
        jnr_log = torch.log1p(jnr_lin) / math.log(1e6 + 1.0)    # [E,K] in [0,1]
        sub_feat = torch.stack(
            [baz_sin, baz_cos, alloc_emit, em, jnr_log], dim=-1
        ).reshape(E, K * 5)

        # Per-jammer features
        if J > 0:
            ill = jf.off_illum_count.float().clamp(0.0, 30.0) / 30.0
            dwell = jf.off_dwell_remaining.float().clamp(0.0, 30.0) / 30.0
            base_ang_sin = torch.sin(jf.off_base_ang)
            base_ang_cos = torch.cos(jf.off_base_ang)
            cue_lag = (jf.step_idx.unsqueeze(1) - jf.off_last_cue).clamp(0, 60).float() / 60.0
            jam_feat = torch.stack(
                [ill, dwell, base_ang_sin, base_ang_cos, cue_lag], dim=-1
            ).reshape(E, J * 5)
        else:
            jam_feat = torch.zeros(E, 0, device=dev)

        # Pool aggregates (normalised)
        n_alive = self.pool.alive.float().sum(dim=1, keepdim=True) / self.N_max
        emit_alive = (self.pool.alive & self.pool.emitter).float().sum(dim=1, keepdim=True) / self.N_max
        jam_alive = (self.pool.alive & self.pool.jammer).float().sum(dim=1, keepdim=True) / self.N_max
        queue_depth = self.task_layer.active.sum(dim=1, keepdim=True).float() / self.task_layer.Q
        avg_prog = (self.task_layer.fields[:, :, F_PROG] /
                    self.task_layer.fields[:, :, F_R].clamp(min=1e-6))
        avg_prog = (avg_prog * self.task_layer.active.float()).sum(dim=1, keepdim=True) / \
                   self.task_layer.active.float().sum(dim=1, keepdim=True).clamp(min=1.0)
        pool_feat = torch.cat([n_alive, emit_alive, jam_alive, queue_depth, avg_prog], dim=-1)

        return torch.cat([step_norm, radar_pos_n, sub_feat, jam_feat, pool_feat], dim=-1)

    def jammer_obs_dim(self) -> int:
        """Static helper for trainer to size actor head."""
        K, J = self.K, (self.jammer.J if self.has_jammers else 0)
        return 1 + 2 + K * 5 + J * 5 + 5

    def jammer_action_mask(self) -> torch.Tensor:
        """Always-True mask [E, J]: any combination of jammers may be on/off.
        Future work: model power-budget constraints (e.g. max concurrent jammers)."""
        if not self.has_jammers or self.jammer.J == 0:
            return torch.zeros(self.E, 0, dtype=torch.bool, device=self.device)
        return torch.ones(self.E, self.jammer.J, dtype=torch.bool, device=self.device)
