"""Wang-2025 task layer for the MFR-IQ env (M2).

Seven task types (plan §2.3) with 5-tuple attributes, aperture-time resource
semantics (R = eta·tau_d full-array-steps; each bound+executing subarray adds
0.25 progress/step, coalition linear), time-window drops, and per-type success
flags accumulated over the dwell.

Queue tensors (E = n_envs, Q = Q_max):
    fields[E,Q,9]: [type_id, P, tau_d, tau_w_remaining, eta, progress,
                    target_slot, sector_id, R]
    active[E,Q]  bool
Per-type criterion state:
    crit_all[E,Q]    — all exec-steps satisfied (types 2/4/5)
    seen_uninit[E,Q] — target observed uninitialized during dwell (type 1)
Physics/criterion evaluation lives in MfrVecEnv; this class is bookkeeping.
"""

from __future__ import annotations

import torch

# type_id: (P, tau_d, tau_w, eta, lam_base)
# lam_base scaled so that sum_k lam·tau_d·eta / (K·0.25) = 1.0 at load_factor=1.0
# (raw Wang table sums to 0.05976; capacity = K subarrays × 0.25 = 1.0
# full-array-step/step → scale = 1.0/0.05976 ≈ 16.734).
# DEVIATION from plan §7 T8 formula (Σλ·τ_d·η/K): that formula omits the 0.25
# subarray-progress factor and yields 600% true overload (drop ≈ 80%,
# inconsistent with G1's [25,45%] band and Wang's 151%→34%).
TASK_TABLE = [
    (7, 10, 60, 0.40, 0.0028),   # 0 精确跟踪
    (6, 6, 55, 0.40, 0.0024),    # 1 敌我识别
    (5, 4, 80, 0.30, 0.0040),    # 2 普通跟踪
    (4, 6, 60, 0.35, 0.0048),    # 3 高优先级搜索
    (3, 4, 40, 0.40, 0.0036),    # 4 电子干扰
    (2, 20, 100, 0.25, 0.0032),  # 5 数据通信
    (1, 4, 75, 0.35, 0.0044),    # 6 低优先级搜索
]
N_TYPES = 7
_LAM_SCALE = 1.0 / sum(l * d * e for _, d, _, e, l in TASK_TABLE)

TYPE_TRACK_PRECISE = 0
TYPE_IFF = 1
TYPE_TRACK_NORMAL = 2
TYPE_SEARCH_HI = 3
TYPE_JAM = 4
TYPE_COMM = 5
TYPE_SEARCH_LO = 6

F_TYPE, F_P, F_TAUD, F_TAUW, F_ETA, F_PROG, F_TGT, F_SECTOR, F_R = range(9)


class TaskLayer:
    def __init__(
        self,
        E: int,
        K: int,
        Q_max: int = 64,  # load-1.5 pending demand ≈44 mean; 32 saturated for
                          # any policy and masked scheduling quality via overflow
        load_factor: float = 1.5,
        device: str = "cuda",
        gen: torch.Generator = None,
    ):
        self.E = int(E)
        self.K = int(K)
        self.Q = int(Q_max)
        self.device = torch.device(device)
        self.gen = gen

        P, tau_d, tau_w, eta, lam = zip(*TASK_TABLE)
        self.P = torch.tensor(P, dtype=torch.float32, device=self.device)
        self.tau_d = torch.tensor(tau_d, dtype=torch.float32, device=self.device)
        self.tau_w = torch.tensor(tau_w, dtype=torch.float32, device=self.device)
        self.eta = torch.tensor(eta, dtype=torch.float32, device=self.device)
        self.lam = torch.tensor(lam, dtype=torch.float32, device=self.device) * (
            _LAM_SCALE * float(load_factor)
        )
        # Resource demand R = eta · tau_d (full-array-steps)
        self.R_req = self.eta * self.tau_d

        # Metrics
        self.n_arrived = torch.zeros(N_TYPES, dtype=torch.long, device=self.device)
        self.n_completed = torch.zeros(N_TYPES, dtype=torch.long, device=self.device)
        self.n_succeeded = torch.zeros(N_TYPES, dtype=torch.long, device=self.device)
        self.n_dropped = torch.zeros(N_TYPES, dtype=torch.long, device=self.device)
        self.reset()

    def reset(self):
        E, Q, dev = self.E, self.Q, self.device
        self.fields = torch.zeros(E, Q, 9, device=dev)
        self.active = torch.zeros(E, Q, dtype=torch.bool, device=dev)
        self.crit_all = torch.ones(E, Q, dtype=torch.bool, device=dev)
        self.seen_uninit = torch.zeros(E, Q, dtype=torch.bool, device=dev)
        self.bound_by = torch.zeros(E, Q, dtype=torch.long, device=dev)  # #subarrays bound
        # Per-slot unique id (dwell-commitment validation: slots are reused)
        if not hasattr(self, "uid") or self.uid.shape != (E, Q):
            self.uid = torch.zeros(E, Q, dtype=torch.long, device=dev)
            self._uid_counter = 1
        else:
            self.uid.zero_()

    # ------------------------------------------------------------------
    def arrive(self, pool) -> torch.Tensor:
        """Poisson arrivals per type; bind target/sector. Returns void-mask info
        (arrivals with no valid target are discarded). pool: TargetPool."""
        E, Q, dev = self.E, self.Q, self.device
        # Draws: [E, N_TYPES] Poisson(λ)
        draws = torch.poisson(
            self.lam.unsqueeze(0).expand(E, N_TYPES), generator=self.gen
        ).long()
        total = int(draws.sum().item())
        if total == 0:
            return self.active
        # Flatten arrivals into a list of (e, type) then vector-assign to free slots
        e_idx, t_idx = draws.nonzero(as_tuple=True)
        counts = draws[e_idx, t_idx]
        e_rep = e_idx.repeat_interleave(counts)
        t_rep = t_idx.repeat_interleave(counts)
        n_arr = e_rep.numel()

        # Target binding per type
        alive = pool.alive  # [E,N]
        emit_alive = pool.alive & pool.emitter
        # random alive target slot (track/IFF types 0,1,2); -1 if none
        def rand_slot(mask):
            r = torch.rand(E, mask.shape[1], device=dev, generator=self.gen)
            r = torch.where(mask, r, torch.full_like(r, 2.0))
            slot = r.argmin(dim=1)
            ok = mask.any(dim=1)
            return torch.where(ok, slot, torch.full_like(slot, -1))

        tgt_track = rand_slot(alive)          # [E]
        tgt_jam = rand_slot(emit_alive)       # [E]

        type_f = t_rep.float()
        is_track = (t_rep <= TYPE_TRACK_NORMAL)
        is_jam = t_rep == TYPE_JAM
        is_search = (t_rep == TYPE_SEARCH_HI) | (t_rep == TYPE_SEARCH_LO)

        tgt_slot = torch.zeros(n_arr, dtype=torch.long, device=dev)
        tgt_slot[is_track] = tgt_track[e_rep[is_track]]
        tgt_slot[is_jam] = tgt_jam[e_rep[is_jam]]
        sector = torch.randint(0, 72, (n_arr,), device=dev, generator=self.gen)

        # Void arrivals: track/jam with no valid target
        void = (is_track & (tgt_slot < 0)) | (is_jam & (tgt_slot < 0))
        keep = ~void
        e_k, t_k = e_rep[keep], t_rep[keep]
        tgt_k, sec_k = tgt_slot[keep], sector[keep]
        if e_k.numel() == 0:
            return self.active

        # Claim free slots (vectorized). nonzero/repeat_interleave yield e_k
        # sorted ascending, so per-env arrival rank = tril one-hot count - 1.
        n_k = e_k.numel()
        same_e = e_k.unsqueeze(1) == e_k.unsqueeze(0)  # [n,n]
        arr_rank = same_e.tril().sum(dim=1) - 1        # [n] 0-based rank in env
        free = ~self.active                            # [E,Q]
        free_rank = free.long().cumsum(dim=1)          # 1-based rank of free slot
        match = free[e_k] & (free_rank[e_k] == (arr_rank + 1).unsqueeze(1))  # [n,Q]
        has = match.any(dim=1)
        chosen = torch.where(has, match.float().argmax(dim=1),
                             torch.full_like(arr_rank, -1))
        # Over-capacity arrivals: queue admission is the scheduler's first
        # decision (Wang 表 1 drop condition applies to pending tasks; an
        # arrival that cannot be admitted is simply not pending). Not counted
        # as drop — otherwise drop_ratio is dominated by Q_max (already
        # saturated for every policy), masking scheduling quality.
        self.n_arrived += torch.bincount(t_k.reshape(-1), minlength=N_TYPES)

        ok = chosen >= 0
        e_k, t_k, tgt_k, sec_k, chosen = (
            e_k[ok], t_k[ok], tgt_k[ok], sec_k[ok], chosen[ok],
        )
        if e_k.numel() == 0:
            return self.active

        P_k = self.P[t_k]
        taud_k = self.tau_d[t_k]
        tauw_k = self.tau_w[t_k]
        eta_k = self.eta[t_k]
        R_k = self.R_req[t_k]

        f = self.fields
        f[e_k, chosen, F_TYPE] = t_k.float()
        f[e_k, chosen, F_P] = P_k
        f[e_k, chosen, F_TAUD] = taud_k
        f[e_k, chosen, F_TAUW] = tauw_k
        f[e_k, chosen, F_ETA] = eta_k
        f[e_k, chosen, F_PROG] = 0.0
        f[e_k, chosen, F_TGT] = tgt_k.float()
        f[e_k, chosen, F_SECTOR] = sec_k.float()
        f[e_k, chosen, F_R] = R_k
        self.active[e_k, chosen] = True
        self.crit_all[e_k, chosen] = True
        self.seen_uninit[e_k, chosen] = False
        self.uid[e_k, chosen] = self._uid_counter
        self._uid_counter += 1
        return self.active

    # ------------------------------------------------------------------
    def bindable(self, pool, n_pool: int = None) -> torch.Tensor:
        """mask[E,Q]: active, and (if target-bound) target still alive.

        Phase B: target_slot ≥ n_pool addresses an off-board jammer (always
        "alive" for binding purposes — suppression, not kill). Pass n_pool=N
        (pool size) to enable the off-board branch; None keeps Phase A behavior.
        """
        tgt = self.fields[:, :, F_TGT].long()
        type_id = self.fields[:, :, F_TYPE].long()
        target_bound = (type_id <= TYPE_TRACK_NORMAL) | (type_id == TYPE_JAM)
        tgt_alive = torch.ones_like(self.active)
        tb = target_bound & self.active
        if tb.any():
            if n_pool is not None:
                pool_slot = tgt.clamp(min=0, max=n_pool - 1)
                in_pool = tgt < n_pool
                alive_lookup = torch.gather(pool.alive, 1, pool_slot)
                tgt_alive = torch.where(tb & in_pool, alive_lookup, tgt_alive)
                # off-board slots: bindable while task active (env controls liveness)
                tgt_alive = torch.where(tb & ~in_pool, torch.ones_like(tgt_alive), tgt_alive)
            else:
                alive_lookup = torch.gather(
                    pool.alive, 1, tgt.clamp(min=0)
                )
                tgt_alive = torch.where(tb, alive_lookup, tgt_alive)
        return self.active & tgt_alive

    # ------------------------------------------------------------------
    def cue_jammers(
        self,
        cue_pool,                       # [E,N_pool] bool: pool jammer to be cued
        cue_off,                        # [E,J] bool: off-board jammer to be cued
        n_pool: int,
        P_jam_cue: float = 8.0,
    ):
        """Auto-generate type-4 tasks against active jammers (plan §2.4).

        Reuses the queue admission path: claims a free slot per cue, fills
        fields with type=JAM, P=P_jam_cue (8 > Wang's max 7), eta/tau_d/R from
        the TASK_TABLE jam row but progress reset. Target slot = pool slot
        (< n_pool) or N_max + j (off-board virtual slot).

        Idempotent within a step: caller passes fresh cue_* masks each step.
        """
        E, Q, dev = self.E, self.Q, self.device
        e_idx_p, n_idx_p = cue_pool.nonzero(as_tuple=True)
        e_idx_o, j_idx_o = cue_off.nonzero(as_tuple=True)
        n_p, n_o = e_idx_p.numel(), e_idx_o.numel()
        if n_p == 0 and n_o == 0:
            return
        # Build (e, tgt_slot) pairs
        if n_p > 0:
            t_p = torch.full_like(e_idx_p, 0)
            tgt_p = n_idx_p.clone()
        if n_o > 0:
            t_o = torch.full_like(e_idx_o, 0)
            tgt_o = n_pool + j_idx_o
        if n_p > 0 and n_o > 0:
            e_idx = torch.cat([e_idx_p, e_idx_o])
            t_idx = torch.cat([t_p, t_o])
            tgt = torch.cat([tgt_p, tgt_o])
        elif n_p > 0:
            e_idx, t_idx, tgt = e_idx_p, t_p, tgt_p
        else:
            e_idx, t_idx, tgt = e_idx_o, t_o, tgt_o

        # Each cue is one type-4 task; coerce type to TYPE_JAM (4)
        t_idx = torch.full_like(e_idx, TYPE_JAM)

        # Claim free slots per env (same vectorised admission as `arrive`)
        n_k = e_idx.numel()
        same_e = e_idx.unsqueeze(1) == e_idx.unsqueeze(0)
        arr_rank = same_e.tril().sum(dim=1) - 1
        free = ~self.active
        free_rank = free.long().cumsum(dim=1)
        match = free[e_idx] & (free_rank[e_idx] == (arr_rank + 1).unsqueeze(1))
        has = match.any(dim=1)
        chosen = torch.where(has, match.float().argmax(dim=1),
                             torch.full_like(arr_rank, -1))
        ok = chosen >= 0
        if not ok.any():
            return
        e_idx, t_idx, tgt, chosen = e_idx[ok], t_idx[ok], tgt[ok], chosen[ok]

        # Fill fields: type-4 with P_cue, R/eta/tau_d from TASK_TABLE[TYPE_JAM],
        # but boosted priority. tau_w set to a short window (30 steps) so cues
        # auto-expire if not served.
        idx4 = TYPE_JAM
        fk = lambda v: torch.full((e_idx.shape[0],), float(v),
                                   dtype=torch.float32, device=self.device)
        P_k = fk(int(P_jam_cue))
        taud_k = fk(float(self.tau_d[idx4].item()))
        tauw_k = fk(30.0)
        eta_k = fk(float(self.eta[idx4].item()))
        R_k = fk(float(self.R_req[idx4].item()))
        sec_k = torch.zeros_like(e_idx)

        f = self.fields
        f[e_idx, chosen, F_TYPE] = t_idx.float()
        f[e_idx, chosen, F_P] = P_k
        f[e_idx, chosen, F_TAUD] = taud_k
        f[e_idx, chosen, F_TAUW] = tauw_k
        f[e_idx, chosen, F_ETA] = eta_k
        f[e_idx, chosen, F_PROG] = 0.0
        f[e_idx, chosen, F_TGT] = tgt.float()
        f[e_idx, chosen, F_SECTOR] = sec_k.float()
        f[e_idx, chosen, F_R] = R_k
        self.active[e_idx, chosen] = True
        self.crit_all[e_idx, chosen] = True
        self.seen_uninit[e_idx, chosen] = False
        self.uid[e_idx, chosen] = self._uid_counter
        self._uid_counter += 1
        # Count cue admissions in n_arrived too so drop_ratio = dropped/arrived
        # stays well-defined (cue tasks ARE additional radar demand that the
        # scheduler must serve or drop). Per-type tracking lets downstream
        # reports separate Poisson demand from EW-driven cue load if needed.
        self.n_arrived += torch.bincount(
            t_idx.reshape(-1), minlength=N_TYPES
        )

    # ------------------------------------------------------------------
    def exposed(self, bindable_mask: torch.Tensor, n_expose: int = 8) -> torch.Tensor:
        """Top-8 bindable tasks sorted by remaining window ascending.
        Returns indices [E, n_expose], -1 padded."""
        E, Q, dev = self.E, self.Q, self.device
        tauw = self.fields[:, :, F_TAUW].clone()
        tauw = torch.where(bindable_mask, tauw, torch.full_like(tauw, 1e9))
        order = tauw.argsort(dim=1)  # [E,Q] ascending
        top = order[:, :n_expose]
        valid = bindable_mask.gather(1, top)
        return torch.where(valid, top, torch.full_like(top, -1))

    # ------------------------------------------------------------------
    def tick_windows(self) -> torch.Tensor:
        """Decrement τ_w on active tasks; return newly-dropped mask [E,Q]."""
        act = self.active
        self.fields[:, :, F_TAUW] = torch.where(
            act, self.fields[:, :, F_TAUW] - 1.0, self.fields[:, :, F_TAUW]
        )
        dropped = act & (self.fields[:, :, F_TAUW] <= 0)
        if dropped.any():
            t = self.fields[:, :, F_TYPE].long()
            self.n_dropped += torch.bincount(
                t[dropped].reshape(-1), minlength=N_TYPES
            )
            self.active = self.active & ~dropped
        return dropped

    # ------------------------------------------------------------------
    def accumulate(
        self,
        progress_add: torch.Tensor,   # [E,Q] progress this step (0.25 × n_exec)
        crit_ok: torch.Tensor,        # [E,Q] per-type per-step criterion satisfied
        target_init_now: torch.Tensor,  # [E,Q] target's track initialized now
        target_init_pre: torch.Tensor,  # [E,Q] target tracked before this step's physics
    ):
        """Update progress + dwell criterion flags. Call once per env step."""
        exec_step = progress_add > 0
        self.fields[:, :, F_PROG] = self.fields[:, :, F_PROG] + progress_add
        self.crit_all = self.crit_all | ~exec_step  # untouched if no exec
        self.crit_all = self.crit_all & (crit_ok | ~exec_step)
        type_id = self.fields[:, :, F_TYPE].long()
        iff = (type_id == TYPE_IFF) & exec_step
        self.seen_uninit = self.seen_uninit | (iff & ~target_init_pre)

    # ------------------------------------------------------------------
    def finalize(self, final_ok: torch.Tensor):
        """Complete tasks with progress ≥ R. final_ok[E,Q] = success criterion.
        Returns (completed_mask, success_mask)."""
        done = self.active & (self.fields[:, :, F_PROG] >= self.fields[:, :, F_R] - 1e-9)
        success = done & final_ok
        if done.any():
            t = self.fields[:, :, F_TYPE].long()
            self.n_completed += torch.bincount(t[done].reshape(-1), minlength=N_TYPES)
            self.n_succeeded += torch.bincount(
                t[success].reshape(-1), minlength=N_TYPES
            )
            self.active = self.active & ~done
        return done, success

    # ------------------------------------------------------------------
    def metrics(self) -> dict:
        arrived = int(self.n_arrived.sum().item())
        dropped = int(self.n_dropped.sum().item())
        completed = int(self.n_completed.sum().item())
        return dict(
            arrived=arrived, completed=completed, dropped=dropped,
            drop_ratio=dropped / max(arrived, 1),
            per_type_arrived=self.n_arrived.cpu().tolist(),
            per_type_completed=self.n_completed.cpu().tolist(),
            per_type_succeeded=self.n_succeeded.cpu().tolist(),
            per_type_dropped=self.n_dropped.cpu().tolist(),
        )
