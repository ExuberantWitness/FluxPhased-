"""Adversarial jammers for MFR-IQ Phase B (plan §3.1).

Two carrier types (plan §2.1):
  - Pool-upgraded: TargetPool emitter slots flagged `jammer=True`. Tracking/
    jam tasks engage them via Phase A type-4 semantics (target_slot < N_max).
  - Off-board: independent slow-drift emitters at 0.7·region_half, addressed
    via virtual target slot ids N_max..N_max+J-1. Cannot be "killed"; only
    suppressed (antijam action / burn-through) or avoided.

Three scripted policies (plan §2.3): J0 noise, J1 reactive, J2 blink.
Pure-torch vectorised; no python loops over envs.
"""

from __future__ import annotations

import math
import torch


JAM_POLICY_NONE = "none"
JAM_POLICY_NOISE = "noise"
JAM_POLICY_REACTIVE = "reactive"
JAM_POLICY_BLINK = "blink"
JAM_POLICY_LEARNING = "learning"
JAM_POLICIES = (JAM_POLICY_NOISE, JAM_POLICY_REACTIVE, JAM_POLICY_BLINK, JAM_POLICY_LEARNING)


class JammerField:
    """Per-env batched jammer state for both carrier types."""

    def __init__(
        self,
        E: int,
        N_pool: int,
        n_offboard: int = 0,
        policy: str = JAM_POLICY_NOISE,
        jammer_pow_W: float = 50.0,
        region_half_m: float = 15000.0,
        fc_hz: float = 10e9,
        channel_bw_hz: float = 10e6,
        hop_freq_offset_hz: float = 8.0 * 10e6,
        blink_period: int = 10,
        reactive_trigger_steps: int = 3,
        reactive_dwell_steps: int = 20,
        ew_detect_db: float = 20.0,
        ew_cooldown_steps: int = 60,
        device: str = "cuda",
        gen: torch.Generator = None,
    ):
        self.E = int(E)
        self.N_pool = int(N_pool)
        self.J = int(n_offboard)
        self.policy = str(policy)
        self.jammer_pow_W = float(jammer_pow_W)
        self.region_half = float(region_half_m)
        self.fc_hz = float(fc_hz)
        self.channel_bw_hz = float(channel_bw_hz)
        self.hop_freq_offset_hz = float(hop_freq_offset_hz)
        self.blink_period = int(blink_period)
        self.reactive_trigger = int(reactive_trigger_steps)
        self.reactive_dwell = int(reactive_dwell_steps)
        self.ew_detect_db = float(ew_detect_db)
        self.ew_cooldown = int(ew_cooldown_steps)
        self.device = torch.device(device)
        self.gen = gen if gen is not None else torch.Generator(device=self.device)
        self.reset()

    # ------------------------------------------------------------------
    def reset(self):
        E, N, J, dev = self.E, self.N_pool, self.J, self.device
        if J > 0:
            ang0 = torch.linspace(0, 2 * math.pi, J + 1, device=dev)[:-1]
            self.off_base_ang = ang0.unsqueeze(0).expand(E, J).clone()
            self.off_range_m = torch.full((E, J), 0.7 * self.region_half, device=dev)
            self.off_pos = torch.zeros(E, J, 2, device=dev)
            self.off_alive = torch.ones(E, J, dtype=torch.bool, device=dev)
            self.off_illum_count = torch.zeros(E, J, dtype=torch.long, device=dev)
            self.off_dwell_remaining = torch.zeros(E, J, dtype=torch.long, device=dev)
            self.off_phase = torch.arange(J, device=dev).unsqueeze(0).expand(E, J).clone()
            self.off_last_cue = torch.full((E, J), -self.ew_cooldown, dtype=torch.long, device=dev)
        else:
            self.off_pos = torch.zeros(E, 0, 2, device=dev)
            self.off_alive = torch.zeros(E, 0, dtype=torch.bool, device=dev)
            self.off_illum_count = torch.zeros(E, 0, dtype=torch.long, device=dev)
            self.off_dwell_remaining = torch.zeros(E, 0, dtype=torch.long, device=dev)
            self.off_phase = torch.zeros(E, 0, dtype=torch.long, device=dev)
            self.off_last_cue = torch.full((E, 0), -self.ew_cooldown, dtype=torch.long, device=dev)
        self.pool_illum_count = torch.zeros(E, N, dtype=torch.long, device=dev)
        self.pool_dwell_remaining = torch.zeros(E, N, dtype=torch.long, device=dev)
        self.pool_phase = torch.zeros(E, N, dtype=torch.long, device=dev)
        self.pool_last_cue = torch.full((E, N), -self.ew_cooldown, dtype=torch.long, device=dev)
        self.step_idx = torch.zeros(E, dtype=torch.long, device=dev)
        self._refresh_off_pos()
        # LEARNING policy: external (PPO trainer) writes the next active mask
        # here before each update_activation call. None = unset → fall back
        # to all-off safe default at step 0.
        self._active_override_off = None
        # Step-0 cached activation attrs (so physics_step can read before any
        # update_activation call). Pool slots have no jammer flag yet → inactive.
        # Off-board: NOISE always on; REACTIVE off (no illumination yet); BLINK
        # on if phase < half.
        if self.policy == JAM_POLICY_NOISE:
            act_off = self.off_alive.clone()
        elif self.policy == JAM_POLICY_REACTIVE:
            act_off = torch.zeros(E, J, dtype=torch.bool, device=dev)
        elif self.policy == JAM_POLICY_BLINK:
            half = self.blink_period // 2
            phase_off = self.off_phase % self.blink_period
            act_off = self.off_alive & (phase_off < half)
        else:
            act_off = torch.zeros(E, J, dtype=torch.bool, device=dev)
        self.active_pool = torch.zeros(E, N, dtype=torch.bool, device=dev)
        self.active_off = act_off
        self.pow_pool = torch.zeros(E, N, device=dev)
        self.pow_off = self.jammer_pow_W * act_off.float()
        self.freq_pool = torch.full((E, N), self.fc_hz, device=dev)
        self.freq_off = torch.full((E, J), self.fc_hz, device=dev)

    def _refresh_off_pos(self):
        if self.J == 0:
            return
        ang = self.off_base_ang + 0.0174533 * (self.step_idx.float().unsqueeze(1) % 360)
        r = self.off_range_m
        self.off_pos = torch.stack([r * torch.cos(ang), r * torch.sin(ang)], dim=-1)

    # ------------------------------------------------------------------
    def set_active_override_off(self, mask):
        """LEARNING policy only: pre-set the next-step off-board active mask.
        mask: [E, J] bool/0-1. Caller (PPO trainer) writes here BEFORE the
        env's next step(); update_activation reads it under LEARNING policy."""
        if mask is None:
            self._active_override_off = None
            return
        expected = (self.E, max(self.J, 0))
        if tuple(mask.shape[:2]) != expected:
            raise ValueError(
                f"override mask shape {tuple(mask.shape)} leading dims != {expected}"
            )
        self._active_override_off = mask.to(self.device).bool()

    # ------------------------------------------------------------------
    def _illumination_mask(self, subarray_baz, subarray_pos, jammer_pos, beam_width_rad):
        """ill[E,M]: jammer m within beam_width_rad of any subarray's main beam."""
        M = jammer_pos.shape[1]
        delta = jammer_pos.unsqueeze(2) - subarray_pos.unsqueeze(1)   # [E,M,K,2]
        az_s2j = torch.atan2(delta[..., 1], delta[..., 0])            # [E,M,K]
        rel = az_s2j - subarray_baz.unsqueeze(1)
        rel = torch.remainder(rel + math.pi, 2 * math.pi) - math.pi
        return (rel.abs() < beam_width_rad).any(dim=2)               # [E,M]

    # ------------------------------------------------------------------
    def update_activation(
        self,
        pool_jammer_mask,                # [E,N_pool] bool: pool slot is a jammer
        pool_alive,                       # [E,N_pool]
        pool_pos,                         # [E,N_pool,2]
        subarray_baz,                     # [E,K]
        subarray_pos,                     # [E,K,2]
        beam_width_rad,
    ):
        """Advance activation state by one step. Must be called BEFORE physics
        (active/pow/freq feed the JNR matrix build). Returns dict with
        active_pool/active_off/pow_pool/pow_off/freq_pool/freq_off."""
        E, N, J, dev = self.E, self.N_pool, self.J, self.device
        self.step_idx += 1
        self._refresh_off_pos()
        alive_pool = pool_jammer_mask & pool_alive

        ill_pool = self._illumination_mask(
            subarray_baz, subarray_pos, pool_pos, beam_width_rad
        ) & alive_pool
        if J > 0:
            ill_off = self._illumination_mask(
                subarray_baz, subarray_pos, self.off_pos, beam_width_rad
            )
        else:
            ill_off = torch.zeros(E, 0, dtype=torch.bool, device=dev)

        if self.policy == JAM_POLICY_NOISE:
            active_pool = alive_pool.clone()
            active_off = self.off_alive.clone()

        elif self.policy == JAM_POLICY_REACTIVE:
            self.pool_illum_count = torch.where(
                ill_pool,
                self.pool_illum_count + 1,
                torch.zeros_like(self.pool_illum_count),
            )
            self.off_illum_count = torch.where(
                ill_off,
                self.off_illum_count + 1,
                torch.zeros_like(self.off_illum_count),
            )
            triggered_p = self.pool_illum_count >= self.reactive_trigger
            triggered_o = self.off_illum_count >= self.reactive_trigger
            self.pool_dwell_remaining = torch.where(
                triggered_p,
                torch.full_like(self.pool_dwell_remaining, self.reactive_dwell),
                torch.clamp(self.pool_dwell_remaining - 1, min=0),
            )
            self.off_dwell_remaining = torch.where(
                triggered_o,
                torch.full_like(self.off_dwell_remaining, self.reactive_dwell),
                torch.clamp(self.off_dwell_remaining - 1, min=0),
            )
            active_pool = alive_pool & (self.pool_dwell_remaining > 0)
            active_off = self.off_alive & (self.off_dwell_remaining > 0)

        elif self.policy == JAM_POLICY_BLINK:
            half = self.blink_period // 2
            phase_pool = (self.step_idx.unsqueeze(1) % self.blink_period).expand(E, N)
            on_pool = phase_pool < half
            hop_pool = ((phase_pool % half) >= (half // 2)).float()
            if J > 0:
                phase_off = (self.step_idx.unsqueeze(1) + self.off_phase) % self.blink_period
                on_off = phase_off < half
                hop_off = ((phase_off % half) >= (half // 2)).float()
            else:
                on_off = torch.zeros(E, 0, dtype=torch.bool, device=dev)
                hop_off = torch.zeros(E, 0, device=dev)
            active_pool = alive_pool & on_pool
            active_off = self.off_alive & on_off
        elif self.policy == JAM_POLICY_LEARNING:
            # External PPO trainer writes _active_override_off before each
            # step. Pool jammers always on (alive). Off-board follow override.
            active_pool = alive_pool.clone()
            if J > 0:
                ov = self._active_override_off
                if ov is None:
                    active_off = torch.zeros(E, J, dtype=torch.bool, device=dev)
                else:
                    active_off = self.off_alive & ov.bool()
            else:
                active_off = torch.zeros(E, 0, dtype=torch.bool, device=dev)
        else:
            raise ValueError(f"unknown jammer policy: {self.policy!r}")

        if self.policy == JAM_POLICY_BLINK:
            freq_pool = self.fc_hz + hop_pool * self.hop_freq_offset_hz
            freq_off = self.fc_hz + (
                hop_off if J > 0 else torch.zeros(E, 0, device=dev)
            ) * self.hop_freq_offset_hz
        else:
            freq_pool = torch.full((E, N), self.fc_hz, device=dev)
            freq_off = (
                torch.full((E, J), self.fc_hz, device=dev) if J > 0
                else torch.zeros(E, 0, device=dev)
            )

        pow_pool = self.jammer_pow_W * active_pool.float()
        pow_off = self.jammer_pow_W * active_off.float()

        # Cache activation as public attrs (physics_step reads active_off/freq_off).
        self.active_pool = active_pool
        self.active_off = active_off
        self.pow_pool = pow_pool
        self.pow_off = pow_off
        self.freq_pool = freq_pool
        self.freq_off = freq_off
        return dict(
            active_pool=active_pool,
            active_off=active_off,
            pow_pool=pow_pool,
            pow_off=pow_off,
            freq_pool=freq_pool,
            freq_off=freq_off,
            ill_pool=ill_pool,
            ill_off=ill_off,
        )

    # ------------------------------------------------------------------
    def ew_detect(self, jnr_from_pool_db, jnr_from_off_db):
        """EW auto-cue decisions based on this step's per-jammer JNR. Call AFTER
        physics_step. Returns (cue_pool[E,N], cue_off[E,J]) bool masks."""
        N, J, dev = self.N_pool, self.J, self.device
        cool_pool = (
            self.step_idx.unsqueeze(1) - self.pool_last_cue >= self.ew_cooldown
        )
        cue_pool = self.active_pool & cool_pool & (jnr_from_pool_db > self.ew_detect_db)
        self.pool_last_cue = torch.where(
            cue_pool, self.step_idx.unsqueeze(1).expand(-1, N), self.pool_last_cue
        )
        if J > 0:
            cool_off = (
                self.step_idx.unsqueeze(1) - self.off_last_cue >= self.ew_cooldown
            )
            cue_off = self.active_off & cool_off & (jnr_from_off_db > self.ew_detect_db)
            self.off_last_cue = torch.where(
                cue_off, self.step_idx.unsqueeze(1).expand(-1, J), self.off_last_cue
            )
        else:
            cue_off = torch.zeros(self.E, 0, dtype=torch.bool, device=dev)
        return cue_pool, cue_off
