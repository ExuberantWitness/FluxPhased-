"""MTPEDF-style greedy rule scheduler for the MFR-IQ env (plan §5).

Each step, per env:
  1. Sort exposed bindable tasks by urgency key = (tau_w_remaining − est.
     completion time) ascending; ties broken by priority P descending.
  2. Free subarrays bind the most urgent task in order.
  3. Coalition: if the task still cannot finish within its remaining window
     with the currently-assigned subarrays (0.25·n·tau_w_rem < R − progress),
     assign the next free subarray to the same task, until satisfiable or no
     free subarrays remain.
  4. No feasible task → idle (action 0).
  5. Phase B antijam: if env has jammers + enable_antijam_action and a
     subarray's last-step JNR > threshold (30 dB), assign action 9 (antijam)
     instead of scheduling that subarray.

Est. completion time with n subarrays = (R − progress) / (0.25·n) steps.
"""

from __future__ import annotations

import torch

from env.gpu.mfr.task_layer import (
    F_TYPE, F_P, F_TAUW, F_ETA, F_PROG, F_R, F_TGT, F_SECTOR,
    TYPE_IFF, TYPE_COMM, TYPE_TRACK_PRECISE,
)

# Phase B antijam trigger: JNR ≥ 65 dB at subarray victim → spend a subarray
# slot on frequency-hopping suppression. Below this, the 25% aperture loss
# costs more task throughput than the σ_inflation gains; MAPPO can learn a
# finer policy in M7. Calibrated at jammer_pow_W=30W where mean sub JNR=51dB.
ANTIJAM_JNR_DB = 65.0


def rule_actions(env) -> torch.Tensor:
    """Return actions [E,K] int64 for the current env state."""
    tl = env.task_layer
    E, K = env.E, env.K
    dev = env.device
    # Phase B: pass n_pool so off-board virtual slots (>= N_max) are bindable.
    bmask = tl.bindable(env.pool, n_pool=env.N_max) if env.has_jammers else tl.bindable(env.pool)
    exposed = tl.exposed(bmask)  # [E,8] queue idx, -1 padded
    f = tl.fields

    # Track-matching (classical schedulers consume tracker output; the
    # pool-slot→track-slot association is a tracking-system product).
    matched, _, _ = env._matched_track()  # [E,N] pool-slot level
    # trace_P of the matched track per pool slot (precise-track feasibility)
    trace_p = (
        env.tracker_P[:, 0, :, 0, 0] + env.tracker_P[:, 0, :, 2, 2]
    )  # [E,N_trk]
    n_trk = trace_p.shape[1]
    matched_slot = torch.zeros_like(matched, dtype=torch.long)
    # _matched_track returns slot indices; reuse via a second call's slot out
    _, m_slot, _ = env._matched_track()
    trace_of_slot = torch.gather(
        trace_p, 1, m_slot.clamp(min=0)
    )  # [E,N]
    covered_any = env._searched_cells.any(dim=1)  # [E,72]

    acts = torch.zeros(E, K, dtype=torch.long, device=dev)
    # Dynamic binds happening inside this call: task-exposure position →
    # subarrays we just assigned (so later tasks can join in-progress work).
    dyn_join = {}
    for e in range(E):
        exp = exposed[e]
        exp = exp[exp >= 0]
        if exp.numel() == 0:
            continue
        ty = f[e, exp, F_TYPE].long()
        tauw = f[e, exp, F_TAUW]
        prog = f[e, exp, F_PROG]
        R = f[e, exp, F_R].clamp(min=1e-9)
        P = f[e, exp, F_P]
        tgt = f[e, exp, F_TGT].long()
        # Phase B: off-board virtual slots (tgt >= N_max) have no pool-side
        # match/trace entry — clamp to a safe index and zero the lookup so
        # the hopeless flag never reads a stale value.
        tgt_in_pool = tgt < env.N_max
        tgt_safe = tgt.clamp(min=0, max=env.N_max - 1)
        matched_e = matched[e][tgt_safe]
        matched_e = torch.where(tgt_in_pool, matched_e, torch.zeros_like(matched_e))
        tp_tgt = trace_of_slot[e][tgt_safe]
        tp_tgt = torch.where(tgt_in_pool, tp_tgt, torch.zeros_like(tp_tgt))
        # IFF on an already-tracked target can never succeed (needs an
        # uninit→init transition during dwell) → pure capacity waste, skip.
        iff_hopeless = (ty == TYPE_IFF) & matched_e
        # precise-track hopeless: matched track's trace_P far from tau_track
        # threshold and dwell is short → convergence won't happen in time.
        pt_hopeless = (ty == TYPE_TRACK_PRECISE) & matched_e & (
            tp_tgt > 4.0 * env.tau_track
        )
        # search-task bonus: uncovered cells already swept by anyone count
        # toward the criterion → fewer steps needed than R alone implies.
        sec = f[e, exp, F_SECTOR].long()
        cell_w = 2.0 * 3.141592653589793 / env.n_search_cells
        offs = torch.arange(8, device=dev)
        sec_cells = (sec.unsqueeze(-1) + offs) % env.n_search_cells
        sec_cov = torch.gather(
            covered_any[e].unsqueeze(0).expand(len(exp), -1), 1, sec_cells
        )  # [n_exp,8]
        n_uncov = (~sec_cov).sum(dim=1).float()
        # Effective remaining work: progress resource + (for search) the cells
        # still uncovered. Search completion ALSO needs the 8-cell sweep; a
        # coalition of n subarrays covers n new cells/step.
        is_search = (ty == 3) | (ty == 6)
        eff_need = (R - prog).clamp(min=0.0)
        eff_need = torch.where(
            is_search, torch.maximum(eff_need, 0.25 * n_uncov), eff_need
        )
        # Urgency = slack (steps to spare if served by the whole array):
        # tauw − time-to-complete with all K subarrays. Absolute-step form
        # spreads resources across task types (ratio form over-concentrates
        # on short-window types and starves long-window precise-track/comm).
        Kf = float(K)
        slack_1 = tauw - eff_need / 0.25         # slack with ONE subarray
        slack_K = tauw - eff_need / (0.25 * Kf)  # slack with the whole array
        frac_full = (eff_need / 0.25) / Kf / tauw.clamp(min=1.0)  # >1 ⇒ hopeless
        hopeless = iff_hopeless | pt_hopeless
        n = exp.numel()
        urgency = [0.0] * n
        for i in range(n):
            if bool(hopeless[i]):
                urgency[i] = 1e9
            elif float(slack_1[i]) >= 0.0:
                # 1 subarray suffices → assign exactly 1, EDF by remaining window
                urgency[i] = -1e6 + float(tauw[i])
            elif int(ty[i]) == TYPE_COMM:
                # comm is the only type whose per-step criterion forces a
                # ≥2-subarray dwell (n_need=2) while R=5 → single-starved at
                # ~33% per attempt under load. Bump past cheap tasks so the
                # pair is assembled immediately instead of after them.
                urgency[i] = -5e5 + float(slack_K[i])
            else:
                # needs coalition → concentrate, EDF by whole-array slack
                urgency[i] = float(slack_K[i])
        order = sorted(range(n), key=lambda i: (urgency[i], -float(P[i])))
        feasible_rank = {}
        for pos, i in enumerate(order):
            cap = 0.25 * (Kf - pos)  # progress/step if i precedes pos subarrays
            feasible_rank[i] = cap * float(tauw[i]) >= float(eff_need[i])
        order.sort(
            key=lambda i: (not feasible_rank[i], urgency[i], -float(P[i]))
        )
        free = list(range(K))
        # Phase 1: EDF order; assign full coalitions to tasks satisfiable
        # within their remaining window using the remaining free subarrays.
        for i in order:
            if not free:
                break
            if bool(hopeless[i]) or not feasible_rank[i]:
                continue
            need = float(eff_need[i])
            w = float(tauw[i])
            # coalition: subarrays needed to finish within window
            n_need = max(1, int(torch.ceil(torch.tensor(need / (0.25 * max(w, 1.0))))))
            if int(ty[i]) == TYPE_COMM:
                n_need = max(2, n_need)  # comm criterion: ≥2 links every dwell step
            if n_need > len(free):
                continue  # cannot finish within window with available subarrays
            for _ in range(n_need):
                k = free.pop(0)
                acts[e, k] = i + 1  # exposed position → action
            dyn_join[(e, int(exp[i]))] = dyn_join.get((e, int(exp[i])), 0) + n_need
        # Phase 2: best-effort — leftover free subarrays join the most urgent
        # feasible task, preferring tasks already in progress (their progress
        # carries over, so a small top-up can finish them inside the window).
        prev_bound = env.bound_task  # [E,K] queue-slot ids from last step
        eligible = [
            i for i in order
            if not bool(hopeless[i]) and feasible_rank[i]
        ]
        def in_progress_key(i):
            qi = int(exp[i])
            was = int((prev_bound[e] == qi).sum()) + dyn_join.get((e, qi), 0)
            return -was  # more already-bound subarrays first
        eligible.sort(key=lambda i: (in_progress_key(i), urgency[i]))
        # assign ALL leftover free subarrays to the single best in-progress
        # (or most-urgent) task — splitting across tasks starves every dwell
        for k in free:
            if eligible:
                acts[e, k] = eligible[0] + 1

    # Phase B antijam override: subarray whose last-step JNR > threshold
    # switches to action 9 (frequency-hop). Highest-JNR subarray first so a
    # single dominant jammer gets exactly one hop-subarray (overspending on
    # antijam starves the scheduler). When antijam is disabled this is skipped.
    # NOTE: env.last_jnr_at_sub is LINEAR JNR (sum of jnr_full linear values).
    if getattr(env, "enable_antijam_action", False):
        last_jnr = getattr(env, "last_jnr_at_sub", None)
        if last_jnr is not None:
            jnr_db = 10.0 * torch.log10(last_jnr.clamp(min=1e-15))
            threat = jnr_db >= ANTIJAM_JNR_DB
            if threat.any():
                # Apply per-env: only the worst-JNR subarray in each env
                # switches to antijam (keeps aperture loss to 25%).
                worst_k = jnr_db.argmax(dim=1)          # [E]
                for e in range(E):
                    if not threat[e].any():
                        continue
                    k = int(worst_k[e].item())
                    acts[e, k] = env.n_act - 1          # last action slot = antijam
    return acts
