"""Stage-A entry point (plan §8).

Examples:
  python run_stage_a.py --algo rule   --load 1.5 --seed 0 --out experiments/mfr/rule_l1.5_s0/
  python run_stage_a.py --algo random --load 1.5 --seed 0 --out ...
  python run_stage_a.py --algo mappo  --load 1.5 --seed 0 --iters 200 --out ...
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time

import torch

sys.path.insert(0, "/home/ubuntu/CODE/FluxPhased-")

from env.gpu.mfr.mfr_env import MfrVecEnv, OBS_DIM, PHYS_DEFAULTS, MFR_DEFAULTS
from algo._shared.pilot.mfr.rule_scheduler import rule_actions
from algo._shared.pilot.mfr.random_scheduler import random_actions


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--algo", choices=["rule", "random", "mappo"], required=True)
    p.add_argument("--load", type=float, default=1.5)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--iters", type=int, default=200)
    p.add_argument("--drop-penalty-scale", type=float, default=7.0)
    p.add_argument("--n-envs", type=int, default=32)
    p.add_argument("--eval-episodes", type=int, default=100)
    p.add_argument("--out", required=True)
    return p.parse_args()


def main():
    a = parse_args()
    os.makedirs(a.out, exist_ok=True)
    cfg = dict(
        algo=a.algo, load=a.load, seed=a.seed, iters=a.iters, n_envs=a.n_envs,
        eval_episodes=a.eval_episodes, drop_penalty_scale=a.drop_penalty_scale,
        phys=PHYS_DEFAULTS, mfr=MFR_DEFAULTS, obs_dim=OBS_DIM,
    )
    with open(os.path.join(a.out, "config.json"), "w") as f:
        json.dump(cfg, f, indent=2)

    if a.algo in ("rule", "random"):
        sched = rule_actions if a.algo == "rule" else random_actions
        env = MfrVecEnv(n_envs=a.eval_episodes, K=4, N_max=12, device="cuda",
                        seed=a.seed, load_factor=a.load)
        env.reset()
        t0 = time.time()
        tot_rew = 0.0
        for _ in range(env.episode_steps):
            obs, r, done, _ = env.step(sched(env))
            tot_rew += float(r[:, 0].mean())
        m = env.task_layer.metrics()
        m["mean_team_reward"] = tot_rew
        m["wall_sec"] = time.time() - t0
        with open(os.path.join(a.out, "metrics.csv"), "w", newline="") as f:
            w = csv.writer(f)
            for k, v in m.items():
                w.writerow([k, v])
        print(f"{a.algo} load={a.load} seed={a.seed}: "
              f"drop {m['drop_ratio']:.3f} arrived {m['arrived']} "
              f"completed {m['completed']} reward {tot_rew:.1f}")
        return

    # mappo
    from algo._shared.pilot.mfr.mappo_trainer import MfrMAPPO
    tr = MfrMAPPO(seed=a.seed, n_envs=a.n_envs, device="cuda",
                  load_factor=a.load, log_dir=a.out, total_iters=a.iters,
                  drop_penalty_scale=a.drop_penalty_scale)
    status = tr.train()
    # final greedy eval at eval_episodes envs
    eval_env = MfrVecEnv(n_envs=a.eval_episodes, K=4, N_max=12, device="cuda",
                         seed=a.seed + 777, load_factor=a.load)
    tr.env = eval_env
    tr.E, tr.K = eval_env.E, eval_env.K
    m = tr.evaluate(n_episodes=a.eval_episodes, greedy=True, seed_offset=999)
    m["train_status"] = status
    with open(os.path.join(a.out, "metrics.csv"), "w", newline="") as f:
        w = csv.writer(f)
        for k, v in m.items():
            w.writerow([k, v])
    print(f"mappo load={a.load} seed={a.seed}: status {status} "
          f"drop {m['drop_ratio']:.3f} arrived {m['arrived']} completed {m['completed']}")


if __name__ == "__main__":
    main()
