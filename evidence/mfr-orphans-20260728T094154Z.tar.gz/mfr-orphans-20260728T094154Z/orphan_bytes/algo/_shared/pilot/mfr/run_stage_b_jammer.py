"""Phase B learning-jammer entry point (M7).

Examples:
  python run_stage_b_jammer.py --seed 0 --iters 100 --out experiments/mfr_phaseB/jammer_s0
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time

import torch

sys.path.insert(0, "/home/ubuntu/CODE/FluxPhased-")

from algo._shared.pilot.mfr.jammer_trainer import JammerPPO


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--iters", type=int, default=100)
    p.add_argument("--n-envs", type=int, default=32)
    p.add_argument("--n-offboard", type=int, default=2)
    p.add_argument("--pool-jammer-frac", type=float, default=0.20)
    p.add_argument("--jammer-pow-w", type=float, default=30.0)
    p.add_argument("--load", type=float, default=1.5)
    p.add_argument("--eval-episodes", type=int, default=100)
    p.add_argument("--out", required=True)
    return p.parse_args()


def main():
    a = parse_args()
    os.makedirs(a.out, exist_ok=True)
    cfg = dict(
        seed=a.seed, iters=a.iters, n_envs=a.n_envs,
        n_offboard=a.n_offboard, pool_jammer_frac=a.pool_jammer_frac,
        jammer_pow_w=a.jammer_pow_w, load=a.load,
        eval_episodes=a.eval_episodes,
    )
    with open(os.path.join(a.out, "config.json"), "w") as f:
        json.dump(cfg, f, indent=2)
    tr = JammerPPO(
        seed=a.seed, n_envs=a.n_envs, device="cuda",
        load_factor=a.load, radar_opponent="rule",
        n_offboard_jammers=a.n_offboard,
        pool_jammer_frac_of_emitters=a.pool_jammer_frac,
        jammer_pow_W=a.jammer_pow_w,
        log_dir=a.out, total_iters=a.iters,
    )
    print(f"obs_dim {tr.obs_dim}, J {tr.J}, E {tr.E}, K {tr.K}")
    status = tr.train()
    m = tr.evaluate(n_episodes=a.eval_episodes, greedy=True)
    m["train_status"] = status
    with open(os.path.join(a.out, "metrics.csv"), "w", newline="") as f:
        w = csv.writer(f)
        for k, v in m.items():
            w.writerow([k, v])
    print(
        f"jammer seed={a.seed} pow={a.jammer_pow_w}W: status {status} "
        f"drop {m['drop_ratio']:.3f} arrived {m['arrived']} "
        f"completed {m['completed']} succeeded {sum(m['per_type_succeeded'])}"
    )


if __name__ == "__main__":
    main()
