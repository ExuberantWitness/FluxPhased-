"""Phase B league eval (M8): round-robin radar × jammer matchups.

Pairwise evaluate radar strategies (rule / mappo) against jammer strategies
(scripted noise/reactive/blink + learning). Returns drop_ratio, mean reward,
and per-type completion signatures per matchup.

G2'b gate (plan §7): against the LEARNING jammer, MAPPO radar drop_ratio must
beat rule radar drop_ratio by ≥ 5 pp with paired t-test p<0.05 across 8 seeds.

Usage:
  python league_eval.py --radar rule,rule,rule --jammer noise,reactive,blink --seed 0 --n-envs 32 --out ...
  python league_eval.py --radar rule,mappo --jammer learning --seeds 0,1,2,3,4,5,6,7 --out ...
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time

import torch

sys.path.insert(0, "/home/ubuntu/CODE/FluxPhased-")

from env.gpu.mfr.mfr_env import MfrVecEnv
from env.gpu.mfr.jammer import (
    JAM_POLICIES, JAM_POLICY_NONE, JAM_POLICY_NOISE, JAM_POLICY_REACTIVE,
    JAM_POLICY_BLINK, JAM_POLICY_LEARNING,
)
from algo._shared.pilot.mfr.rule_scheduler import rule_actions
from algo._shared.pilot.mfr.random_scheduler import random_actions
from algo._shared.pilot.mfr.jammer_trainer import JammerPPO


_JAM_CHOICES = [JAM_POLICY_NONE] + list(JAM_POLICIES)


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--radar", default="rule",
                   help="Comma-list: rule / random / mappo[:ckpt_path]")
    p.add_argument("--jammer", default="noise,reactive,blink,learning",
                   help="Comma-list: none / noise / reactive / blink / learning[:ckpt_path]")
    p.add_argument("--seeds", default="0")
    p.add_argument("--n-envs", type=int, default=32)
    p.add_argument("--episodes-per-seed", type=int, default=4)  # 32 envs × 4 eps = 128
    p.add_argument("--n-offboard", type=int, default=2)
    p.add_argument("--pool-jammer-frac", type=float, default=0.20)
    p.add_argument("--jammer-pow-w", type=float, default=30.0)
    p.add_argument("--load", type=float, default=1.5)
    p.add_argument("--enable-antijam", action="store_true")
    p.add_argument("--out", required=True)
    return p.parse_args()


def _parse_pair(s):
    """Split 'learning:/path/to.pt' → ('learning', '/path/to.pt')."""
    if ":" in s:
        k, v = s.split(":", 1)
        return k.strip(), v.strip()
    return s.strip(), None


def _make_radar(kind, ckpt, env, seed):
    """Return a callable(env)->actions implementing the chosen radar."""
    if kind == "rule":
        return rule_actions
    if kind == "random":
        return random_actions
    if kind == "mappo":
        if ckpt is None:
            raise ValueError("mappo radar requires --radar mappo:/path/to/ckpt.pt")
        from algo._shared.pilot.mfr.mappo_trainer import Actor
        state = torch.load(ckpt, map_location=env.device)
        actor = Actor().to(env.device)
        actor.load_state_dict(state["actor"])
        actor.eval()

        def _mappo(env):
            with torch.no_grad():
                obs = env._build_obs()
                mask = env.action_mask()
                logits = actor(obs).masked_fill(~mask, -1e9)
                return logits.argmax(dim=-1)
        return _mappo
    raise ValueError(f"unknown radar kind: {kind!r}")


def _make_jammer(kind, ckpt, env, seed):
    """Return a callable(env)->jammer_actions or None for scripted policies.

    None means 'env.step() uses scripted policy internally'.
    For learning, return a callable that reads env.jammer_obs() and predicts.
    """
    if kind in (JAM_POLICY_NONE, JAM_POLICY_NOISE, JAM_POLICY_REACTIVE, JAM_POLICY_BLINK):
        return None
    if kind == JAM_POLICY_LEARNING:
        if ckpt is None:
            raise ValueError("learning jammer requires --jammer learning:/path/to/ckpt.pt")
        obs_dim = env.jammer_obs_dim()
        actor = JammerPPO.__new__(JammerPPO)  # bypass __init__
        from algo._shared.pilot.mfr.jammer_trainer import BernoulliActor
        a = BernoulliActor(obs_dim, env.jammer.J).to(env.device)
        state = torch.load(ckpt, map_location=env.device)
        a.load_state_dict(state["actor"])
        a.eval()

        def _learning(env):
            with torch.no_grad():
                logits = a(env.jammer_obs())
                return (torch.sigmoid(logits) > 0.5).float()
        return _learning
    raise ValueError(f"unknown jammer kind: {kind!r}")


def run_matchup(radar_kind, radar_ckpt, jammer_kind, jammer_ckpt,
                seed, n_envs, episodes_per_seed, args):
    """Run one (radar × jammer × seed) matchup. Returns metric dict."""
    env = MfrVecEnv(
        n_envs=n_envs, K=4, N_max=12, device="cuda",
        seed=seed, load_factor=args.load,
        jammer_policy=(jammer_kind if jammer_kind != JAM_POLICY_NONE else None),
        n_offboard_jammers=args.n_offboard,
        pool_jammer_frac_of_emitters=args.pool_jammer_frac,
        jammer_pow_W=args.jammer_pow_w,
        enable_antijam_action=args.enable_antijam,
    )
    radar_fn = _make_radar(radar_kind, radar_ckpt, env, seed)
    jammer_fn = _make_jammer(jammer_kind, jammer_ckpt, env, seed)
    env.reset()
    base = env.task_layer.metrics()
    tot_rew = 0.0
    for _ in range(episodes_per_seed):
        for _ in range(env.episode_steps):
            j_act = jammer_fn(env) if jammer_fn is not None else None
            r_act = radar_fn(env)
            obs, r, done, _ = env.step(r_act, jammer_actions=j_act)
            tot_rew += float(r[:, 0].mean())
        env.reset()
    m = env.task_layer.metrics()
    arr = max(m["arrived"] - base["arrived"], 1)
    return dict(
        radar=radar_kind, jammer=jammer_kind, seed=seed,
        arrived=m["arrived"] - base["arrived"],
        completed=m["completed"] - base["completed"],
        dropped=m["dropped"] - base["dropped"],
        succeeded=sum(m["per_type_succeeded"]) - sum(base["per_type_succeeded"]),
        drop_ratio=(m["dropped"] - base["dropped"]) / arr,
        mean_team_reward=tot_rew / episodes_per_seed,
    )


def main():
    a = parse_args()
    os.makedirs(a.out, exist_ok=True)
    radar_list = [_parse_pair(s) for s in a.radar.split(",")]
    jammer_list = [_parse_pair(s) for s in a.jammer.split(",")]
    seeds = [int(s) for s in a.seeds.split(",")]
    cfg = dict(
        radar=radar_list, jammer=jammer_list, seeds=seeds,
        n_envs=a.n_envs, episodes_per_seed=a.episodes_per_seed,
        n_offboard=a.n_offboard, pool_jammer_frac=a.pool_jammer_frac,
        jammer_pow_w=a.jammer_pow_w, load=a.load,
        enable_antijam=a.enable_antijam,
    )
    with open(os.path.join(a.out, "league_config.json"), "w") as f:
        json.dump(cfg, f, indent=2, default=str)

    rows = []
    t0 = time.time()
    for radar_kind, radar_ckpt in radar_list:
        for jammer_kind, jammer_ckpt in jammer_list:
            for seed in seeds:
                t_m = time.time()
                m = run_matchup(
                    radar_kind, radar_ckpt, jammer_kind, jammer_ckpt,
                    seed, a.n_envs, a.episodes_per_seed, a,
                )
                m["wall_sec"] = time.time() - t_m
                rows.append(m)
                print(
                    f"radar={radar_kind} jammer={jammer_kind} seed={seed}: "
                    f"drop {m['drop_ratio']:.3f} reward {m['mean_team_reward']:.1f} "
                    f"({m['wall_sec']:.1f}s)"
                )

    with open(os.path.join(a.out, "league_results.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f"\nLeague done in {time.time() - t0:.1f}s, "
          f"{len(rows)} matchups → {a.out}/league_results.csv")


if __name__ == "__main__":
    main()
