"""Stage-B entry point: rule/random eval under adversarial jammers (plan §5).

Gate G1': rule drop_ratio under each scripted jammer policy must be ≥ 0.19
(≥ 2× Phase A baseline 0.090), proving jammers break the near-Nash floor.
Random must be worse than rule by ≥ 10pp (mirrors Phase A G1 contract).

Examples:
  python run_stage_b.py --algo rule   --jammer noise     --seed 0 --out ...
  python run_stage_b.py --algo random --jammer reactive  --seed 0 --out ...
  python run_stage_b.py --algo rule   --jammer blink     --seed 0 --out ...
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time

import torch

sys.path.insert(0, "/home/ubuntu/CODE/FluxPhased-")

from env.gpu.mfr.mfr_env import MfrVecEnv, OBS_DIM, OBS_DIM_JAMMER, PHYS_DEFAULTS, MFR_DEFAULTS
from env.gpu.mfr.jammer import JAM_POLICIES, JAM_POLICY_NONE
from algo._shared.pilot.mfr.rule_scheduler import rule_actions
from algo._shared.pilot.mfr.random_scheduler import random_actions


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--algo", choices=["rule", "random"], required=True)
    p.add_argument(
        "--jammer", choices=list(JAM_POLICIES) + [JAM_POLICY_NONE],
        default=JAM_POLICY_NONE,
    )
    p.add_argument("--n-offboard", type=int, default=2)
    p.add_argument("--pool-jammer-frac", type=float, default=0.20)
    p.add_argument("--jammer-pow-w", type=float, default=100.0)
    p.add_argument("--enable-antijam", action="store_true",
                   help="Expose action 9 (frequency-hop) to the scheduler.")
    p.add_argument("--load", type=float, default=1.5)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--eval-episodes", type=int, default=100)
    p.add_argument("--out", required=True)
    return p.parse_args()


def main():
    a = parse_args()
    os.makedirs(a.out, exist_ok=True)
    cfg = dict(
        algo=a.algo, jammer=a.jammer, load=a.load, seed=a.seed,
        n_envs=a.eval_episodes, eval_episodes=a.eval_episodes,
        n_offboard=a.n_offboard, pool_jammer_frac=a.pool_jammer_frac,
        jammer_pow_w=a.jammer_pow_w, enable_antijam=a.enable_antijam,
        phys=PHYS_DEFAULTS, mfr=MFR_DEFAULTS, obs_dim=OBS_DIM,
        obs_dim_jammer=OBS_DIM_JAMMER,
    )
    with open(os.path.join(a.out, "config.json"), "w") as f:
        json.dump(cfg, f, indent=2)

    sched = rule_actions if a.algo == "rule" else random_actions
    env = MfrVecEnv(
        n_envs=a.eval_episodes, K=4, N_max=12, device="cuda",
        seed=a.seed, load_factor=a.load,
        jammer_policy=(a.jammer if a.jammer != JAM_POLICY_NONE else None),
        n_offboard_jammers=a.n_offboard,
        pool_jammer_frac_of_emitters=a.pool_jammer_frac,
        jammer_pow_W=a.jammer_pow_w,
        enable_antijam_action=a.enable_antijam,
    )
    env.reset()
    t0 = time.time()
    tot_rew = 0.0
    for _ in range(env.episode_steps):
        # action sampling for random uses env.action_mask() so antijam slot
        # (action 9) is in-policy when --enable-antijam is set.
        obs, r, done, _ = env.step(sched(env))
        tot_rew += float(r[:, 0].mean())
    m = env.task_layer.metrics()
    m["mean_team_reward"] = tot_rew
    m["wall_sec"] = time.time() - t0
    if env.has_jammers:
        m["off_board_jammers_active"] = (
            float(env.jammer.active_off.sum(dim=1).float().mean().item())
        )
    with open(os.path.join(a.out, "metrics.csv"), "w", newline="") as f:
        w = csv.writer(f)
        for k, v in m.items():
            w.writerow([k, v])
    print(
        f"{a.algo} jammer={a.jammer} pow={a.jammer_pow_w}W "
        f"antijam={int(a.enable_antijam)} load={a.load} seed={a.seed}: "
        f"drop {m['drop_ratio']:.3f} arrived {m['arrived']} "
        f"completed {m['completed']} reward {tot_rew:.1f}"
    )


if __name__ == "__main__":
    main()
