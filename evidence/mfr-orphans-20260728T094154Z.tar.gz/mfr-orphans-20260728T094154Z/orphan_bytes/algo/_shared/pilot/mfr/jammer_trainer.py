"""Learning jammer PPO trainer for MFR-IQ Phase B (plan §6, M7).

Single central agent controls all J off-board jammers as a multi-binary
action (independent Bernoulli per jammer). Obs is env-side state (radar
subarray activity, jammer illumination history, pool aggregates) — NO
privileged tracker god-view. Reward is the NEGATIVE radar team reward
(zero-sum: jammer's gain = radar's loss).

Architecture:
  - Actor: jammer_obs_dim → 128×128 Tanh → J logits (sigmoid output for
    independent Bernoulli per jammer).
  - Critic: same obs → 128×128 Tanh → V (central value, single agent).

PPO: lr 3e-4, γ 0.99, GAE λ 0.95, clip 0.2, entropy 0.01→0.005 linear over
first 30% of training, value coef 0.5, grad clip 0.5. Each iteration rolls
out T×E steps under a rule radar opponent; 4 epochs × 4 minibatches.

G2'a gate (plan §7): after training, the learning jammer's drop_ratio under
a rule-radar opponent must exceed the best scripted (blink) drop_ratio by
≥ 5 pp.
"""

from __future__ import annotations

import csv
import math
import os
import time

import torch
import torch.nn as nn

import sys
sys.path.insert(0, "/home/ubuntu/CODE/FluxPhased-")

from env.gpu.mfr.mfr_env import MfrVecEnv
from env.gpu.mfr.jammer import JAM_POLICY_LEARNING
from algo._shared.pilot.mfr.rule_scheduler import rule_actions


def _orthogonal_init(module, gain=math.sqrt(2.0)):
    if isinstance(module, nn.Linear):
        nn.init.orthogonal_(module.weight, gain=gain)
        nn.init.zeros_(module.bias)


class BernoulliActor(nn.Module):
    """Multi-binary actor: outputs J independent Bernoulli logits."""

    def __init__(self, obs_dim, n_jammers, hidden=128):
        super().__init__()
        self.n_jammers = int(n_jammers)
        self.net = nn.Sequential(
            nn.Linear(obs_dim, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, self.n_jammers),
        )
        self.net.apply(_orthogonal_init)
        nn.init.orthogonal_(self.net[-1].weight, gain=0.01)

    def forward(self, obs):
        return self.net(obs)


class Critic(nn.Module):
    def __init__(self, in_dim, hidden=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1),
        )
        self.net.apply(_orthogonal_init)
        nn.init.orthogonal_(self.net[-1].weight, gain=1.0)

    def forward(self, x):
        return self.net(x).squeeze(-1)


class JammerPPO:
    def __init__(
        self,
        seed=0,
        n_envs=32,
        device="cuda",
        load_factor=1.5,
        radar_opponent="rule",
        n_offboard_jammers=2,
        pool_jammer_frac_of_emitters=0.20,
        jammer_pow_W=30.0,
        log_dir=None,
        total_iters=200,
        drop_penalty_scale=7.0,
    ):
        self.seed = int(seed)
        self.device = device
        self.total_iters = int(total_iters)
        self.radar_opponent = str(radar_opponent)
        torch.manual_seed(self.seed)

        self.env = MfrVecEnv(
            n_envs=n_envs, K=4, N_max=12, device=device,
            seed=self.seed, load_factor=load_factor,
            jammer_policy=JAM_POLICY_LEARNING,
            n_offboard_jammers=n_offboard_jammers,
            pool_jammer_frac_of_emitters=pool_jammer_frac_of_emitters,
            jammer_pow_W=jammer_pow_W,
            enable_antijam_action=False,  # rule radar: antijam trigger is off
            drop_penalty_scale=drop_penalty_scale,
        )
        self.E, self.K = self.env.E, self.env.K
        self.J = self.env.jammer.J
        self.obs_dim = self.env.jammer_obs_dim()
        self.actor = BernoulliActor(self.obs_dim, self.J).to(device)
        self.critic = Critic(self.obs_dim).to(device)
        self.opt = torch.optim.Adam(
            list(self.actor.parameters()) + list(self.critic.parameters()),
            lr=3e-4,
        )
        self.gamma, self.gae_lam, self.clip = 0.99, 0.95, 0.2
        self.log_dir = log_dir
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)

    # ------------------------------------------------------------------
    def _entropy_coef(self, it):
        # Anneal 0.01 → 0.005 over first 30%, then 0.005 → 0.001 over last 50%.
        # Sharp late anneal forces commitment past the greedy=0.5 threshold.
        frac = it / max(self.total_iters - 1, 1)
        if frac < 0.3:
            return 0.01 + (0.005 - 0.01) * (frac / 0.3)
        if frac < 0.5:
            return 0.005
        return 0.005 + (0.001 - 0.005) * ((frac - 0.5) / 0.5)

    # ------------------------------------------------------------------
    def _radar_actions(self, env):
        if self.radar_opponent == "rule":
            return rule_actions(env)
        raise ValueError(f"unknown radar_opponent: {self.radar_opponent!r}")

    # ------------------------------------------------------------------
    def train(self):
        env, E, J, dev = self.env, self.E, self.J, self.device
        T = env.episode_steps
        log_path = os.path.join(self.log_dir, "train_curve.csv") if self.log_dir else None
        if log_path:
            f_log = open(log_path, "w", newline="")
            writer = csv.writer(f_log)
            writer.writerow([
                "iter", "entropy", "kl", "policy_loss", "value_loss",
                "ep_jammer_reward", "drop_ratio", "succeeded", "arrived",
                "active_frac", "entropy_coef", "sec_per_iter",
            ])

        collapse_streak = 0
        status = "OK"
        prev = dict(arrived=0, dropped=0, succeeded=0)
        for it in range(self.total_iters):
            t0 = time.time()
            env.reset()
            m0 = env.task_layer.metrics()
            base_arrived, base_dropped = m0["arrived"], m0["dropped"]
            base_succ = sum(m0["per_type_succeeded"])

            b_obs = torch.zeros(T, E, self.obs_dim, device=dev)
            b_act = torch.zeros(T, E, J, device=dev)
            b_logp = torch.zeros(T, E, device=dev)
            b_rew = torch.zeros(T, E, device=dev)
            b_val = torch.zeros(T, E, device=dev)
            b_done = torch.zeros(T, E, device=dev)

            with torch.no_grad():
                for t in range(T):
                    j_obs = env.jammer_obs()
                    logits = self.actor(j_obs)                       # [E, J]
                    dist = torch.distributions.Bernoulli(logits=logits)
                    jam_act = dist.sample()                          # [E, J] {0,1}
                    logp = dist.log_prob(jam_act).sum(dim=-1)        # [E]
                    r_act = self._radar_actions(env)
                    obs_r, rew_r, done, _ = env.step(r_act, jammer_actions=jam_act)
                    # Jammer reward = negative radar team reward (zero-sum)
                    jam_rew = -rew_r[:, 0]
                    b_obs[t] = j_obs
                    b_act[t] = jam_act
                    b_logp[t] = logp
                    b_rew[t] = jam_rew
                    b_done[t] = done.float()
                    b_val[t] = self.critic(j_obs)

            # GAE
            adv = torch.zeros(T, E, device=dev)
            lastgae = torch.zeros(E, device=dev)
            for t in reversed(range(T)):
                nextval = b_val[t + 1] if t < T - 1 else torch.zeros(E, device=dev)
                nonterm = 1.0 - b_done[t]
                delta = b_rew[t] + self.gamma * nextval * nonterm - b_val[t]
                lastgae = delta + self.gamma * self.gae_lam * nonterm * lastgae
                adv[t] = lastgae
            ret = adv + b_val

            f_obs = b_obs.reshape(T * E, self.obs_dim)
            f_act = b_act.reshape(T * E, J)
            f_logp = b_logp.reshape(T * E)
            f_adv = adv.reshape(T * E)
            f_ret = ret.reshape(T * E)
            f_adv = (f_adv - f_adv.mean()) / (f_adv.std() + 1e-8)

            n = T * E
            mb = n // 4
            ent_coef = self._entropy_coef(it)
            stats = dict(entropy=0.0, kl=0.0, policy_loss=0.0, value_loss=0.0)
            nupd = 0
            for _ in range(4):
                perm = torch.randperm(n, device=dev)
                for mb_i in range(4):
                    idx = perm[mb_i * mb:(mb_i + 1) * mb]
                    mo = f_obs[idx]
                    ma = f_act[idx]
                    mlp = f_logp[idx]
                    madv = f_adv[idx]
                    mret = f_ret[idx]
                    logits = self.actor(mo)
                    dist = torch.distributions.Bernoulli(logits=logits)
                    logp = dist.log_prob(ma).sum(dim=-1)
                    ratio = (logp - mlp).exp()
                    s1 = ratio * madv
                    s2 = ratio.clamp(1 - self.clip, 1 + self.clip) * madv
                    policy_loss = -torch.min(s1, s2).mean()
                    entropy = dist.entropy().sum(dim=-1).mean()
                    kl = (mlp - logp).mean()

                    v = self.critic(mo)
                    value_loss = 0.5 * (v - mret).pow(2).mean()

                    loss = policy_loss + 0.5 * value_loss - ent_coef * entropy
                    self.opt.zero_grad()
                    loss.backward()
                    nn.utils.clip_grad_norm_(
                        list(self.actor.parameters()) + list(self.critic.parameters()),
                        0.5,
                    )
                    self.opt.step()
                    stats["entropy"] += float(entropy.detach())
                    stats["kl"] += float(kl.detach())
                    stats["policy_loss"] += float(policy_loss.detach())
                    stats["value_loss"] += float(value_loss.detach())
                    nupd += 1
            for k in stats:
                stats[k] /= nupd

            tl = env.task_layer
            m1 = tl.metrics()
            arrived = m1["arrived"] - base_arrived
            dropped = m1["dropped"] - base_dropped
            succeeded = sum(m1["per_type_succeeded"]) - base_succ
            drop_ratio = dropped / max(arrived, 1)
            ep_jam_rew = float(b_rew.sum(dim=0).mean())
            active_frac = float(b_act.mean().item())
            if log_path:
                writer.writerow([
                    it, stats["entropy"], stats["kl"], stats["policy_loss"],
                    stats["value_loss"], ep_jam_rew, drop_ratio,
                    succeeded, arrived, active_frac,
                    ent_coef, time.time() - t0,
                ])
                f_log.flush()

            if abs(stats["policy_loss"]) < 1e-7 and stats["kl"] < 1e-5:
                collapse_streak += 1
            else:
                collapse_streak = 0
            if collapse_streak >= 10:
                status = "FAIL_COLLAPSE"
                break

        if log_path:
            f_log.close()
        if self.log_dir:
            torch.save(
                dict(actor=self.actor.state_dict(),
                     critic=self.critic.state_dict()),
                os.path.join(self.log_dir, "final.pt"),
            )
        return status

    # ------------------------------------------------------------------
    @torch.no_grad()
    def evaluate(self, n_episodes=100, greedy=True, seed_offset=10000):
        env = self.env
        E = env.E
        env.gen.manual_seed(self.seed + seed_offset)
        base = None
        done_eps = 0
        while done_eps < n_episodes:
            env.reset()
            if base is None:
                base = env.task_layer.metrics()
            for _ in range(env.episode_steps):
                j_obs = env.jammer_obs()
                logits = self.actor(j_obs)
                if greedy:
                    jam_act = (torch.sigmoid(logits) > 0.5).float()
                else:
                    jam_act = torch.distributions.Bernoulli(logits=logits).sample()
                r_act = self._radar_actions(env)
                env.step(r_act, jammer_actions=jam_act)
            done_eps += E
        m = env.task_layer.metrics()
        if base is not None:
            m = dict(
                arrived=m["arrived"] - base["arrived"],
                completed=m["completed"] - base["completed"],
                dropped=m["dropped"] - base["dropped"],
                drop_ratio=(m["dropped"] - base["dropped"]) /
                           max(m["arrived"] - base["arrived"], 1),
                per_type_arrived=[x - y for x, y in zip(m["per_type_arrived"], base["per_type_arrived"])],
                per_type_completed=[x - y for x, y in zip(m["per_type_completed"], base["per_type_completed"])],
                per_type_succeeded=[x - y for x, y in zip(m["per_type_succeeded"], base["per_type_succeeded"])],
                per_type_dropped=[x - y for x, y in zip(m["per_type_dropped"], base["per_type_dropped"])],
            )
        return m
