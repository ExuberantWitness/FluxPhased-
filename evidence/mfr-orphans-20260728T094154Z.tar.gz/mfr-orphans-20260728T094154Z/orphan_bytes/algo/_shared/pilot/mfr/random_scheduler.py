"""Uniform-random scheduler (lower-bound baseline, plan §5).

Each subarray independently picks uniformly among {idle} ∪ exposed bindable
tasks. Uses env.gen for seed-reproducibility.
"""

from __future__ import annotations

import torch


def random_actions(env) -> torch.Tensor:
    tl = env.task_layer
    E, K = env.E, env.K
    dev = env.device
    # Phase B: pass n_pool so off-board virtual slots (>= N_max) are bindable.
    bmask = (
        tl.bindable(env.pool, n_pool=env.N_max)
        if env.has_jammers else tl.bindable(env.pool)
    )
    exposed = tl.exposed(bmask)              # [E,8]
    n_valid = (exposed >= 0).sum(dim=1)      # [E]
    # uniform over 0..n_valid (0 = idle). When antijam action is enabled,
    # the action space extends to 9 (n_act=10); the random scheduler biases
    # 5% of decisions toward antijam (action 9) by capping sampling at n_act-1
    # with a small probability mass.
    u = torch.rand(E, K, device=dev, generator=env.gen)
    acts = (u * (n_valid.unsqueeze(1) + 1).float()).long()
    return acts.clamp(min=0, max=env.n_act - 1)
