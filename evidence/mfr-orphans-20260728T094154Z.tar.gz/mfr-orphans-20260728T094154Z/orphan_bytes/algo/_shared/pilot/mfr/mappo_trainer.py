"""MAPPO trainer for the MFR-IQ env (plan §6).

Per-subarray actor (shared params): obs 159 → 128×128 → 9-way softmax with
action mask. Central critic: 4×159 obs + privileged → 128×128 → V.
PPO: lr 3e-4, γ 0.99, GAE λ 0.95, clip 0.2, entropy 0.01→0.001 linear over the
first 30% of training, value coef 0.5, grad clip 0.5, orthogonal init.
Each iteration: 32 envs × 600 steps rollout, 4 epochs × 4 minibatches.
Health: entropy/kl/policy_loss logged per iteration; collapse guard
(policy_loss→0 and kl<1e-5 for 10 consecutive iters) stops and flags FAIL.
"""

from __future__ import annotations

import csv
import math
import os
import time

import torch
import torch.nn as nn

import sys
sys.path.insert(0, "/home/ubuntu/CODE/FluxPhased-")

from env.gpu.mfr.mfr_env import MfrVecEnv, OBS_DIM


def _orthogonal_init(module, gain=math.sqrt(2.0)):
    if isinstance(module, nn.Linear):
        nn.init.orthogonal_(module.weight, gain=gain)
        nn.init.zeros_(module.bias)


class Actor(nn.Module):
    def __init__(self, obs_dim=OBS_DIM, n_act=9, hidden=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, n_act),
        )
        self.net.apply(_orthogonal_init)
        nn.init.orthogonal_(self.net[-1].weight, gain=0.01)

    def forward(self, obs):
        return self.net(obs)


class Critic(nn.Module):
    def __init__(self, in_dim, hidden=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, 1),
        )
        self.net.apply(_orthogonal_init)
        nn.init.orthogonal_(self.net[-1].weight, gain=1.0)

    def forward(self, x):
        return self.net(x).squeeze(-1)


class MfrMAPPO:
    def __init__(self, seed=0, n_envs=32, device="cuda", load_factor=1.5,
                 log_dir=None, total_iters=200, drop_penalty_scale=7.0):
        self.seed = int(seed)
        self.device = device
        self.total_iters = int(total_iters)
        torch.manual_seed(self.seed)
        self.env = MfrVecEnv(n_envs=n_envs, K=4, N_max=12, device=device,
                             seed=self.seed, load_factor=load_factor,
                             drop_penalty_scale=drop_penalty_scale)
        self.E, self.K = self.env.E, self.env.K
        priv_dim = self.env.privileged().shape[1]
        self.actor = Actor().to(device)
        self.critic = Critic(self.K * OBS_DIM + priv_dim).to(device)
        self.opt = torch.optim.Adam(
            list(self.actor.parameters()) + list(self.critic.parameters()),
            lr=3e-4,
        )
        self.gamma, self.gae_lam, self.clip = 0.99, 0.95, 0.2
        self.log_dir = log_dir
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)

    # ------------------------------------------------------------------
    def _entropy_coef(self, it):
        frac = it / max(self.total_iters, 1)
        if frac >= 0.3:
            return 0.005  # floor raised 0.001→0.005 (exploration guard, 2026-07-27)
        return 0.01 + (0.005 - 0.01) * (frac / 0.3)

    # ------------------------------------------------------------------
    def train(self):
        env, E, K, dev = self.env, self.E, self.K, self.device
        T = env.episode_steps  # 600 — episode boundary == iteration boundary
        log_path = os.path.join(self.log_dir, "train_curve.csv") if self.log_dir else None
        if log_path:
            f_log = open(log_path, "w", newline="")
            writer = csv.writer(f_log)
            writer.writerow(["iter", "entropy", "kl", "policy_loss", "value_loss",
                             "ep_reward", "drop_ratio", "succeeded", "arrived",
                             "entropy_coef", "sec_per_iter"])

        collapse_streak = 0
        status = "OK"
        # Counters persist across iterations within one train() run (queue
        # state resets each iter, metrics counters don't) → snapshot per iter.
        prev = dict(arrived=0, dropped=0, succeeded=0)
        for it in range(self.total_iters):
            t0 = time.time()
            obs = env.reset()
            m0 = env.task_layer.metrics()
            base_arrived, base_dropped = m0["arrived"], m0["dropped"]
            base_succ = sum(m0["per_type_succeeded"])

            b_obs = torch.zeros(T, E, K, OBS_DIM, device=dev)
            b_act = torch.zeros(T, E, K, dtype=torch.long, device=dev)
            b_logp = torch.zeros(T, E, K, device=dev)
            b_mask = torch.zeros(T, E, K, 9, dtype=torch.bool, device=dev)
            b_rew = torch.zeros(T, E, device=dev)
            b_val = torch.zeros(T, E, device=dev)
            b_done = torch.zeros(T, E, device=dev)
            b_priv = torch.zeros(T, E, self.critic.net[0].in_features - K * OBS_DIM, device=dev)

            with torch.no_grad():
                for t in range(T):
                    mask = env.action_mask()
                    priv = env.privileged()
                    flat = obs.reshape(E, K * OBS_DIM)
                    cin = torch.cat([flat, priv], dim=-1)
                    logits = self.actor(obs)
                    logits = logits.masked_fill(~mask, -1e9)
                    dist = torch.distributions.Categorical(logits=logits)
                    act = dist.sample()
                    b_obs[t], b_act[t] = obs, act
                    b_logp[t] = dist.log_prob(act)
                    b_mask[t] = mask
                    b_val[t] = self.critic(cin)
                    b_priv[t] = priv
                    obs, rew, done, _ = env.step(act)
                    b_rew[t] = rew[:, 0]  # team reward
                    b_done[t] = done.float()

            # GAE (team reward, central value)
            adv = torch.zeros(T, E, device=dev)
            lastgae = torch.zeros(E, device=dev)
            for t in reversed(range(T)):
                nextval = b_val[t + 1] if t < T - 1 else torch.zeros(E, device=dev)
                nonterm = 1.0 - b_done[t]
                delta = b_rew[t] + self.gamma * nextval * nonterm - b_val[t]
                lastgae = delta + self.gamma * self.gae_lam * nonterm * lastgae
                adv[t] = lastgae
            ret = adv + b_val

            # Flatten
            f_obs = b_obs.reshape(T * E * K, OBS_DIM)
            f_act = b_act.reshape(T * E * K)
            f_logp = b_logp.reshape(T * E * K)
            f_mask = b_mask.reshape(T * E * K, 9)
            f_adv = adv.unsqueeze(-1).expand(T, E, K).reshape(T * E * K)
            cin_all = torch.cat([
                b_obs.reshape(T, E, K * OBS_DIM), b_priv
            ], dim=-1).reshape(T * E, -1)
            f_ret = ret.reshape(T * E)
            f_val = b_val.reshape(T * E)

            f_adv = (f_adv - f_adv.mean()) / (f_adv.std() + 1e-8)

            n = T * E * K
            nc = T * E
            mb = n // 4
            ent_coef = self._entropy_coef(it)
            stats = dict(entropy=0.0, kl=0.0, policy_loss=0.0, value_loss=0.0)
            nupd = 0
            for _ in range(4):
                perm = torch.randperm(T * E, device=dev)
                for mb_i in range(4):
                    # minibatch over env-steps; expand to agents
                    idx_e = perm[mb_i * (nc // 4):(mb_i + 1) * (nc // 4)]
                    # actor batch: all K agents of these env-steps
                    rows = (idx_e.unsqueeze(-1) * K + torch.arange(K, device=dev)).reshape(-1)
                    mo = f_obs[rows]
                    ma = f_act[rows]
                    mlp = f_logp[rows]
                    mm = f_mask[rows]
                    madv = f_adv[rows]
                    logits = self.actor(mo).masked_fill(~mm, -1e9)
                    dist = torch.distributions.Categorical(logits=logits)
                    logp = dist.log_prob(ma)
                    ratio = (logp - mlp).exp()
                    s1 = ratio * madv
                    s2 = ratio.clamp(1 - self.clip, 1 + self.clip) * madv
                    policy_loss = -torch.min(s1, s2).mean()
                    entropy = dist.entropy().mean()
                    kl = (mlp - logp).mean()

                    v = self.critic(cin_all[idx_e])
                    value_loss = 0.5 * (v - f_ret[idx_e]).pow(2).mean()

                    loss = policy_loss + 0.5 * value_loss - ent_coef * entropy
                    self.opt.zero_grad()
                    loss.backward()
                    nn.utils.clip_grad_norm_(
                        list(self.actor.parameters()) + list(self.critic.parameters()),
                        0.5,
                    )
                    self.opt.step()
                    stats["entropy"] += float(entropy.detach())
                    stats["kl"] += float(kl.detach())
                    stats["policy_loss"] += float(policy_loss.detach())
                    stats["value_loss"] += float(value_loss.detach())
                    nupd += 1
            for k in stats:
                stats[k] /= nupd

            tl = env.task_layer
            m1 = tl.metrics()
            arrived = m1["arrived"] - base_arrived
            dropped = m1["dropped"] - base_dropped
            succeeded = sum(m1["per_type_succeeded"]) - base_succ
            drop_ratio = dropped / max(arrived, 1)
            ep_rew = float(b_rew.sum(dim=0).mean())
            if log_path:
                writer.writerow([it, stats["entropy"], stats["kl"], stats["policy_loss"],
                                 stats["value_loss"], ep_rew, drop_ratio,
                                 succeeded, arrived,
                                 ent_coef, time.time() - t0])
                f_log.flush()

            # collapse guard
            if abs(stats["policy_loss"]) < 1e-7 and stats["kl"] < 1e-5:
                collapse_streak += 1
            else:
                collapse_streak = 0
            if collapse_streak >= 10:
                status = "FAIL_COLLAPSE"
                break

        if log_path:
            f_log.close()
        if self.log_dir:
            torch.save(dict(actor=self.actor.state_dict(),
                            critic=self.critic.state_dict()),
                       os.path.join(self.log_dir, "final.pt"))
        return status

    # ------------------------------------------------------------------
    @torch.no_grad()
    def evaluate(self, n_episodes=100, greedy=True, seed_offset=10000):
        """Run episodes with the current policy; return task-layer metrics."""
        env = self.env
        E = env.E
        done_eps = 0
        env.gen.manual_seed(self.seed + seed_offset)
        base = None
        while done_eps < n_episodes:
            env.reset()
            if base is None:
                base = env.task_layer.metrics()
            for _ in range(env.episode_steps):
                mask = env.action_mask()
                logits = self.actor(env._build_obs()).masked_fill(~mask, -1e9)
                if greedy:
                    act = logits.argmax(dim=-1)
                else:
                    act = torch.distributions.Categorical(logits=logits).sample()
                env.step(act)
            done_eps += E
        m = env.task_layer.metrics()
        if base is not None:
            m = dict(
                arrived=m["arrived"] - base["arrived"],
                completed=m["completed"] - base["completed"],
                dropped=m["dropped"] - base["dropped"],
                drop_ratio=(m["dropped"] - base["dropped"]) / max(m["arrived"] - base["arrived"], 1),
                per_type_arrived=[x - y for x, y in zip(m["per_type_arrived"], base["per_type_arrived"])],
                per_type_completed=[x - y for x, y in zip(m["per_type_completed"], base["per_type_completed"])],
                per_type_succeeded=[x - y for x, y in zip(m["per_type_succeeded"], base["per_type_succeeded"])],
                per_type_dropped=[x - y for x, y in zip(m["per_type_dropped"], base["per_type_dropped"])],
            )
        return m
