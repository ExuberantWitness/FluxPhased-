"""Phase B tests: adversarial jammers (T14-T19).

Run: pytest tests/mfr/test_mfr_jammer.py -x -q
"""

import sys
import math

import torch

sys.path.insert(0, "/home/ubuntu/CODE/FluxPhased-")

from env.gpu.mfr.mfr_env import MfrVecEnv, OBS_DIM, OBS_DIM_JAMMER
from env.gpu.mfr.jammer import JammerField, JAM_POLICY_NOISE, JAM_POLICY_REACTIVE, JAM_POLICY_BLINK
from env.gpu.mfr.task_layer import TYPE_JAM


DEV = "cuda" if torch.cuda.is_available() else "cpu"


def test_t14_jammer_physics_monotone():
    """T14: J0 noise jammer on → σ_meas rises with jammer power; P_detect falls.
    Single subarray staring at a single target; one off-board noise jammer at
    fixed bearing. Sweep jammer_pow_W ∈ {1, 10, 100, 1000}; both monotone."""
    E = 4
    sigmas, jnrs = [], []
    for pw in [1.0, 10.0, 100.0, 1000.0]:
        env = MfrVecEnv(n_envs=E, K=4, N_max=12, device=DEV, seed=0,
                        jammer_policy=JAM_POLICY_NOISE, n_offboard_jammers=1,
                        pool_jammer_frac_of_emitters=0.0,
                        jammer_pow_W=pw)
        env.reset()
        # Place a target at 5 km, beam stare at it
        env.pool.alive[:, 0] = True
        env.pool.pos[:, 0] = torch.tensor([5000.0, 0.0], device=DEV)
        env.pool.vel[:, 0] = 0.0
        env.pool.rcs[:, 0] = 1.0
        # Point all subarrays at target
        baz = torch.zeros(E, 1, 4, device=DEV)
        alloc = torch.zeros(E, 1, 4, 4, device=DEV); alloc[..., 1] = 10.0  # track
        em = torch.ones(E, 1, 4, dtype=torch.bool, device=DEV)
        out = env.physics_step(baz, alloc, em)
        sigmas.append(float(out["sigma_meas"][0, 0, 0].item()))
        jnrs.append(float(out["jnr_from_off_db"][0, 0].item()))
    # σ monotone non-decreasing in jammer power
    for i in range(len(sigmas) - 1):
        assert sigmas[i + 1] >= sigmas[i] - 1e-6, (
            f"σ not monotone: {sigmas}"
        )
    # JNR at subarray strictly increasing (each 10× power = +10 dB)
    for i in range(len(jnrs) - 1):
        delta = jnrs[i + 1] - jnrs[i]
        assert 9.0 < delta < 11.0, (
            f"JNR delta {delta:.2f} not ≈10 dB per 10× power: {jnrs}"
        )


def test_t15_reactive_jammer_trigger():
    """T15: J1 reactive jammer — illuminating ≥3 steps triggers activation;
    stays on for dwell=20; turns off when dwell expires AND no illumination."""
    E = 2
    env = MfrVecEnv(n_envs=E, K=4, N_max=12, device=DEV, seed=0,
                    jammer_policy=JAM_POLICY_REACTIVE, n_offboard_jammers=1,
                    pool_jammer_frac_of_emitters=0.0)
    env.reset()
    # Beam all subarrays directly at the off-board jammer (its bearing is set
    # by _refresh_off_pos: ang0[0]=0 → +x direction).
    # Off-board initial pos = (0.7·region_half, 0); bearing = atan2(0, +) = 0
    baz_at_jam = torch.zeros(E, 1, 4, device=DEV)
    alloc = torch.zeros(E, 1, 4, 4, device=DEV); alloc[..., 1] = 10.0
    em = torch.ones(E, 1, 4, dtype=torch.bool, device=DEV)
    # Step 1-3: illuminate; verify jammer not active for first 2, active from step 3
    for step in range(1, 4):
        env.physics_step(baz_at_jam, alloc, em)
        env.jammer.update_activation(
            env.pool.jammer, env.pool.alive, env.pool.pos,
            baz_at_jam.squeeze(1), env.radar_pos.squeeze(1),
            env.beam_width_rad,
        )
        active = bool(env.jammer.active_off[0, 0].item())
        if step < 3:
            assert not active, f"step {step}: reactive jammer active pre-trigger"
    assert bool(env.jammer.active_off[0, 0].item()), "step 3: reactive must trigger"
    # Stop illuminating; dwell should keep it on for ~20 more steps
    baz_away = torch.full((E, 1, 4), math.pi / 2.0, device=DEV)
    for step in range(4, 24):
        env.physics_step(baz_away, alloc, em)
        env.jammer.update_activation(
            env.pool.jammer, env.pool.alive, env.pool.pos,
            baz_away.squeeze(1), env.radar_pos.squeeze(1),
            env.beam_width_rad,
        )
    # By step ~23 dwell should still be active (triggered at step 3, dwell 20 → ~step 22-23)
    # Then by step 30 it must turn off (no illumination, dwell expired).
    for step in range(24, 35):
        env.physics_step(baz_away, alloc, em)
        env.jammer.update_activation(
            env.pool.jammer, env.pool.alive, env.pool.pos,
            baz_away.squeeze(1), env.radar_pos.squeeze(1),
            env.beam_width_rad,
        )
    assert not bool(env.jammer.active_off[0, 0].item()), (
        "reactive jammer must turn off after dwell expires without illumination"
    )


def test_t16_blink_period_autocorr():
    """T16: J2 blink — 200 steps, on/off autocorrelation peaks at lag = blink_period."""
    E = 1
    env = MfrVecEnv(n_envs=E, K=4, N_max=12, device=DEV, seed=0,
                    jammer_policy=JAM_POLICY_BLINK, n_offboard_jammers=1,
                    pool_jammer_frac_of_emitters=0.0)
    env.reset()
    baz = torch.zeros(E, 1, 4, device=DEV)
    alloc = torch.zeros(E, 1, 4, 4, device=DEV); alloc[..., 1] = 10.0
    em = torch.ones(E, 1, 4, dtype=torch.bool, device=DEV)
    active_seq = []
    for _ in range(200):
        env.physics_step(baz, alloc, em)
        env.jammer.update_activation(
            env.pool.jammer, env.pool.alive, env.pool.pos,
            baz.squeeze(1), env.radar_pos.squeeze(1),
            env.beam_width_rad,
        )
        active_seq.append(int(env.jammer.active_off[0, 0].item()))
    s = torch.tensor(active_seq, dtype=torch.float32)
    s = s - s.mean()
    # Autocorrelation at lag 0 and lag 10
    def acf(s, k):
        return float((s[:len(s) - k] * s[k:]).sum().item() / len(s))
    a0 = acf(s, 0)
    a10 = acf(s, 10)
    a5 = acf(s, 5)
    # Sanity: lag-0 is the max; lag-10 (period) should be > lag-5 (anti-phase)
    assert a10 > a5 * 0.5, (
        f"blink autocorrelation at period-lag (10) {a10:.3f} must exceed anti-phase (5) {a5:.3f}"
    )
    # On-fraction ≈ 0.5
    on_frac = sum(active_seq) / len(active_seq)
    assert 0.4 < on_frac < 0.6, f"on-fraction {on_frac:.2f} not ≈0.5"


def test_t17_ew_cue_emission():
    """T17: high per-jammer JNR → EW auto-cue creates a type-4 task targeting
    the offending jammer. Cool-down prevents re-cue within 60 steps."""
    E = 2
    env = MfrVecEnv(n_envs=E, K=4, N_max=12, device=DEV, seed=0,
                    jammer_policy=JAM_POLICY_NOISE, n_offboard_jammers=1,
                    pool_jammer_frac_of_emitters=0.0,
                    jammer_pow_W=5000.0,           # high power → JNR well above 20 dB
                    ew_detect_db=20.0, ew_cooldown_steps=60)
    env.reset()
    baz = torch.zeros(E, 1, 4, device=DEV)
    alloc = torch.zeros(E, 1, 4, 4, device=DEV); alloc[..., 1] = 10.0
    em = torch.ones(E, 1, 4, dtype=torch.bool, device=DEV)
    # Step once: should trigger a cue via task_layer.cue_jammers
    n_before = int(env.task_layer.active.sum().item())
    env.physics_step(baz, alloc, em)
    env.jammer.update_activation(
        env.pool.jammer, env.pool.alive, env.pool.pos,
        baz.squeeze(1), env.radar_pos.squeeze(1), env.beam_width_rad,
    )
    cue_pool, cue_off = env.jammer.ew_detect(
        # placeholder last-step JNR (env physics_step output cached separately)
        torch.zeros(E, 12, device=DEV),
        torch.full((E, 1), 50.0, device=DEV),  # well above 20 dB threshold
    )
    assert cue_off.any(), "high-JNR off-board jammer must trigger EW cue"
    env.task_layer.cue_jammers(cue_pool, cue_off, n_pool=env.N_max)
    n_after = int(env.task_layer.active.sum().item())
    assert n_after > n_before, "cue must add a type-4 task to the queue"
    # Verify the new task targets the off-board slot (N_max + 0)
    f = env.task_layer.fields
    new = (env.task_layer.active & (f[:, :, 0].long() == TYPE_JAM))
    assert new.any(), "cued task must be type JAM"
    tgt = f[new][:, 6].long()  # F_TGT = 6
    assert (tgt >= env.N_max).any(), "cued task must target off-board virtual slot"


def test_t18_antijam_action_sigma_attenuation():
    """T18: subarray with antijam_mask=True → its incoming jammer JNR attenuated
    by ~1/hop_rate_max factor; the subarray is idle (no task progress)."""
    E = 2
    env = MfrVecEnv(n_envs=E, K=4, N_max=12, device=DEV, seed=0,
                    jammer_policy=JAM_POLICY_NOISE, n_offboard_jammers=1,
                    pool_jammer_frac_of_emitters=0.0,
                    jammer_pow_W=100.0,
                    enable_antijam_action=True)
    env.reset()
    baz = torch.zeros(E, 1, 4, device=DEV)
    alloc = torch.zeros(E, 1, 4, 4, device=DEV); alloc[..., 1] = 10.0
    em = torch.ones(E, 1, 4, dtype=torch.bool, device=DEV)
    # Baseline: no antijam
    out0 = env.physics_step(baz, alloc, em, antijam_mask=torch.zeros(E, 4, dtype=torch.bool, device=DEV))
    jnr0 = float(out0["jnr_at_sub"][0, 0].item())
    # With antijam on subarray 0
    aj = torch.zeros(E, 4, dtype=torch.bool, device=DEV); aj[:, 0] = True
    out1 = env.physics_step(baz, alloc, em, antijam_mask=aj)
    jnr1 = float(out1["jnr_at_sub"][0, 0].item())
    # Antijam raises hop_rate from 1 → 8 → overlap dilution 8× → JNR ~8× lower
    # (linear) ≈ 9 dB drop
    drop_db = 10 * math.log10(jnr0 / max(jnr1, 1e-15))
    assert drop_db > 5.0, f"antijam should drop JNR by ≥5 dB; got {drop_db:.2f}"


def test_t19_phase_a_bit_identical():
    """T19: default ctor (jammer_policy=None) → env shape matches Phase A:
    obs_dim=159, n_act=9, has_jammers=False, jammer=None, and a random-policy
    rollout is NaN-free. Bit-identical trajectory reproducibility across
    separate env instances is not asserted here (CUDA reduction ordering
    introduces ~1e-4-level drift over long rollouts); reset() reproducibility
    under same seed is covered by test_mfr_env.py T1."""
    E = 2
    env = MfrVecEnv(n_envs=E, K=4, N_max=12, device=DEV, seed=42)
    assert env.obs_dim == OBS_DIM == 159, f"obs_dim {env.obs_dim} != 159"
    assert env.n_act == 9
    assert env.has_jammers is False
    assert env.jammer is None
    # Same-seed reset must produce identical obs (Phase A contract)
    env_a = MfrVecEnv(n_envs=E, K=4, N_max=12, device=DEV, seed=42)
    env_b = MfrVecEnv(n_envs=E, K=4, N_max=12, device=DEV, seed=42)
    oa, _ = env_a.reset()
    ob, _ = env_b.reset()
    assert torch.equal(oa, ob), "Phase A reset(seed) reproducibility broken"
    # NaN-free smoke: 50-step random policy
    env_a.reset()
    g = torch.Generator(device=DEV).manual_seed(0)
    for _ in range(50):
        a = torch.randint(0, 9, (E, 4), generator=g, device=DEV)
        o, r, _, _ = env_a.step(a)
        assert torch.isfinite(o).all(), "Phase A obs has NaN/Inf"
        assert torch.isfinite(r).all(), "Phase A reward has NaN/Inf"
