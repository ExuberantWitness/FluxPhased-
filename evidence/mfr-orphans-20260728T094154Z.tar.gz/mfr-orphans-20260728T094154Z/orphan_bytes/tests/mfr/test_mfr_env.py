"""M1 tests: target pool + physics chain + obs skeleton (T1-T6).

Run: pytest tests/mfr/test_mfr_env.py -x -q
"""

import sys

import torch

sys.path.insert(0, "/home/ubuntu/CODE/FluxPhased-")

from env.gpu.mfr.mfr_env import MfrVecEnv, OBS_DIM
from env.gpu.mfr.target_pool import TargetPool

DEV = "cuda" if torch.cuda.is_available() else "cpu"


def test_t1_target_pool_statistics():
    """T1: steady-state alive count, despawn rules, seed reproducibility."""
    gen = torch.Generator(device=DEV)
    gen.manual_seed(0)
    pool = TargetPool(E=64, N_max=12, lam_spawn=0.017, device=DEV, gen=gen)
    # 600 steps ≈ one episode; measure alive over last 100 steps (steady state)
    counts = []
    for step in range(600):
        pool.step()
        if step >= 500:
            counts.append(pool.n_alive().float())
    mean_alive = torch.stack(counts).mean().item()
    assert 4.0 <= mean_alive <= 10.0, f"steady-state alive {mean_alive} outside [4,10] band"

    # Despawn: force a target out of region → dies next step
    pool.alive[0, 0] = True
    pool.pos[0, 0] = torch.tensor([1e6, 0.0], device=DEV)
    pool.step()
    assert not bool(pool.alive[0, 0]), "out-of-region target must despawn"

    # Seed reproducibility
    def run(seed):
        g = torch.Generator(device=DEV)
        g.manual_seed(seed)
        p = TargetPool(E=4, N_max=12, lam_spawn=0.02, device=DEV, gen=g)
        for _ in range(50):
            p.step()
        return p.pos.clone(), p.alive.clone()
    a = run(123)
    b = run(123)
    assert torch.equal(a[0], b[0]) and torch.equal(a[1], b[1]), "same seed must reproduce"


def _env(E=8, seed=0, **kw):
    return MfrVecEnv(n_envs=E, K=4, N_max=12, device=DEV, seed=seed, **kw)


def test_t2_physics_detection_monotonicity():
    """T2: in-beam detection >> out-of-beam; JNR injection lowers detections."""
    env = _env(E=8)
    K = env.K
    # Place one strong target dead-ahead of subarray 0 at 5 km
    env.pool.alive[:] = False
    env.pool.alive[:, 0] = True
    env.pool.pos[:, 0] = torch.tensor([5000.0, 0.0], device=DEV)
    env.pool.vel[:] = 0.0
    env.pool.rcs[:, 0] = 2.0
    env.pool.emitter[:] = False

    alloc = torch.zeros(8, 1, K, 4, device=DEV)
    alloc[..., 0] = 10.0  # softmax → detect ≈ 1
    em = torch.ones(8, 1, K, dtype=torch.bool, device=DEV)

    def count_detections(beam0, n_steps=50):
        torch.manual_seed(7)
        n = 0
        for _ in range(n_steps):
            baz = torch.zeros(8, 1, K, device=DEV)
            baz[:, 0, 0] = beam0
            # stagger other subarrays' beams away + different channels not modeled
            baz[:, 0, 1:] = torch.pi
            out = env.physics_step(baz, alloc, em)
            n += int(out["detections"].mask[:, 0].sum().item())
        return n

    n_in = count_detections(0.0)
    n_out = count_detections(torch.pi / 2)
    assert n_in >= 25, f"in-beam detections {n_in} too low"
    assert n_out <= 5, f"out-of-beam detections {n_out} too high"
    assert n_in > 4 * max(n_out, 1), "in-beam must dominate"

    # JNR injection: another emitter target jamming subarray 0 co-channel.
    # Model: add an emitting node by marking target 1 as emitter AT subarray
    # position with high effective power is not wired in M1 (emitters don't
    # interfere). Instead verify sigma inflation path: jnr_at_sub raises σ.
    out = env.physics_step(torch.zeros(8, 1, K, device=DEV), alloc, em)
    sigma_clean = out["sigma_meas"].clone()
    # Co-located subarrays all emitting same freq → mutual JNR → larger σ
    # than single-emitter case. Compare against K=1 effective (others off):
    em_one = torch.zeros(8, 1, K, dtype=torch.bool, device=DEV)
    em_one[:, 0, 0] = True
    out2 = env.physics_step(torch.zeros(8, 1, K, device=DEV), alloc, em_one)
    sigma_solo = out2["sigma_meas"]
    assert (sigma_clean >= sigma_solo - 1e-9).all(), "more co-channel emitters must not reduce σ"


def test_t3_tracker_convergence():
    """T3: constant illumination of a CV target → initialized + trace_P decreases."""
    env = _env(E=4)
    K = env.K
    env.pool.alive[:] = False
    env.pool.alive[:, 0] = True
    env.pool.pos[:, 0] = torch.tensor([5000.0, 0.0], device=DEV)
    env.pool.vel[:, 0] = torch.tensor([100.0, 0.0], device=DEV)
    env.pool.rcs[:, 0] = 2.0
    env.pool.emitter[:] = False
    env.pool.max_age = 10 ** 9  # keep alive for the test

    alloc = torch.zeros(4, 1, K, 4, device=DEV)
    alloc[..., 0] = 10.0
    em = torch.ones(4, 1, K, dtype=torch.bool, device=DEV)

    torch.manual_seed(3)
    traces = []
    for step in range(150):
        # beam servos to true target azimuth each step (physics test only)
        tgt = env.pool.pos[:, 0]
        baz = torch.zeros(4, 1, K, device=DEV)
        baz[:, 0, :] = torch.atan2(tgt[:, 1], tgt[:, 0]).unsqueeze(-1)
        env.pool.step()
        env.physics_step(baz, alloc, em)
        tp = (
            env.tracker_P[:, 0, :, 0, 0] + env.tracker_P[:, 0, :, 2, 2]
        ).min(dim=1).values  # best slot per env
        traces.append(tp)
        if step > 60:
            assert bool(env.tracker_initialized[:, 0].any(dim=1).all()), \
                "all envs must have an initialized track by step 60"
    early = torch.stack(traces[2:12]).mean()
    late = torch.stack(traces[-20:]).mean()
    assert late < early, f"trace_P must decrease: early {early:.3f} late {late:.3f}"


def test_t4_no_godview():
    """T4: a target never illuminated must have zero belief in obs (no leak)."""
    env = _env(E=4)
    obs = env._build_obs()
    assert obs.shape == (4, 4, OBS_DIM)
    # Fresh reset: nothing detected → all belief channels zero
    base = 12 + 8 * 9
    beliefs = obs[:, :, base:base + 12 * 6]
    assert (beliefs == 0).all(), "fresh-reset beliefs must be zero (no godview)"

    # Illuminate only target 0; target 1 must remain zero-belief
    K = env.K
    env.pool.alive[:] = False
    env.pool.alive[:, 0] = True
    env.pool.alive[:, 1] = True
    env.pool.pos[:, 0] = torch.tensor([5000.0, 0.0], device=DEV)
    env.pool.pos[:, 1] = torch.tensor([-5000.0, 0.0], device=DEV)
    env.pool.vel[:] = 0.0
    env.pool.rcs[:, 0:2] = 2.0
    env.pool.emitter[:] = False
    alloc = torch.zeros(4, 1, K, 4, device=DEV)
    alloc[..., 0] = 10.0
    em = torch.ones(4, 1, K, dtype=torch.bool, device=DEV)
    torch.manual_seed(5)
    for _ in range(80):
        baz = torch.zeros(4, 1, K, device=DEV)  # all beams at az 0 → target 0 only
        env.physics_step(baz, alloc, em)
    obs = env._build_obs()
    beliefs = obs[0, 0, base:base + 12 * 6].reshape(12, 6)
    init_flags = beliefs[:, 5]
    n_init = int((init_flags > 0).sum().item())
    assert n_init >= 1, "target 0 under constant illumination must be tracked"
    # No initialized track may sit near the never-illuminated target 1 (-5000, 0).
    # Belief pos is normalized by region_half=15000 → target 1 at (-1/3, 0).
    pos_b = beliefs[init_flags > 0][:, [0, 2]]
    tgt1 = torch.tensor([-1.0 / 3.0, 0.0], device=DEV)
    d_tgt1 = (pos_b - tgt1).norm(dim=-1)
    assert float(d_tgt1.min()) > 0.1, \
        f"track within 1500 m of never-illuminated target 1 (leak): {d_tgt1.min().item():.4f}"


def test_t5_nan_free_random():
    """T5: random controls, 10 short episodes, no NaN/Inf anywhere."""
    env = _env(E=8)
    K = env.K
    torch.manual_seed(11)
    for ep in range(10):
        env.reset()
        for _ in range(120):
            baz = (torch.rand(8, 1, K, device=DEV) - 0.5) * 2 * torch.pi
            alloc = torch.randn(8, 1, K, 4, device=DEV)
            em = torch.rand(8, 1, K, device=DEV) > 0.3
            out = env.physics_step(baz, alloc, em)
            obs = env._build_obs()
            for name, t in [
                ("obs", obs), ("dets.z", out["detections"].z),
                ("jnr_sub", out["jnr_at_sub"]), ("sigma", out["sigma_meas"]),
                ("tracker_x", env.tracker_x), ("tracker_P", env.tracker_P),
            ]:
                assert torch.isfinite(t).all(), f"ep{ep} {name} non-finite"


def test_t6_detection_old_path_snapshot():
    """T6: twoteam detect() old path (no target_pos) output snapshot guard."""
    from env.gpu.twoteam.detection import detect
    torch.manual_seed(99)
    E, T, R = 2, 2, 2
    dev = DEV
    pos = torch.randn(E, T, R, 2, device=dev) * 2000
    baz = torch.zeros(E, T, R, device=dev)
    alloc = torch.full((E, T, R, 4), 0.25, device=dev)
    em = torch.ones(E, T, R, dtype=torch.bool, device=dev)
    alive = torch.ones(E, T, R, dtype=torch.bool, device=dev)
    jnr = torch.zeros(E, 4, 4, device=dev)
    d = detect(
        pos, baz, alloc, em, em, alive, jnr,
        range_max_m=8000.0, fc_hz=10e9, channel_bw_hz=10e6,
        noise_figure_db=5.0, P_per_subarray_W=5.0, n_subarrays=25,
        aperture_D_m=0.4, aperture_eta=0.6, sigma_rcs_m2=1.0,
        detect_threshold_db=15.0, detect_width_db=3.0, p_fa=1e-6,
        k_max=8, n_search_cells=84, beam_width_rad=0.075,
        coherent_processing_gain_db=20.0, device=dev,
    )
    # Snapshot invariants (computed post-M0; guards future edits)
    assert d.z.shape == (E, T, 8, 2)
    assert d.mask.shape == (E, T, 8)
    n_det = int(d.mask.sum().item())
    assert 0 <= n_det <= E * T * 8
    assert torch.isfinite(d.z).all() and torch.isfinite(d.snr_db).all()
