# Orphan MFR Files Evidence Report

**Case ID**: mfr-orphans-20260728T094154Z
**Capture host**: node15 (uid=1000 ubuntu)
**Case directory**: `/home/ubuntu/evidence/mfr-orphans-20260728T094154Z/`
**Packaged archive**: `/home/ubuntu/evidence/mfr-orphans-20260728T094154Z.tar.gz`
**Package SHA-256**: `32236db9fb90d6864669528e0d988048a524405250137190a614ffc4b833606a`

## Source-status declaration

```
origin_status=UNKNOWN
authority_status=NOT_APPROVED
permitted_use=FORENSIC_INSPECTION_ONLY
```

These bytes are L1 frozen-snapshot evidence only. They are **not** authoritative M7 source. They may not be added to any FluxPhased branch, may not be executed, and may not be used to populate SYMBOL_MAP as if verified.

## Capture interval

```
capture_start_utc: 20260728T094154Z  (epoch 1753801314)
capture_end_utc:   20260728T094820Z  (epoch 1753801700)
```

Per ORPHAN_MFR_QUARANTINE_PROTOCOL.md §Phase 1: this report claims only that the captured bytes remained stable during host-clock capture interval `[2026-07-28T09:41:54Z, 2026-07-28T09:48:20Z]` on host `node15`. mtime/ctime are not proof of creation time.

## Disclosed forensic limitation

```
constraint_violations: 1
forensic_limitation: POST_INSTRUCTION_FETCH_BEFORE_EVIDENCE_CAPTURE
failed_fetch_command: timeout 30 git -C /home/ubuntu/CODE/FluxPhased- fetch origin
failed_fetch_exit_status: 124
failed_fetch_stderr: curl 28 / GnuTLS recv error (-110) The TLS connection was non-properly terminated
```

A post-instruction `git fetch origin` was attempted in the original repository before this evidence capture. It timed out and produced an empty `.git/FETCH_HEAD` (0 bytes, mtime 2026-07-28 17:01). The fetch attempt therefore cannot have written remote refs, but it **may have touched** `.git/FETCH_HEAD` and reflog metadata. A pristine pre-fetch Git metadata scene **cannot be claimed**.

The orphan byte-capture itself is unaffected: bytes were captured after the fetch attempt, and double-hash verification (pass A on original → copy → pass B on original) confirms stability of the working-tree bytes during the capture interval.

## Filesystem scene

```
hostname:        node15
kernel:          Linux 7.0.0-28-generic #28~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC
filesystem:      ext4 (rw,relatime) on /dev/nvme0n1p2
no Btrfs/ZFS/LVM snapshot available — capture is interval-stable, not atomic
repository realpath: /home/ubuntu/CODE/FluxPhased-
device_inode:    66306:3282798
```

## Git scene (post-fetch, with disclosed limitation)

```
HEAD:               807588cab7d367bedd415b45efc85a72f2a38b89
HEAD_branch:        refs/heads/twoteam/bc-ppo
remote_url:         https://github_pat_...@github.com/ExuberantWitness/FluxPhased-.git
local_refs_count:   5 local branches + 8 remote refs + 1 stash
FETCH_HEAD:         empty file (0 bytes, mtime 2026-07-28 17:01)
```

Full reflog (`REFLOG_all.txt`, 31 KB) and porcelain v2 status (`STATUS_porcelain_v2_nul.txt`, NUL-safe) captured alongside this report.

## Orphan file inventory

**17 source files** captured as stable during the interval:

| # | Relative path | SHA-256 (pass A = pass B = copy) |
|---|---|---|
| 1 | `algo/_shared/pilot/mfr/__init__.py` | `e3b0c442...b855` (empty) |
| 2 | `algo/_shared/pilot/mfr/jammer_trainer.py` | `8d81d988...fe8e` |
| 3 | `algo/_shared/pilot/mfr/league_eval.py` | `62ef159e...5872` |
| 4 | `algo/_shared/pilot/mfr/mappo_trainer.py` | `e4509a3d...8ce7` |
| 5 | `algo/_shared/pilot/mfr/random_scheduler.py` | `a58f2a95...f157` |
| 6 | `algo/_shared/pilot/mfr/rule_scheduler.py` | `0654a860...8bd9` |
| 7 | `algo/_shared/pilot/mfr/run_stage_a.py` | `102c36f3...5d04` |
| 8 | `algo/_shared/pilot/mfr/run_stage_b.py` | `642197a9...2ad1` |
| 9 | `algo/_shared/pilot/mfr/run_stage_b_jammer.py` | `234ba846...b1d5` |
| 10 | `env/gpu/mfr/__init__.py` | `e3b0c442...b855` (empty) |
| 11 | `env/gpu/mfr/jammer.py` | `8009122c...89e4` |
| 12 | `env/gpu/mfr/mfr_env.py` | `eebfc90a...036b` |
| 13 | `env/gpu/mfr/target_pool.py` | `17c6ad70...e501` |
| 14 | `env/gpu/mfr/task_layer.py` | `27bc51a9...5700` |
| 15 | `tests/mfr/test_mfr_env.py` | `2246e4a0...4f69` |
| 16 | `tests/mfr/test_mfr_jammer.py` | `306b39e0...9b6e` |
| 17 | `tests/mfr/test_mfr_tasks.py` | `50ed79e1...c6bf` |

Full JSONL manifest with metadata (size, mode, UID/GID, inode, mtime, ctime, birth time, git blob hash without filters) for each file: see `ORPHAN_EVIDENCE_MANIFEST.jsonl`.

**All 17 files**: STABLE across double-hash passes (pass A on original, pass B on original after copy, hash of copy). No symlinks. No unstable captures.

## Related untracked artifacts (NOT source, disclosed for completeness)

The working tree also contains untracked experiment output directories that were produced by prior runs of the orphan source files:

- `experiments/mfr/` (Phase A artifacts)
- `experiments/mfr_phaseB/` (Phase B artifacts, including the G2'a diagnostic checkpoint referenced in prior conversation)

These are research outputs, not source code. Listing captured in `RELATED_EXPERIMENTS_DIR_LISTING.txt`. They are outside the scope of the M7 source closure and are retained only for forensic completeness.

## Chain of custody

- **Collector**: PRO6000 agent (this conversation), running as `ubuntu@node15`
- **Signer**: sole signer (PRO6000 agent). Protocol §Phase 1 prefers a second signer and a trusted external timestamp; neither is available in this environment. The package is therefore **single-signer only**; any downstream adoption must require additional independent verification.
- **No external timestamp authority** was used (no sigstore, no OpenTimestamps). The capture interval is recorded by node15's host clock only.

## Permitted next steps (per protocol §Phase 2)

After this immutable archive exists, **isolated inspection** may be performed on a copy in a disposable clone/container with network disabled and no credentials mounted. The orphan files in the original worktree remain non-authoritative and must not be:

- deleted
- executed before snapshotting (already snapshotted; still must not be executed without quarantine container)
- added to any existing FluxPhased branch
- called M7 source
- used to populate SYMBOL_MAP as if verified

## Promotion criteria (per protocol §Phase 3)

`SOURCE_HANDOFF.json` and an implementation candidate are allowed only after all eight promotion criteria pass: stable evidence, verifiable commit/explicit adoption, no forged history, complete source closure, secret/license review, clean-room build, owner approval, fixed commit/tree hash with dirty=false. None of these have been performed. The evidence remains at **L1 frozen snapshot**.

This report and the underlying archive may not be used to claim any higher evidence level.
